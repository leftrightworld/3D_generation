"""Generate galileo_pendulum_peg.xml — Galileo pendulum with fixed peg.

Physics: inextensible 0.60 m string (pivot to bob, stiffness=0 limit).
Visual: spatial tendon with peg wrap (decorative kink when string contacts peg).
"""
import math
import os

L_TOTAL = 0.60
L_UPPER = 0.30
PIVOT = (0, 0.55, 1.00)
PEG = (0, 0.55, 0.70)
Y_SWING = 0.55
Z_REF = 0.70

# 60 deg left of vertical: bob at same height as peg
angle = math.radians(60)
bob_x = -L_TOTAL * math.sin(angle)
bob_z = PIVOT[2] - L_TOTAL * math.cos(angle)

xml = f"""<mujoco model="galileo_pendulum_peg">
  <!-- Galileo pendulum with peg: total string length {L_TOTAL} m.
       Pivot→peg = {L_UPPER} m; after wrap the bob swings on the shorter
       segment peg→bob while energy keeps the right-side peak near z={Z_REF}. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="wood" rgba="0.93 0.82 0.58 1" specular="0.1" shininess="0.1"/>
    <material name="peg_mat" rgba="0.78 0.65 0.40 1" specular="0.2" shininess="0.2"/>
    <material name="bob_brass" rgba="0.90 0.74 0.36 1" specular="0.7" shininess="0.85"/>
    <material name="string_mat" rgba="0.28 0.25 0.22 1" specular="0" shininess="0"/>
    <material name="line_mat" rgba="0.55 0.50 0.48 0.5" specular="0" shininess="0"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>
    <!-- Stand (non-colliding; swing plane at y={Y_SWING}) -->
    <geom type="box" size="0.04 0.04 0.50" pos="0 0.30 0.50" material="wood"
          contype="0" conaffinity="0"/>
    <geom type="box" size="0.20 0.04 0.04" pos="0 0.30 1.00" material="wood"
          contype="0" conaffinity="0"/>

    <site name="pivot" pos="{PIVOT[0]} {PIVOT[1]} {PIVOT[2]}" size="0.006"/>

    <!-- Fixed peg on post (axis +y for wrap in xz plane) -->
    <geom name="peg" type="cylinder" size="0.024 0.045" pos="{PEG[0]} {PEG[1]} {PEG[2]}"
          euler="1.5708 0 0" material="peg_mat" contype="0" conaffinity="0"/>
    <site name="peg_side" pos="0 {PEG[1]+0.10} {PEG[2]}" size="0.004"/>

    <!-- Start-height reference line -->
    <geom type="capsule" fromto="-0.55 {Y_SWING} {Z_REF}  0.55 {Y_SWING} {Z_REF}"
          size="0.003" material="line_mat" contype="0" conaffinity="0"/>

    <!-- Bob released from 60 deg left, z = reference height -->
    <body name="bob" pos="{bob_x:.4f} {Y_SWING} {bob_z:.4f}">
      <freejoint/>
      <site name="bob_hook" pos="0 0 0" size="0.005"/>
      <geom type="sphere" size="0.025" mass="0.05" material="bob_brass"/>
    </body>

    <camera name="cam" pos="0 -2.2 0.65" fovy="42"
            xyaxes="1 0 0   0 0 1"/>
  </worldbody>

  <tendon>
    <!-- Physics: inextensible string, chord length = {L_TOTAL} m -->
    <spatial name="string_phys" limited="true" range="0 {L_TOTAL + 0.002:.3f}"
             stiffness="0" damping="0"
             solreflimit="0.001 1" solimplimit="0.99 0.999 0.001">
      <site site="pivot"/>
      <site site="bob_hook"/>
    </spatial>
    <!-- Visual: string with peg wrap — shows kink when bob passes peg on the right -->
    <spatial name="string_vis" width="0.005" rgba="0.28 0.25 0.22 1"
             limited="false" stiffness="0" damping="0">
      <site site="pivot"/>
      <geom geom="peg" sidesite="peg_side"/>
      <site site="bob_hook"/>
    </spatial>
  </tendon>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "galileo_pendulum_peg.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out}")
