"""
Generate scenes/spool_with_string.xml with visible multi-turn string wraps
around the axle (side view shows stacked arcs under the hub).
"""
import math
import os

# Wrap geometry: semicircular arcs in xz (side view along -y).
# Each turn is offset in +x so coils read left-to-right under the hub.
N_WRAPS = 6
WRAP_R = 0.042         # groove radius on the visible face
WRAP_SEGS = 8
WRAP_X_STEP = 0.008
# Only the bottom-right quadrant (toward +x exit): no horns sticking out left.
ARC_START = -math.pi * 0.48
ARC_END = -math.pi * 0.06


def wrap_capsules():
    lines = []
    for turn in range(N_WRAPS):
        cx = turn * WRAP_X_STEP
        cz = -0.004 - turn * 0.0018
        for seg in range(WRAP_SEGS):
            t0 = ARC_START + (ARC_END - ARC_START) * seg / WRAP_SEGS
            t1 = ARC_START + (ARC_END - ARC_START) * (seg + 1) / WRAP_SEGS
            x0 = cx + WRAP_R * math.cos(t0)
            z0 = cz + WRAP_R * math.sin(t0)
            x1 = cx + WRAP_R * math.cos(t1)
            z1 = cz + WRAP_R * math.sin(t1)
            mat = "wrap_dark" if turn % 2 else "wrap_light"
            lines.append(
                f'      <geom type="capsule" fromto="{x0:.5f} 0 {z0:.5f}  '
                f'{x1:.5f} 0 {z1:.5f}" size="0.0032" material="{mat}" '
                f'contype="0" conaffinity="0"/>'
            )
    return "\n".join(lines)


wrap_xml = wrap_capsules()
# Free end of the rope leaves after the last wrap toward +x.
last_cz = -0.004 - (N_WRAPS - 1) * 0.0018
last_cx = (N_WRAPS - 1) * WRAP_X_STEP
string_site_x = last_cx + WRAP_R * math.cos(ARC_END) + 0.005
string_site_z = last_cz + WRAP_R * math.sin(ARC_END)

xml = f"""<mujoco model="spool_with_string">
  <!-- String wrapped under the axle (multi-turn visual); mocap hand in
       render.py pulls +x so the spool rolls toward the puller. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="36"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="brass" rgba="0.90 0.74 0.36 1" specular="0.65" shininess="0.75"/>
    <material name="axle_mat" rgba="0.30 0.28 0.30 1" specular="0.5" shininess="0.6"/>
    <material name="hand_blue" rgba="0.30 0.50 0.78 1" specular="0.4" shininess="0.5"/>
    <material name="wrap_dark" rgba="0.18 0.16 0.14 1" specular="0" shininess="0"/>
    <material name="wrap_light" rgba="0.32 0.29 0.26 1" specular="0" shininess="0"/>
  </asset>

  <default>
    <geom friction="0.62 0.008 0.0001" solref="0.004 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <body name="spool" pos="-0.28 0 0.062">
      <freejoint/>
      <geom name="drum" type="cylinder" fromto="0 -0.032 0  0 0.032 0"
            size="0.065" mass="0.38" material="brass"/>
      <geom name="axle" type="cylinder" fromto="0 -0.042 0  0 0.042 0"
            size="0.014" mass="0.03" material="axle_mat"/>
{wrap_xml}
      <site name="string_on_spool" pos="{string_site_x:.5f} 0 {string_site_z:.5f}" size="0.004"/>
    </body>

  <!-- Mocap hand: render.py ramps mocap_x along +x. -->
    <body name="pull_hand" mocap="true" pos="0.30 0 0.020">
      <geom type="sphere" size="0.034" material="hand_blue" contype="0" conaffinity="0"/>
      <site name="anchor" pos="0.038 0 0" size="0.004"/>
    </body>

    <camera name="cam" pos="0.20 -0.88 0.15" fovy="34"
            xyaxes="0.98 0.18 0   0.04 0.22 0.975"/>
  </worldbody>

  <tendon>
    <spatial name="string" width="0.0045" rgba="0.22 0.20 0.18 1"
             limited="true" range="0.18 0.52"
             stiffness="280" damping="14" springlength="0.44">
      <site site="string_on_spool"/>
      <site site="anchor"/>
    </spatial>
  </tendon>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "spool_with_string.xml")
with open(out_path, "w") as f:
    f.write(xml)
print(f"Wrote {out_path}  ({N_WRAPS} wraps x {WRAP_SEGS} segs)")
