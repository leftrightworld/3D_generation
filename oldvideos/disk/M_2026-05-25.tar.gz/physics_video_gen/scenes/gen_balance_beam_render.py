"""Render balance beam: slow damped return to horizontal equilibrium."""
import math
import os

import imageio.v2 as imageio
import mujoco

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SCENE = "scenes/balance_beam_lever.xml"
OUT = "out/scenes/balance_beam_lever.mp4"

INIT_TILT = 0.17
OMEGA = 2.1
DECAY = 0.38


def main():
    model = mujoco.MjModel.from_xml_path(SCENE)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, 1080, 1920)
    fps = 30
    duration = 6.0
    dt = model.opt.timestep
    spf = max(1, int(round((1.0 / fps) / dt)))

    frames = []
    t = 0.0
    for _ in range(int(duration * fps)):
        theta = INIT_TILT * math.exp(-DECAY * t) * math.cos(OMEGA * t)
        data.qpos[0] = theta
        data.qvel[0] = 0.0
        mujoco.mj_forward(model, data)
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())
        t += spf * dt

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    imageio.mimsave(OUT, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {OUT}  (tilt {INIT_TILT:.2f} rad, {duration}s slow decay)")


if __name__ == "__main__":
    main()
