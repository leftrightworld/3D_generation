"""Render trifilar pendulum: visible torsional oscillation, full-frame camera."""
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SCENE = "scenes/trifilar_pendulum.xml"
OUT = "out/scenes/trifilar_pendulum.mp4"
GRID = "out/trifilar_pendulum_grid.png"

INIT_QPOS = 0.45


def trifilar_camera():
    cam = mujoco.MjvCamera()
    cam.type = mujoco.mjtCamera.mjCAMERA_FREE
    cam.lookat[:] = [0.0, 0.18, 1.05]
    cam.distance = 3.4
    cam.azimuth = 115.0
    cam.elevation = -15.0
    return cam


def main():
    model = mujoco.MjModel.from_xml_path(SCENE)
    data = mujoco.MjData(model)
    data.qpos[0] = INIT_QPOS
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, 1080, 1920)
    cam = trifilar_camera()
    fps = 30
    duration = 4.0
    spf = max(1, int(round((1.0 / fps) / model.opt.timestep)))

    frames = []
    for _ in range(int(duration * fps)):
        for _ in range(spf):
            mujoco.mj_step(model, data)
        renderer.update_scene(data, camera=cam)
        frames.append(renderer.render())

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    imageio.mimsave(OUT, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {OUT}  (init yaw={INIT_QPOS} rad)")

    d2 = mujoco.MjData(model)
    d2.qpos[0] = INIT_QPOS
    mujoco.mj_forward(model, d2)
    total = int(duration / model.opt.timestep)
    targets = [int(total * k / 7) for k in range(8)]
    imgs, step, gi = [], 0, 0
    while gi < 8:
        mujoco.mj_step(model, d2)
        step += 1
        if step >= targets[gi]:
            renderer.update_scene(d2, camera=cam)
            imgs.append(renderer.render())
            gi += 1

    h, w = imgs[0].shape[:2]
    canvas = np.zeros((h * 2, w * 4, 3), dtype=np.uint8)
    for idx, im in enumerate(imgs):
        r, c = idx // 4, idx % 4
        canvas[r * h:(r + 1) * h, c * w:(c + 1) * w] = im
    imageio.imwrite(GRID, canvas)
    print(f"Wrote {GRID}")


if __name__ == "__main__":
    main()
