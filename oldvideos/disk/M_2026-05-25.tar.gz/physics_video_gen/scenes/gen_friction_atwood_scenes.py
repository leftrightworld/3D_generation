"""Render triple_block, incline_string, double_atwood with proper initial conditions."""
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

SCENE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(SCENE_DIR)

SCENES = {
    "triple_block_friction_chain": {
        "xml": "scenes/triple_block_friction_chain.xml",
        "mp4": "out/scenes/triple_block_friction_chain.mp4",
        "grid": "out/triple_block_friction_chain_grid.png",
        "duration": 2.5,
        "setup": "triple",
    },
    "two_bodies_on_incline_string": {
        "xml": "scenes/two_bodies_on_incline_string.xml",
        "mp4": "out/scenes/two_bodies_on_incline_string.mp4",
        "grid": "out/two_bodies_on_incline_string_grid.png",
        "duration": 3.0,
        "setup": "incline",
    },
    "double_atwood": {
        "xml": "scenes/double_atwood.xml",
        "mp4": "out/scenes/double_atwood.mp4",
        "grid": "out/double_atwood_grid.png",
        "duration": 3.5,
        "setup": "atwood",
    },
}


def setup_triple(model, data):
    pass


# (time, slide_bot, slide_mid_rel, slide_top_rel)
# mid/top negative rel = shear backward on stack; return to 0 = catch up
TRIPLE_KEYS = (
    (0.00, 0.00, 0.000, 0.000),
    (0.25, 0.08, -0.038, -0.010),
    (0.55, 0.18, -0.028, -0.018),
    (0.90, 0.28, -0.010, -0.006),
    (1.30, 0.36, 0.000, 0.000),
    (2.50, 0.52, 0.000, 0.000),
)


def _interp_keys(keys, t):
    if t <= keys[0][0]:
        return keys[0][1:]
    if t >= keys[-1][0]:
        return keys[-1][1:]
    for (t0, b0, m0, p0), (t1, b1, m1, p1) in zip(keys, keys[1:]):
        if t0 <= t <= t1:
            u = (t - t0) / (t1 - t0)
            return (
                b0 + u * (b1 - b0),
                m0 + u * (m1 - m0),
                p0 + u * (p1 - p0),
            )
    return keys[-1][1:]


def advance_triple(model, data, dt):
    """Keyframe friction-chain: bottom leads, middle then top catch up and align."""
    bot_j = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "slide_bot")
    mid_j = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "slide_mid")
    top_j = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "slide_top")
    bot_q = model.jnt_qposadr[bot_j]
    mid_q = model.jnt_qposadr[mid_j]
    top_q = model.jnt_qposadr[top_j]
    bot_v = model.jnt_dofadr[bot_j]
    mid_v = model.jnt_dofadr[mid_j]
    top_v = model.jnt_dofadr[top_j]

    t1 = data.time + dt
    b1, m1, p1 = _interp_keys(TRIPLE_KEYS, t1)
    b0, m0, p0 = _interp_keys(TRIPLE_KEYS, data.time)
    data.qpos[bot_q] = b1
    data.qpos[mid_q] = m1
    data.qpos[top_q] = p1
    data.qvel[bot_v] = (b1 - b0) / dt
    data.qvel[mid_v] = (m1 - m0) / dt
    data.qvel[top_v] = (p1 - p0) / dt
    data.time = t1
    mujoco.mj_forward(model, data)


def setup_incline(model, data):
    pass


def setup_atwood(model, data):
    # Main: red (heavy) starts higher, carrier lower. Inner: yellow down, blue up.
    for name, val in [
        ("j_left", 0.07),
        ("j_carrier", -0.07),
        ("j_r1", -0.05),
        ("j_r2", 0.05),
    ]:
        jid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        data.qpos[model.jnt_qposadr[jid]] = val


SETUPS = {"triple": setup_triple, "incline": setup_incline, "atwood": setup_atwood}


def step_scene(model, data, setup_name, dt):
    if setup_name == "triple":
        advance_triple(model, data, dt)
    else:
        mujoco.mj_step(model, data)


def render_mp4(cfg, fps=30, width=1920, height=1080):
    model = mujoco.MjModel.from_xml_path(cfg["xml"])
    data = mujoco.MjData(model)
    SETUPS[cfg["setup"]](model, data)
    mujoco.mj_forward(model, data)
    renderer = mujoco.Renderer(model, height=height, width=width)
    steps = max(1, int(round((1.0 / fps) / model.opt.timestep)))
    frame_dt = steps * model.opt.timestep
    frames = []
    for _ in range(int(round(cfg["duration"] * fps))):
        for _ in range(steps):
            step_scene(model, data, cfg["setup"], model.opt.timestep)
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())
    os.makedirs(os.path.dirname(cfg["mp4"]) or ".", exist_ok=True)
    imageio.mimsave(cfg["mp4"], frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {cfg['mp4']}")


def render_grid(cfg, cols=4, rows=2, width=480, height=270):
    model = mujoco.MjModel.from_xml_path(cfg["xml"])
    data = mujoco.MjData(model)
    SETUPS[cfg["setup"]](model, data)
    mujoco.mj_forward(model, data)
    renderer = mujoco.Renderer(model, height=height, width=width)
    total = int(round(cfg["duration"] / model.opt.timestep))
    targets = [int(round((i + 1) * total / (cols * rows))) for i in range(cols * rows)]
    cells, idx = [], 0
    for step in range(1, total + 1):
        step_scene(model, data, cfg["setup"], model.opt.timestep)
        if idx < len(targets) and step >= targets[idx]:
            renderer.update_scene(data, camera="cam")
            cells.append(renderer.render())
            idx += 1
    while len(cells) < cols * rows:
        renderer.update_scene(data, camera="cam")
        cells.append(renderer.render())
    grid = np.concatenate(
        [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)], axis=0
    )
    os.makedirs(os.path.dirname(cfg["grid"]) or ".", exist_ok=True)
    imageio.imwrite(cfg["grid"], grid)
    print(f"Wrote {cfg['grid']}")


def main():
    os.chdir(ROOT)
    for key in ("triple_block_friction_chain", "double_atwood"):
        cfg = SCENES[key]
        print(f"=== {cfg['xml']} ===")
        render_mp4(cfg)
        render_grid(cfg)


if __name__ == "__main__":
    main()
