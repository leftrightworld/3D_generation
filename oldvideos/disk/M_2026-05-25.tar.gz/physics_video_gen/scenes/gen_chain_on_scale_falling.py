"""Chain released from ceiling weld — links land on scale one after another."""
import os
import sys

import imageio.v2 as imageio
import mujoco
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from chain_build import build_chain_tree_no_root_free, init_chain_hinges, scale_hang_path

SCENE_DIR = os.path.dirname(os.path.abspath(__file__))
XML_NAME = "chain_on_scale_falling.xml"

N = 26
LINK_LEN = 0.014
LINK_R = 0.006
MASS = 0.009
HANG_Z = 0.42
SCALE_Z = 0.068


def build_xml() -> str:
    chain = build_chain_tree_no_root_free(
        N, LINK_LEN, LINK_R, MASS, indent=4,
        root_pos=(0.0, 0.0, HANG_Z), alt_material="link_alt",
    )
    return f"""<mujoco model="chain_on_scale_falling">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="6" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="scale" rgba="0.78 0.65 0.40 1" specular="0.2" shininess="0.25"/>
    <material name="scale_base" rgba="0.55 0.50 0.48 1" specular="0.15" shininess="0.2"/>
    <material name="link" rgba="0.55 0.50 0.48 1" specular="0.25" shininess="0.25"/>
    <material name="link_alt" rgba="0.86 0.32 0.30 1" specular="0.25" shininess="0.25"/>
    <material name="anchor" rgba="0.30 0.28 0.30 1" specular="0.3" shininess="0.3"/>
  </asset>

  <default>
    <geom friction="0.42 0.02 0.001" solref="0.003 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>
    <geom type="box" pos="0 0 0.028" size="0.11 0.08 0.028" material="scale_base"
          contype="0" conaffinity="0"/>
    <geom type="sphere" pos="0 0 {HANG_Z + 0.015:.3f}" size="0.009" material="anchor"
          contype="0" conaffinity="0"/>

    <body name="scale" pos="0 0 {SCALE_Z}">
      <joint name="scale_z" type="slide" axis="0 0 1" stiffness="220" damping="14"
             limited="true" range="-0.030 0.030"/>
      <geom name="scale_plate" type="box" size="0.17 0.11 0.013" mass="0.75" material="scale"/>
    </body>

{chain}

    <camera name="cam" pos="0 -1.35 0.19" fovy="50"
            xyaxes="1 0 0   0 0 1"/>
  </worldbody>

  <equality>
    <weld name="chain_hold" body1="link0" relpose="0 0 0 1 0 0 0" solref="0.002 1"/>
  </equality>
</mujoco>
"""


def setup_sim(model, data):
    init_chain_hinges(model, data, scale_hang_path(N, LINK_LEN, HANG_Z))


def render_mp4(xml_path, out_path, duration=2.0, fps=30):
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    setup_sim(model, data)
    weld_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_EQUALITY, "chain_hold")
    scale_j = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "scale_z")
    scale_adr = model.jnt_qposadr[scale_j]
    data.eq_active[weld_id] = 1
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, 1080, 1920)
    steps = max(1, int(round((1.0 / fps) / model.opt.timestep)))
    released = False
    min_scale = 0.0
    frames = []
    for fi in range(int(round(duration * fps))):
        if fi == 1 and not released:
            data.eq_active[weld_id] = 0
            released = True
        for _ in range(steps):
            mujoco.mj_step(model, data)
        min_scale = min(min_scale, data.qpos[scale_adr])
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())
    print(f"  scale dip={min_scale:.4f} m")
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    imageio.mimsave(out_path, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {out_path}")


def render_grid(xml_path, out_path, duration=2.0, cols=4, rows=2):
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    setup_sim(model, data)
    weld_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_EQUALITY, "chain_hold")
    renderer = mujoco.Renderer(model, 270, 480)
    total = int(round(duration / model.opt.timestep))
    targets = [int(round((i + 1) * total / (cols * rows))) for i in range(cols * rows)]
    cells, idx = [], 0
    for step in range(1, total + 1):
        if step == 2:
            data.eq_active[weld_id] = 0
        mujoco.mj_step(model, data)
        if idx < len(targets) and step >= targets[idx]:
            renderer.update_scene(data, camera="cam")
            cells.append(renderer.render())
            idx += 1
    while len(cells) < cols * rows:
        renderer.update_scene(data, camera="cam")
        cells.append(renderer.render())
    grid = np.concatenate(
        [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)], axis=0
    )
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    imageio.imwrite(out_path, grid)
    print(f"Wrote {out_path}")


def main():
    os.chdir(os.path.dirname(SCENE_DIR))
    xml_path = os.path.join("scenes", XML_NAME)
    with open(xml_path, "w", encoding="utf-8") as f:
        f.write(build_xml())
    print(f"Wrote {xml_path}")
    render_mp4(xml_path, "out/scenes/chain_on_scale_falling.mp4")
    render_grid(xml_path, "out/chain_on_scale_falling_grid.png")


if __name__ == "__main__":
    main()
