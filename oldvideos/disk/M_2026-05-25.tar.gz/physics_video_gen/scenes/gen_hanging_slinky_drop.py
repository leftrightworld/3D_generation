"""
Procedurally generate scenes/hanging_slinky_drop.xml: a vertical slinky
discretized into N links joined by stiff slide springs, with visible coil
loops.  Top link is free at release; bottom stays nearly still until the
collapse wave arrives.
"""
import math
import os

try:
    import mujoco
except ImportError:
    mujoco = None

N = 24
SEG_L = 0.038
LINK_R = 0.006
LINK_M = 0.010
COIL_R = 0.034
K_SPRING = 52.0
D_SPRING = 0.50
ANCHOR_Z = 1.72

COLORS = ["link_warm", "link_gold", "link_coral", "link_teal"]


def link_body(i):
    indent = "      " + "  " * i
    mat = COLORS[i % len(COLORS)]
    parts = []
    if i > 0:
        parts.append(
            f'{indent}<joint name="s{i}" type="slide" axis="0 0 1" '
            f'stiffness="{K_SPRING}" damping="{D_SPRING}" '
            f'range="-{SEG_L * 0.35:.4f} {SEG_L * 0.35:.4f}" springref="0"/>'
        )
    # Thin core + horizontal coil loop (visible from side view).
    x0 = COIL_R if i % 2 == 0 else -COIL_R
    x1 = -x0
    parts.append(
        f'{indent}<geom name="core{i}" type="capsule" '
        f'fromto="0 0 {LINK_R:.4f}  0 0 -{LINK_R:.4f}" '
        f'size="{LINK_R * 0.45:.4f}" material="{mat}" mass="{LINK_M * 0.35:.4f}"/>'
    )
    parts.append(
        f'{indent}<geom name="coil{i}" type="capsule" '
        f'fromto="{x0:.4f} 0 0  {x1:.4f} 0 0" size="0.0110" '
        f'material="coil_metal" mass="{LINK_M * 0.65:.4f}"/>'
    )
    if i < N - 1:
        child = (
            f'{indent}<body name="link{i + 1}" pos="0 0 -{SEG_L:.4f}">\n'
            f"{link_body(i + 1)}\n"
            f"{indent}</body>"
        )
        parts.append(child)
    return "\n".join(parts)


chain_xml = link_body(0)
chain_bottom_z = ANCHOR_Z - (N - 1) * SEG_L - COIL_R
# Side-view camera centred on the full hanging + falling span (top to floor).
cam_z = ANCHOR_Z * 0.48

xml = f"""<mujoco model="hanging_slinky_drop">
  <!-- Discretized slinky: {N} coil links on stiff vertical slide springs.
       Top link is free at release; collapse wave leaves the bottom still
       for a short time (classic slinky drop). -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="36"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="frame_wood" rgba="0.78 0.65 0.40 1" specular="0.12" shininess="0.15"/>
    <material name="coil_metal" rgba="0.78 0.80 0.84 1" specular="0.55" shininess="0.65"/>
    <material name="link_warm" rgba="0.92 0.74 0.36 1" specular="0.35" shininess="0.45"/>
    <material name="link_gold" rgba="0.95 0.82 0.28 1" specular="0.35" shininess="0.45"/>
    <material name="link_coral" rgba="0.90 0.48 0.42 1" specular="0.35" shininess="0.45"/>
    <material name="link_teal"  rgba="0.36 0.72 0.68 1" specular="0.35" shininess="0.45"/>
  </asset>

  <default>
    <geom friction="0.4 0.04 0.001" solref="0.005 1" solimp="0.95 0.99 0.001"
          contype="1" conaffinity="1"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <body name="link0" pos="0 0 {ANCHOR_Z:.4f}">
      <freejoint name="top_free"/>
{chain_xml}
    </body>

  <camera name="cam" pos="0.00 -2.05 {cam_z:.3f}" fovy="46"
            xyaxes="1 0 0   0 0.08 0.997"/>
  </worldbody>
</mujoco>
"""


def settle_hanging_qpos(model_xml):
    fallback = ["0", "0", f"{ANCHOR_Z:.4f}", "1", "0", "0", "0"] + ["0"] * (N - 1)
    if mujoco is None:
        return fallback
    eq_xml = model_xml.replace('<freejoint name="top_free"/>', "")
    eq_xml = eq_xml.replace(
        "  </worldbody>",
        "  </worldbody>\n\n"
        "  <equality>\n"
        f'    <weld body1="world" body2="link0" relpose="0 0 {ANCHOR_Z:.4f} 1 0 0 0"/>\n'
        "  </equality>",
    )
    m = mujoco.MjModel.from_xml_string(eq_xml)
    d = mujoco.MjData(m)
    for _ in range(5000):
        mujoco.mj_step(m, d)
    slides = [f"{v:.6f}" for v in d.qpos[: N - 1]]
    return ["0", "0", f"{ANCHOR_Z:.6f}", "1", "0", "0", "0"] + slides


out_path = os.path.join(os.path.dirname(__file__), "hanging_slinky_drop.xml")
with open(out_path, "w", encoding="utf-8") as f:
    f.write(xml)

init_qpos = ",".join(settle_hanging_qpos(xml))
print(f"Wrote {out_path}  (N={N}, z_top={ANCHOR_Z:.2f}, z_bottom≈{chain_bottom_z:.2f})")
print(f'Suggested: --duration 2.0 --init-qpos "{init_qpos}"')
print("Suggested init-qvel: all zeros (default)")
