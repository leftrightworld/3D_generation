"""Generate rolling_disc_inscribes_cycloid.xml and render with runtime cycloid trail.

The cycloid is drawn incrementally during simulation by projecting past rim-marker
positions as red dots each frame.  The rim marker is a massless site (no effect on
disc dynamics).
"""
import argparse
import math
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

R = 0.10
X0 = 0.12
VX = 0.6
OMEGA = 6.0  # wy for rolling without slip in +x (MuJoCo right-hand rule)

SCENE_DIR = os.path.dirname(os.path.abspath(__file__))
XML_NAME = "rolling_disc_inscribes_cycloid.xml"

INIT_QVEL = [VX, 0.0, 0.0, 0.0, OMEGA, 0.0]


def write_xml(path: str | None = None) -> str:
    if path is None:
        path = os.path.join(SCENE_DIR, XML_NAME)
    xml = f"""<mujoco model="rolling_disc_inscribes_cycloid">
  <!-- Thin disc rolling without slip; rim site traces cycloid (trail drawn at render). -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="disc_mat" rgba="0.92 0.78 0.36 1" specular="0.4" shininess="0.55"/>
  </asset>

  <default>
    <geom friction="0.55 0.02 0.001" solref="0.005 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

  <!-- Disc axis +y, rolls in +x; rim marker is a site (zero mass, visual only) -->
    <body name="disc" pos="{X0} 0 {R}">
      <freejoint/>
      <geom name="disc_geom" type="cylinder" size="{R} 0.012" mass="0.5"
            material="disc_mat" euler="1.5708 0 0"/>
      <site name="rim_marker" pos="{R} 0 0" size="0.014"
            rgba="0.86 0.32 0.30 1"/>
    </body>

    <camera name="cam" pos="0.8 -2.0 0.22" fovy="42"
            xyaxes="1 0 0   0 0 1"/>
  </worldbody>
</mujoco>
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"Wrote {path}")
    return path


def _setup_model_data(xml_path: str, init_qvel=None):
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    if init_qvel:
        for i, v in enumerate(init_qvel):
            if i < model.nv:
                data.qvel[i] = v
    mujoco.mj_forward(model, data)
    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "rim_marker")
    return model, data, site_id


def _append_trail_geoms(scene, trail, dot_size=0.0045,
                        rgba=(0.86, 0.32, 0.30, 0.75)):
    mat = np.eye(3).flatten()
    for pt in trail:
        if scene.ngeom >= scene.maxgeom:
            break
        g = scene.geoms[scene.ngeom]
        mujoco.mjv_initGeom(
            g,
            type=mujoco.mjtGeom.mjGEOM_SPHERE,
            size=[dot_size, 0.0, 0.0],
            pos=pt,
            mat=mat,
            rgba=list(rgba),
        )
        scene.ngeom += 1


def render_with_trail(
    xml_path: str,
    output_path: str,
    duration: float = 4.0,
    fps: int = 30,
    width: int = 1920,
    height: int = 1080,
    init_qvel=None,
    camera: str = "cam",
    trail_stride: int = 2,
) -> None:
    model, data, site_id = _setup_model_data(xml_path, init_qvel)
    renderer = mujoco.Renderer(model, height=height, width=width)

    sim_dt = model.opt.timestep
    steps_per_frame = max(1, int(round((1.0 / fps) / sim_dt)))
    n_frames = int(round(duration * fps))

    trail = []
    frames = []
    for _ in range(n_frames):
        for step in range(steps_per_frame):
            mujoco.mj_step(model, data)
            if step % trail_stride == 0:
                trail.append(data.site_xpos[site_id].copy())

        renderer.update_scene(data, camera=camera)
        _append_trail_geoms(renderer.scene, trail)
        frames.append(renderer.render())

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    imageio.mimsave(output_path, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {output_path}  ({len(frames)} frames @ {fps} fps, {width}x{height})")


def render_grid_with_trail(
    xml_path: str,
    output_path: str,
    duration: float = 4.0,
    cols: int = 4,
    rows: int = 2,
    width: int = 480,
    height: int = 270,
    init_qvel=None,
    camera: str = "cam",
    trail_stride: int = 2,
) -> None:
    model, data, site_id = _setup_model_data(xml_path, init_qvel)
    renderer = mujoco.Renderer(model, height=height, width=width)

    n_cells = cols * rows
    total_steps = int(round(duration / model.opt.timestep))
    step_targets = [int(round((i + 1) * total_steps / n_cells)) for i in range(n_cells)]

    trail = []
    cell_images = []
    target_idx = 0
    for step in range(1, total_steps + 1):
        mujoco.mj_step(model, data)
        if step % trail_stride == 0:
            trail.append(data.site_xpos[site_id].copy())

        if target_idx < n_cells and step >= step_targets[target_idx]:
            renderer.update_scene(data, camera=camera)
            _append_trail_geoms(renderer.scene, trail)
            cell_images.append(renderer.render())
            target_idx += 1

    while len(cell_images) < n_cells:
        renderer.update_scene(data, camera=camera)
        _append_trail_geoms(renderer.scene, trail)
        cell_images.append(renderer.render())

    row_imgs = []
    for r in range(rows):
        row_imgs.append(np.concatenate(cell_images[r * cols:(r + 1) * cols], axis=1))
    grid = np.concatenate(row_imgs, axis=0)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    imageio.imwrite(output_path, grid)
    times = [round(duration * (i + 1) / n_cells, 2) for i in range(n_cells)]
    print(f"Wrote {output_path}  ({rows}x{cols} grid, times: {', '.join(f'{t:.2f}s' for t in times)})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-render", action="store_true", help="Only write XML")
    ap.add_argument("--duration", type=float, default=4.0)
    args = ap.parse_args()

    write_xml()
    if args.no_render:
        return

    # MuJoCo needs relative paths under physics_video_gen (Chinese path workaround)
    xml_rel = os.path.join("scenes", XML_NAME)
    out_mp4 = os.path.join("out", "scenes", "rolling_disc_inscribes_cycloid.mp4")
    out_grid = os.path.join("out", "rolling_disc_inscribes_cycloid_grid.png")

    render_with_trail(
        xml_rel, out_mp4,
        duration=args.duration, init_qvel=INIT_QVEL, trail_stride=2,
    )
    render_grid_with_trail(
        xml_rel, out_grid,
        duration=args.duration, init_qvel=INIT_QVEL, trail_stride=2,
    )


if __name__ == "__main__":
    main()
