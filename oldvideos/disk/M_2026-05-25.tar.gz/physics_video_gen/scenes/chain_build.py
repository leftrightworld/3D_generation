"""Articulated chain helpers — path-based init for side-view (xz) scenes."""
from __future__ import annotations

import math

import mujoco
import numpy as np


def build_chain_tree(
    n: int,
    link_len: float,
    link_r: float,
    mass: float,
    material: str = "link",
    joint: str = "hinge",
    indent: int = 4,
    root_material: str | None = None,
    alt_material: str | None = None,
) -> str:
    pad = " " * indent

    def body(i: int, depth: int) -> str:
        sp = pad + "  " * depth
        mat = root_material if i == 0 and root_material else (
            alt_material if alt_material and i % 2 == 1 else material
        )
        if i == 0:
            head = f'{sp}<body name="link0" pos="0 0 0">\n{sp}  <freejoint name="chain_top"/>\n'
        else:
            head = f'{sp}<body name="link{i}" pos="0 0 {-link_len:.4f}">\n'
            if joint == "ball":
                head += f'{sp}  <joint name="j{i}" type="ball" damping="0.006"/>\n'
            else:
                head += f'{sp}  <joint name="j{i}" type="hinge" axis="0 1 0" damping="0.006"/>\n'
        geom = (
            f'{sp}  <geom type="capsule" name="g{i}" '
            f'fromto="0 0 0  0 0 {-link_len:.4f}" size="{link_r}" mass="{mass}" '
            f'material="{mat}"/>\n'
            f'{sp}  <geom type="sphere" pos="0 0 {-link_len:.4f}" size="{link_r * 1.35:.4f}" '
            f'mass="0" material="{mat}" contype="0" conaffinity="0"/>\n'
        )
        if i + 1 >= n:
            return head + geom + f"{sp}</body>\n"
        return head + geom + body(i + 1, depth + 1) + f"{sp}</body>\n"

    return body(0, 0)


def build_chain_tree_no_root_free(
    n: int,
    link_len: float,
    link_r: float,
    mass: float,
    material: str = "link",
    indent: int = 4,
    root_pos: tuple[float, float, float] = (0.0, 0.0, 0.0),
    alt_material: str | None = None,
) -> str:
    pad = " " * indent

    def body(i: int, depth: int) -> str:
        sp = pad + "  " * depth
        mat = alt_material if alt_material and i % 2 == 1 else material
        if i == 0:
            head = f'{sp}<body name="link0" pos="{root_pos[0]:.4f} {root_pos[1]:.4f} {root_pos[2]:.4f}">\n'
        else:
            head = (
                f'{sp}<body name="link{i}" pos="0 0 {-link_len:.4f}">\n'
                f'{sp}  <joint name="j{i}" type="hinge" axis="0 1 0" damping="0.005"/>\n'
            )
        geom = (
            f'{sp}  <geom type="capsule" name="g{i}" '
            f'fromto="0 0 0  0 0 {-link_len:.4f}" size="{link_r}" mass="{mass}" '
            f'material="{mat}"/>\n'
            f'{sp}  <geom type="sphere" pos="0 0 {-link_len:.4f}" size="{link_r * 1.45:.4f}" '
            f'mass="0" material="{mat}" contype="0" conaffinity="0"/>\n'
        )
        if i + 1 >= n:
            return head + geom + f"{sp}</body>\n"
        return head + geom + body(i + 1, depth + 1) + f"{sp}</body>\n"

    return body(0, 0)


def joint_qpos_indices(model: mujoco.MjModel) -> list[tuple[str, int, int]]:
    return [
        (
            mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_JOINT, i) or f"j{i}",
            model.jnt_qposadr[i],
            model.jnt_type[i],
        )
        for i in range(model.njnt)
    ]


def _heading_xz(v: np.ndarray) -> float:
    return math.atan2(float(v[0]), float(-v[2]))


def _y_quat(angle: float) -> np.ndarray:
    return np.array([math.cos(angle / 2), 0.0, math.sin(angle / 2), 0.0])


def init_chain_path(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    waypoints: list[tuple[float, float, float]],
    settle: int = 120,
) -> None:
    """Place hinge chain along waypoints[0..n] (n = number of links)."""
    wps = np.array(waypoints, dtype=float)
    n_links = len(wps) - 1
    data.qpos[:] = 0.0
    data.qvel[:] = 0.0

    d0 = wps[1] - wps[0]
    d0 /= np.linalg.norm(d0) + 1e-12
    data.qpos[0:3] = wps[0]
    data.qpos[3:7] = _y_quat(_heading_xz(d0))

    hinges = [
        adr
        for _, adr, jtype in joint_qpos_indices(model)
        if jtype == int(mujoco.mjtJoint.mjJNT_HINGE)
    ]
    for i in range(1, n_links):
        vin = wps[i] - wps[i - 1]
        vout = wps[i + 1] - wps[i]
        vin /= np.linalg.norm(vin) + 1e-12
        vout /= np.linalg.norm(vout) + 1e-12
        theta = _heading_xz(vout) - _heading_xz(vin)
        theta = (theta + math.pi) % (2 * math.pi) - math.pi
        data.qpos[hinges[i - 1]] = theta

    mujoco.mj_forward(model, data)
    for _ in range(settle):
        mujoco.mj_step(model, data)


def resample_polyline(points: list[tuple[float, float, float]], n_links: int, link_len: float) -> list[tuple[float, float, float]]:
    """Sample n_links+1 waypoints along a polyline at ~link_len spacing."""
    dense: list[np.ndarray] = []
    for a, b in zip(points, points[1:]):
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        seg = b - a
        steps = max(1, int(math.ceil(np.linalg.norm(seg) / (link_len * 0.95))))
        for k in range(steps):
            dense.append(a + seg * (k / steps))
    dense.append(np.array(points[-1], dtype=float))

    # arc-length resample
    arc = [0.0]
    for i in range(1, len(dense)):
        arc.append(arc[-1] + np.linalg.norm(dense[i] - dense[i - 1]))
    total = arc[-1]
    targets = [i * total / n_links for i in range(n_links + 1)]
    out: list[tuple[float, float, float]] = []
    j = 0
    for t in targets:
        while j + 1 < len(arc) and arc[j + 1] < t:
            j += 1
        if j + 1 >= len(arc):
            out.append(tuple(dense[-1]))
            continue
        u = (t - arc[j]) / max(arc[j + 1] - arc[j], 1e-9)
        p = dense[j] + u * (dense[j + 1] - dense[j])
        out.append((float(p[0]), float(p[1]), float(p[2])))
    return out


def fountain_path(n: int, link_len: float) -> list[tuple[float, float, float]]:
    """Side-view path: pull high-right, outside leg down, arch crest, coil in beaker."""
    poly = [
        (0.118, 0.0, 0.32),
        (0.118, 0.0, 0.14),
        (0.118, 0.0, 0.072),
        (0.098, 0.0, 0.26),
        (0.062, 0.0, 0.29),
        (0.028, 0.0, 0.21),
        (0.000, 0.0, 0.14),
        (-0.018, 0.0, 0.10),
        (0.022, 0.0, 0.082),
        (-0.012, 0.0, 0.074),
        (0.015, 0.0, 0.068),
    ]
    return resample_polyline(poly, n, link_len)


def pile_path(n: int, link_len: float) -> list[tuple[float, float, float]]:
    """Lift point high; short vertical; dense pile on table (bottom stays put)."""
    poly = [
        (0.0, 0.0, 0.30),
        (0.0, 0.0, 0.20),
        (0.0, 0.0, 0.13),
        (0.0, 0.0, 0.095),
    ]
    for k in range(14):
        poly.append((0.028 * (1 if k % 2 == 0 else -1), 0.0, 0.078 + 0.001 * (k % 3)))
    poly.append((0.0, 0.0, 0.076))
    return resample_polyline(poly, n, link_len)


def scale_hang_path(n: int, link_len: float, z_top: float) -> list[tuple[float, float, float]]:
    """Vertical first link; upper accordion then straight hang to scale."""
    pts: list[tuple[float, float, float]] = [(0.0, 0.0, z_top)]
    z = z_top
    for i in range(1, n + 1):
        if i == 1:
            z -= link_len
            pts.append((0.0, 0.0, z))
        elif i <= max(3, n // 3):
            z -= link_len * 0.84
            pts.append((0.012 * (1 if i % 2 else -1), 0.0, z))
        else:
            z -= link_len * 0.98
            pts.append((0.0, 0.0, z))
    return pts


def top_freejoint_qvel_slice(model: mujoco.MjModel) -> slice:
    adr = model.jnt_dofadr[0]
    return slice(adr, adr + 6)


def last_body_id(model: mujoco.MjModel) -> int:
    for i in range(model.nbody - 1, 0, -1):
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, i) or ""
        if name.startswith("link"):
            return i
    return model.nbody - 1


def init_chain_hinges(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    waypoints: list[tuple[float, float, float]],
) -> None:
    """Set hinge angles only (root body fixed in XML). First link must be vertical (-z)."""
    wps = np.array(waypoints, dtype=float)
    n_links = len(wps) - 1
    data.qpos[:] = 0.0
    data.qvel[:] = 0.0
    hinges = [
        adr
        for _, adr, jtype in joint_qpos_indices(model)
        if jtype == int(mujoco.mjtJoint.mjJNT_HINGE)
    ]
    for i in range(1, n_links):
        vin = wps[i] - wps[i - 1]
        vout = wps[i + 1] - wps[i]
        vin /= np.linalg.norm(vin) + 1e-12
        vout /= np.linalg.norm(vout) + 1e-12
        theta = _heading_xz(vout) - _heading_xz(vin)
        theta = (theta + math.pi) % (2 * math.pi) - math.pi
        data.qpos[hinges[i - 1]] = theta
    mujoco.mj_forward(model, data)


def build_chain_tree_mocap(
    n: int,
    link_len: float,
    link_r: float,
    mass: float,
    hand_pos: tuple[float, float, float],
    material: str = "link",
    indent: int = 4,
    root_material: str | None = None,
    alt_material: str | None = None,
) -> str:
    hx, hy, hz = hand_pos
    chain = build_chain_tree_no_root_free(
        n, link_len, link_r, mass, material=material, indent=indent,
        root_pos=hand_pos, alt_material=alt_material,
    )
    if root_material:
        chain = chain.replace('material="link"', f'material="{root_material}"', 1)
    return (
        f'    <body name="hand" mocap="true" pos="{hx:.4f} {hy:.4f} {hz:.4f}"/>\n'
        f"{chain}"
    )


def mocap_id(model: mujoco.MjModel, name: str = "hand") -> int:
    bid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)
    return model.body_mocapid[bid]


def move_hand_z(model: mujoco.MjModel, data: mujoco.MjData, z: float, name: str = "hand") -> None:
    mid = mocap_id(model, name)
    data.mocap_pos[mid][2] = z
