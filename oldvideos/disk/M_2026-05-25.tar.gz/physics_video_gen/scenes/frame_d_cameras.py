"""Compute motion bounds and suggest centered camera for D-assignment scenes."""
import os
import re
import mujoco
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCENES_DIR = os.path.join(ROOT, "scenes")

SCENE_CONFIG = {
    "cycloidal_pendulum_huygens": {"dur": 4.0, "qpos": [0.55], "qvel": [], "ctrl": {}},
    "rolling_chain": {"dur": 5.0, "qpos": [], "qvel": [0.5] + [0] * 19},
    "centrifugal_governor": {"dur": 5.0, "qpos": [], "qvel": [10.0]},
    "pulley_with_inertia": {"dur": 3.0, "qpos": [], "qvel": []},
    "n_body_1d_collisions": {"dur": 2.0, "qpos": [], "qvel": [0] * 36 + [2.5]},
    "block_on_accelerating_wedge": {"dur": 1.5, "qpos": [], "qvel": []},
    "pendulum_with_lateral_spring": {"dur": 12.0, "qpos": [0.4], "qvel": []},
    "hanging_slinky_drop": {"dur": 1.5, "qpos": None, "qvel": []},
    "standing_wave_on_string": {"dur": 4.0, "qpos": None, "qvel": []},
    "belt_friction": {"dur": 4.0, "qpos": [], "qvel": [6.0]},
    "block_on_block_static_friction": {"dur": 2.0, "qpos": [], "qvel": [1.0, 0.0]},
    "tumbling_book": {"dur": 5.0, "qpos": [], "qvel": [0, 0, 0, 0.05, 8, 0, 0.3]},
    "swinging_chain_pendulum": {"dur": 5.0, "qpos": [0.021817] * 24, "qvel": []},
    "bead_in_rotating_ring": {"dur": 4.0, "qpos": [], "qvel": [14.0]},
    "block_and_tackle": {"dur": 3.0, "qpos": [], "qvel": []},
    "cantilever_load_curve": {"dur": 3.0, "qpos": [], "qvel": []},
    "symmetry_breaking_ball_on_dome": {"dur": 2.0, "qpos": [], "qvel": []},
}


def load_init_from_gen(name):
    gen = os.path.join(SCENES_DIR, f"gen_{name}.py")
    if not os.path.isfile(gen):
        return None, None
    import subprocess
    r = subprocess.run(
        ["python", gen], capture_output=True, text=True, cwd=SCENES_DIR
    )
    qpos = qvel = None
    for line in r.stdout.splitlines():
        if "--init-qpos" in line:
            part = line.split('--init-qpos "', 1)
            if len(part) > 1:
                qpos = [float(x) for x in part[1].split('"')[0].split(",")]
        if "--init-qvel" in line and "zeros" not in line:
            part = line.split('--init-qvel "', 1)
            if len(part) > 1:
                qvel = [float(x) for x in part[1].split('"')[0].split(",")]
    return qpos, qvel


def bounds_for_scene(name, cfg):
    path = os.path.join(SCENES_DIR, f"{name}.xml")
    m = mujoco.MjModel.from_xml_path(path)
    d = mujoco.MjData(m)

    qpos = cfg.get("qpos")
    qvel = cfg.get("qvel")
    if qpos is None:
        gp, gv = load_init_from_gen(name)
        qpos = gp or []
        if not qvel and gv:
            qvel = gv
    if qpos:
        for i, v in enumerate(qpos):
            if i < m.nq:
                d.qpos[i] = v
    if qvel:
        for i, v in enumerate(qvel):
            if i < m.nv:
                d.qvel[i] = v

    ctrl = cfg.get("ctrl", {})
    if ctrl and m.nu:
        for i in range(m.nu):
            an = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_ACTUATOR, i)
            if an in ctrl:
                d.ctrl[i] = ctrl[an]

    mujoco.mj_forward(m, d)
    mins = np.array([np.inf, np.inf, np.inf])
    maxs = -mins
    dur = cfg["dur"]
    steps = int(dur / m.opt.timestep)
    skip = max(1, steps // 120)
    for t in range(steps + 1):
        if t % skip == 0 or t == steps:
            for i in range(1, m.nbody):
                p = d.xpos[i]
                mins = np.minimum(mins, p)
                maxs = np.maximum(maxs, p)
        if t < steps:
            if ctrl:
                for i in range(m.nu):
                    an = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_ACTUATOR, i)
                    if an in ctrl:
                        d.ctrl[i] = ctrl[an]
            mujoco.mj_step(m, d)

    center = 0.5 * (mins + maxs)
    extent = max(maxs - mins)
    extent = max(extent, 0.12)
    margin = 0.18
    extent *= 1.0 + margin

    # camera on -y side, look at center
    dist = max(extent * 1.35, 0.55)
    cam_pos = np.array([center[0], center[1] - dist, center[2] + extent * 0.12])
    fovy = float(np.clip(38 + 12 * (extent / dist), 36, 52))
    return center, cam_pos, fovy


def patch_camera(xml_path, cam_pos, fovy):
    with open(xml_path, encoding="utf-8") as f:
        text = f.read()
    new_cam = (
        f'    <camera name="cam" pos="{cam_pos[0]:.3f} {cam_pos[1]:.3f} {cam_pos[2]:.3f}" '
        f'fovy="{fovy:.1f}"\n'
        f'            xyaxes="1 0 0   0 0.12 0.993"/>'
    )
    text, n = re.subn(
        r'    <camera name="cam"[^/]*/>',
        new_cam,
        text,
        count=1,
    )
    if n == 0:
        text, n = re.subn(
            r'    <camera name="cam"[^>]*>[\s\S]*?</camera>',
            new_cam,
            text,
            count=1,
        )
    if n:
        with open(xml_path, "w", encoding="utf-8") as f:
            f.write(text)
    return n > 0


def main():
    for name, cfg in SCENE_CONFIG.items():
        center, cam_pos, fovy = bounds_for_scene(name, cfg)
        path = os.path.join(SCENES_DIR, f"{name}.xml")
        ok = patch_camera(path, cam_pos, fovy)
        print(f"{name}: center={center.round(3)} cam={cam_pos.round(3)} fovy={fovy:.1f} patched={ok}")


if __name__ == "__main__":
    main()
