"""
Generate scenes/domino_branching.xml: Y-shaped domino cascade.
Main arm along +x, then splits into +30 deg and -30 deg branches.
"""
import math
import os

HX, HY, HZ = 0.006, 0.018, 0.045
SPACING = 0.040
TILT_DEG = 10.0
tilt = math.radians(TILT_DEG)
qw = math.cos(tilt * 0.5)
qy = math.sin(tilt * 0.5)

COLOR_CYCLE = ["dom_cream", "dom_peach", "dom_blue", "dom_dark"]

# Branch geometry: main trunk, then Y split (centered near origin for framing).
MAIN_N = 8
BRANCH_N = 10
BRANCH_ANGLE = math.radians(28)
ORIGIN = (-0.32, 0.0)
SPLIT = (ORIGIN[0] + MAIN_N * SPACING, 0.0)


def domino_body(name, x, y, mat, tilted=False):
    if tilted:
        return (
            f'    <body name="{name}" pos="{x:.4f} {y:.4f} {HZ:.4f}" '
            f'quat="{qw:.5f} 0 {qy:.5f} 0">\n'
            f'      <joint type="free"/>\n'
            f'      <geom type="box" size="{HX} {HY} {HZ}" mass="0.025" '
            f'material="{mat}"/>\n'
            f'    </body>'
        )
    return (
        f'    <body name="{name}" pos="{x:.4f} {y:.4f} {HZ:.4f}">\n'
        f'      <joint type="free"/>\n'
        f'      <geom type="box" size="{HX} {HY} {HZ}" mass="0.025" '
        f'material="{mat}"/>\n'
        f'    </body>'
    )


bodies = []
idx = 0

for i in range(MAIN_N):
    x = ORIGIN[0] + i * SPACING
    mat = COLOR_CYCLE[idx % len(COLOR_CYCLE)]
    bodies.append(domino_body(f"d{idx}", x, ORIGIN[1], mat, tilted=(i == 0)))
    idx += 1

for branch_sign, label in ((1, "up"), (-1, "dn")):
    angle = branch_sign * BRANCH_ANGLE
    cos_a, sin_a = math.cos(angle), math.sin(angle)
    for j in range(BRANCH_N):
        dist = (j + 1) * SPACING
        x = SPLIT[0] + dist * cos_a
        y = SPLIT[1] + dist * sin_a
        mat = COLOR_CYCLE[idx % len(COLOR_CYCLE)]
        bodies.append(domino_body(f"d{idx}", x, y, mat))
        idx += 1

bodies_xml = "\n".join(bodies)

xml = f"""<mujoco model="domino_branching">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="2560" offheight="1440" fovy="42"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="dom_cream" rgba="0.96 0.92 0.85 1" specular="0.15" shininess="0.2"/>
    <material name="dom_peach" rgba="0.95 0.78 0.62 1" specular="0.15" shininess="0.2"/>
    <material name="dom_blue"  rgba="0.36 0.58 0.82 1" specular="0.25" shininess="0.3"/>
    <material name="dom_dark"  rgba="0.32 0.30 0.32 1" specular="0.25" shininess="0.3"/>
  </asset>

  <default>
    <geom friction="0.7 0.04 0.001" solref="0.005 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

{bodies_xml}

  <!-- Layout centered on origin; low camera matches domino height -->
    <camera name="cam" pos="0 -0.45 0.18" fovy="52"
            xyaxes="1 0 0   0 0.22 0.975"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "domino_branching.xml")
with open(out_path, "w") as f:
    f.write(xml)
print(f"Wrote {out_path}  ({idx} dominoes, Y-branch)")
