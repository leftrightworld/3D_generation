"""
Generate scenes/bead_on_parabolic_wire.xml: bead sliding on z = a*x^2 wire.
Period depends on feature than cycloid's amplitude-independent period.
"""
import math
import os

A = 0.55          # z = A * x^2  (concave up in +z)
X_MIN, X_MAX = -0.55, 0.55
N_SEG = 36
TRACK_W = 0.10
TRACK_T = 0.010
BALL_R = 0.028
BALL_M = 0.050
START_X = -0.42


def parab_z(x):
    return A * x * x


def parab_slope(x):
    return 2 * A * x


def segment(i):
    t0 = i / N_SEG
    t1 = (i + 1) / N_SEG
    x0 = X_MIN + t0 * (X_MAX - X_MIN)
    x1 = X_MIN + t1 * (X_MAX - X_MIN)
    xm = 0.5 * (x0 + x1)
    zm = parab_z(xm)
    chord = math.hypot(x1 - x0, parab_z(x1) - parab_z(x0)) * 1.08
    slope = parab_slope(xm)
    alpha = math.atan(slope)
    return (
        f'    <geom type="box" pos="{xm:.4f} 0 {zm:.4f}" '
        f'euler="0 {-alpha:.5f} 0" '
        f'size="{chord * 0.5:.4f} {TRACK_W * 0.5} {TRACK_T * 0.5}" '
        f'material="wire_mat"/>'
    )


track_xml = "\n".join(segment(i) for i in range(N_SEG))

z_start = parab_z(START_X)
slope_s = parab_slope(START_X)
alpha_s = math.atan(slope_s)
nx = -math.sin(alpha_s)
nz = math.cos(alpha_s)
ball_x = START_X + BALL_R * nx
ball_z = z_start + BALL_R * nz

xml = f"""<mujoco model="bead_on_parabolic_wire">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.0005" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="wire_mat" rgba="0.78 0.65 0.40 1" specular="0.55" shininess="0.65"/>
    <material name="bead_red" rgba="0.86 0.34 0.30 1" specular="0.55" shininess="0.7"/>
  </asset>

  <default>
    <geom friction="0.04 0.004 0.0001" solref="0.003 1" solimp="0.97 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

{track_xml}

    <body name="bead" pos="{ball_x:.4f} 0 {ball_z:.4f}">
      <freejoint/>
      <geom type="sphere" size="{BALL_R}" mass="{BALL_M}"
            material="bead_red"/>
    </body>

    <camera name="cam" pos="0 -1.55 0.35" fovy="40"
            xyaxes="1 0 0   0 0.15 0.989"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "bead_on_parabolic_wire.xml")
with open(out_path, "w") as f:
    f.write(xml)
print(f"Wrote {out_path}")
