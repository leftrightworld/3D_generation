"""
Generate scenes/pyramid_keystone_removal.xml: 4-1-1-1 pyramid; keystone at
row-1 centre rests on inner base blocks.  render.py settles then slides it +y.
"""
import os

BW, BD, BH = 0.10, 0.08, 0.04
BW_TOP = 0.08
M = 0.08
GAP = 0.0008
FRICTION = "0.8 0.04 0.005"
CONTACT = 'solref="0.003 1" solimp="0.97 0.99 0.001" margin="0.001"'
COLORS = ["brick_warm", "brick_cool"]

bodies = []
bid = 0


def add_block(name, x, z, mat, bw=BW):
    global bid
    bodies.append(
        f'    <body name="{name}" pos="{x:.4f} 0 {z:.4f}">\n'
        f'      <freejoint/>\n'
        f'      <geom type="box" size="{bw} {BD} {BH}" mass="{M}"\n'
        f'            material="{mat}" friction="{FRICTION}" {CONTACT}/>\n'
        f'    </body>'
    )
    bid += 1


ROW0_Z = BH
KEYSTONE_Z = 2 * BH + GAP + BH
ROW2_Z = KEYSTONE_Z + BH + GAP + BH
ROW3_Z = ROW2_Z + BH + GAP + BH

# Row 0: 4 blocks
for x in [-0.30, -0.10, 0.10, 0.30]:
    add_block(f"b{bid}", x, ROW0_Z, COLORS[bid % 2])

# Row 1: keystone only (upper tiers rest solely on this block)
add_block("keystone", 0.0, KEYSTONE_Z, "keystone")

# Row 2–3: narrower upper tiers on keystone
add_block(f"b{bid}", 0.0, ROW2_Z, COLORS[bid % 2], bw=BW_TOP)
add_block(f"b{bid}", 0.0, ROW3_Z, COLORS[bid % 2], bw=BW_TOP)

bodies_xml = "\n".join(bodies)

xml = f"""<mujoco model="pyramid_keystone_removal">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="5" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="36"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat"  rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="table_wood" rgba="0.55 0.42 0.28 1" specular="0.15" shininess="0.2"/>
    <material name="brick_warm" rgba="0.92 0.78 0.46 1" specular="0.1" shininess="0.12"/>
    <material name="brick_cool" rgba="0.78 0.66 0.36 1" specular="0.1" shininess="0.12"/>
    <material name="keystone" rgba="0.72 0.28 0.22 1" specular="0.12" shininess="0.15"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="table" type="box" pos="0 0 -0.05" size="0.55 0.45 0.05"
          material="table_wood" friction="{FRICTION.split()[0]} 0.04 0.005"/>

{bodies_xml}

    <camera name="cam" pos="0.05 -2.05 0.42" fovy="36"
            xyaxes="0.98 0.20 0   0.04 0.20 0.978"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "pyramid_keystone_removal.xml")
with open(out_path, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out_path}  ({bid} blocks, keystone-only row 1)")
