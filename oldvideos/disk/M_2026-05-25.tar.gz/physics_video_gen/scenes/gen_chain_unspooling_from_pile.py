"""Chain pile on table: mocap lifts top, bottom pile stays via high friction."""
import os
import sys

import imageio.v2 as imageio
import mujoco
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from chain_build import (
    build_chain_tree_mocap,
    init_chain_hinges,
    last_body_id,
    mocap_id,
    move_hand_z,
    pile_path,
)

SCENE_DIR = os.path.dirname(os.path.abspath(__file__))
XML_NAME = "chain_unspooling_from_pile.xml"

N = 40
LINK_LEN = 0.010
LINK_R = 0.0055
MASS = 0.0025
HAND_Z = 0.30
TABLE_Z = 0.04
LIFT_VZ = 0.18
LIFT_DUR = 3.0


def build_xml() -> str:
    chain = build_chain_tree_mocap(
        N, LINK_LEN, LINK_R, MASS, (0.0, 0.0, HAND_Z),
        root_material="link_top", alt_material="link_alt",
    )
    return f"""<mujoco model="chain_unspooling_from_pile">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="6" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="table" rgba="0.93 0.82 0.58 1" specular="0.1" shininess="0.1"/>
    <material name="link" rgba="0.55 0.50 0.48 1" specular="0.25" shininess="0.25"/>
    <material name="link_alt" rgba="0.68 0.62 0.58 1" specular="0.25" shininess="0.25"/>
    <material name="link_top" rgba="0.86 0.32 0.30 1" specular="0.25" shininess="0.25"/>
  </asset>

  <default>
    <geom friction="0.90 0.04 0.001" solref="0.004 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat" friction="1.0 0.05 0.001"/>
    <geom type="box" pos="0 0 {TABLE_Z}" size="0.18 0.11 {TABLE_Z}" material="table"
          friction="1.0 0.05 0.001"/>

{chain}

    <camera name="cam" pos="0.02 -1.35 0.14" fovy="54"
            xyaxes="1 0 0   0 0 1"/>
  </worldbody>

  <equality>
    <weld name="hand_weld" body1="link0" body2="hand" solref="0.002 1"/>
  </equality>
</mujoco>
"""


def setup_sim(model, data):
    init_chain_hinges(model, data, pile_path(N, LINK_LEN))
    move_hand_z(model, data, HAND_Z)


def sim_step(model, data, t: float) -> None:
    z = HAND_Z + LIFT_VZ * min(t, LIFT_DUR)
    move_hand_z(model, data, z)
    mujoco.mj_step(model, data)


def render_mp4(xml_path, out_path, duration=3.5, fps=30):
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    setup_sim(model, data)
    bid = last_body_id(model)
    z0_hand, z0_bot = HAND_Z, data.xpos[bid, 2]
    renderer = mujoco.Renderer(model, 1080, 1920)
    steps = max(1, int(round((1.0 / fps) / model.opt.timestep)))
    max_hand = HAND_Z
    frames = []
    for fi in range(int(round(duration * fps))):
        t = fi / fps
        for _ in range(steps):
            sim_step(model, data, t)
        max_hand = max(max_hand, float(data.mocap_pos[mocap_id(model)][2]))
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())
    print(
        f"  hand peak dz={max_hand - z0_hand:.3f}, "
        f"bottom z={data.xpos[bid, 2]:.3f} (start {z0_bot:.3f})"
    )
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    imageio.mimsave(out_path, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {out_path}")


def render_grid(xml_path, out_path, duration=3.5, cols=4, rows=2):
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    setup_sim(model, data)
    renderer = mujoco.Renderer(model, 270, 480)
    total = int(round(duration / model.opt.timestep))
    targets = [int(round((i + 1) * total / (cols * rows))) for i in range(cols * rows)]
    cells, idx = [], 0
    for step in range(1, total + 1):
        sim_step(model, data, step * model.opt.timestep)
        if idx < len(targets) and step >= targets[idx]:
            renderer.update_scene(data, camera="cam")
            cells.append(renderer.render())
            idx += 1
    while len(cells) < cols * rows:
        renderer.update_scene(data, camera="cam")
        cells.append(renderer.render())
    grid = np.concatenate(
        [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)], axis=0
    )
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    imageio.imwrite(out_path, grid)
    print(f"Wrote {out_path}")


def main():
    os.chdir(os.path.dirname(SCENE_DIR))
    xml_path = os.path.join("scenes", XML_NAME)
    with open(xml_path, "w", encoding="utf-8") as f:
        f.write(build_xml())
    print(f"Wrote {xml_path}")
    render_mp4(xml_path, "out/scenes/chain_unspooling_from_pile.mp4")
    render_grid(xml_path, "out/chain_unspooling_from_pile_grid.png")


if __name__ == "__main__":
    main()
