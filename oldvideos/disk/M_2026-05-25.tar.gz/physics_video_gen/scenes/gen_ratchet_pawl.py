"""Generate ratchet_pawl.xml and render: forward click-click, then reverse lock."""
import math
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

SCENE_DIR = os.path.dirname(os.path.abspath(__file__))
XML_NAME = "ratchet_pawl.xml"

N_TEETH = 12
R = 0.10


def build_tooth_geoms() -> str:
    lines = []
    for i in range(N_TEETH):
        ang = 2 * math.pi * i / N_TEETH
        # Gentle ramp: pawl rides over during CCW (+omega).
        r_ramp = R + 0.003
        xr = r_ramp * math.cos(ang - 0.14)
        yr = r_ramp * math.sin(ang - 0.14)
        lines.append(
            f'      <geom type="box" pos="{xr:.4f} {yr:.4f} 0" '
            f'euler="0 0 {ang - 0.72:.4f}" size="0.015 0.005 0.010" '
            f'material="tooth" friction="0.50 0.02 0.001"/>'
        )
        # Near-vertical lock face: blocks CW (-omega).
        r_lock = R + 0.005
        xl = r_lock * math.cos(ang + 0.11)
        yl = r_lock * math.sin(ang + 0.11)
        lines.append(
            f'      <geom type="box" pos="{xl:.4f} {yl:.4f} 0" '
            f'euler="0 0 {ang + 0.04:.4f}" size="0.007 0.007 0.014" '
            f'material="tooth_lock" friction="0.65 0.02 0.001"/>'
        )
    return "\n".join(lines)


def build_xml() -> str:
    return f"""<mujoco model="ratchet_pawl">
  <!-- 12-tooth ratchet + spring pawl. CCW (+omega) free; CW blocked. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="4" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="wheel" rgba="0.92 0.78 0.36 1" specular="0.4" shininess="0.5"/>
    <material name="tooth" rgba="0.78 0.65 0.40 1" specular="0.3" shininess="0.35"/>
    <material name="tooth_lock" rgba="0.62 0.48 0.34 1" specular="0.3" shininess="0.35"/>
    <material name="pawl" rgba="0.86 0.32 0.30 1" specular="0.3" shininess="0.35"/>
    <material name="frame" rgba="0.55 0.50 0.48 1" specular="0.2" shininess="0.2"/>
    <material name="mark" rgba="0.96 0.90 0.30 1" specular="0.3" shininess="0.3"/>
    <material name="pivot" rgba="0.30 0.28 0.30 1" specular="0.4" shininess="0.5"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

  <!-- Fixed frame + pawl pivot -->
    <geom type="box" pos="0.145 0 0.08" size="0.018 0.022 0.08" material="frame"
          contype="0" conaffinity="0"/>
    <geom type="sphere" pos="0.125 0 0.10" size="0.010" material="pivot"
          contype="0" conaffinity="0"/>

    <body name="wheel" pos="0 0 0.10">
      <joint name="wheel_hinge" type="hinge" axis="0 0 1" damping="0.02"/>
      <geom type="cylinder" size="{R * 0.55:.3f} 0.010" mass="0.35" material="wheel"/>
      <geom type="sphere" pos="{R * 0.65:.4f} 0 0.012" size="0.010" material="mark"
            contype="0" conaffinity="0"/>
      <geom type="sphere" pos="{-R * 0.65:.4f} 0 0.012" size="0.008" material="pawl"
            contype="0" conaffinity="0"/>
{build_tooth_geoms()}
    </body>

    <body name="pawl_arm" pos="0.125 0 0.10">
      <joint name="pawl_hinge" type="hinge" axis="0 0 1"
             stiffness="22" damping="0.22" ref="0.08"
             limited="true" range="-0.04 0.50"/>
      <geom type="capsule" fromto="0 0 0  -0.032 0 0" size="0.006" mass="0.030"
            material="pawl" friction="0.65 0.02 0.001"/>
      <geom type="sphere" pos="-0.032 0 0" size="0.009" material="pawl"
            friction="0.65 0.02 0.001"/>
    </body>

    <camera name="cam" pos="0 0 0.42" fovy="44"
            xyaxes="1 0 0   0 1 0"/>
  </worldbody>

  <actuator>
    <velocity name="wheel_drive" joint="wheel_hinge" kv="90" ctrlrange="-8 8"/>
  </actuator>

  <keyframe>
    <key name="forward" ctrl="4"/>
  </keyframe>
</mujoco>
"""


def write_xml(path: str | None = None) -> str:
    if path is None:
        path = os.path.join(SCENE_DIR, XML_NAME)
    with open(path, "w", encoding="utf-8") as f:
        f.write(build_xml())
    print(f"Wrote {path}")
    return path


def wheel_ctrl(sim_time: float) -> float:
    """CCW drive for first half; release drive for reverse lock demo."""
    return 4.0 if sim_time < 1.5 else 0.0


def render_mp4(
    xml_path: str,
    output_path: str,
    duration: float = 3.0,
    fps: int = 30,
    width: int = 1920,
    height: int = 1080,
) -> None:
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    aid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "wheel_drive")
    wid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "wheel_hinge")
    pid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "pawl_hinge")
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)
    dt = model.opt.timestep
    steps = max(1, int(round((1.0 / fps) / dt)))
    n_frames = int(round(duration * fps))
    q_fwd_end = None
    impulse_done = False
    frames = []
    for fi in range(n_frames):
        t = fi / fps
        ctrl = wheel_ctrl(t)
        for _ in range(steps):
            data.ctrl[aid] = ctrl
            if t >= 1.5 and not impulse_done:
                data.qvel[wid] = -2.5
                impulse_done = True
            mujoco.mj_step(model, data)
        if fi == int(round(1.5 * fps)) - 1:
            q_fwd_end = data.qpos[wid]
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())

    fwd_turns = (q_fwd_end or data.qpos[wid]) / (2 * math.pi)
    rev_deg = math.degrees(data.qpos[wid] - (q_fwd_end or 0.0))
    print(
        f"  forward: {fwd_turns:.2f} turns, reverse: {rev_deg:+.1f} deg, "
        f"pawl={data.qpos[pid]:+.3f} rad"
    )
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    imageio.mimsave(output_path, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {output_path} ({len(frames)} frames)")


def render_grid(
    xml_path: str,
    output_path: str,
    duration: float = 3.0,
    cols: int = 4,
    rows: int = 2,
    width: int = 480,
    height: int = 270,
) -> None:
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    aid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "wheel_drive")
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)
    n_cells = cols * rows
    total = int(round(duration / model.opt.timestep))
    targets = [int(round((i + 1) * total / n_cells)) for i in range(n_cells)]
    cells, idx = [], 0
    impulse_done = False
    for step in range(1, total + 1):
        t = step * model.opt.timestep
        data.ctrl[aid] = wheel_ctrl(t)
        if t >= 1.5 and not impulse_done:
            wid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "wheel_hinge")
            data.qvel[wid] = -2.5
            impulse_done = True
        mujoco.mj_step(model, data)
        if idx < n_cells and step >= targets[idx]:
            renderer.update_scene(data, camera="cam")
            cells.append(renderer.render())
            idx += 1
    while len(cells) < n_cells:
        renderer.update_scene(data, camera="cam")
        cells.append(renderer.render())
    grid = np.concatenate(
        [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)],
        axis=0,
    )
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    imageio.imwrite(output_path, grid)
    print(f"Wrote {output_path}")


def main() -> None:
    root = os.path.dirname(SCENE_DIR)
    os.chdir(root)
    xml_path = write_xml(os.path.join("scenes", XML_NAME))
    render_mp4(xml_path, "out/scenes/ratchet_pawl.mp4")
    render_grid(xml_path, "out/ratchet_pawl_grid.png")


if __name__ == "__main__":
    main()
