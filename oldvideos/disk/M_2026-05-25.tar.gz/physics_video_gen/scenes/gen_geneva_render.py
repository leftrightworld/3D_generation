"""Render Geneva drive: slow, obvious dwell then 90° step."""
import math
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SCENE = "scenes/geneva_drive.xml"
OUT = "out/scenes/geneva_drive.mp4"
GRID = "out/geneva_drive_grid.png"

DRIVER_OMEGA = 0.50
QUARTER = math.pi / 2
DWELL_END = 0.48
SWEEP_END = 0.78


def smoothstep(t):
    t = max(0.0, min(1.0, t))
    return t * t * (3.0 - 2.0 * t)


def driven_angle(driver_a):
    phase = driver_a % QUARTER
    idx = int(driver_a / QUARTER)
    u = phase / QUARTER
    if u < DWELL_END:
        return idx * QUARTER
    if u < SWEEP_END:
        t = (u - DWELL_END) / (SWEEP_END - DWELL_END)
        return (idx + smoothstep(t)) * QUARTER
    return (idx + 1) * QUARTER


def geneva_camera():
    cam = mujoco.MjvCamera()
    cam.type = mujoco.mjtCamera.mjCAMERA_FREE
    cam.lookat[:] = [0.0, 0.18, 0.56]
    cam.distance = 0.62
    cam.azimuth = -92.0
    cam.elevation = -8.0
    return cam


def main():
    model = mujoco.MjModel.from_xml_path(SCENE)
    data = mujoco.MjData(model)
    drv = model.joint("driver_spin").id
    drn = model.joint("driven_spin").id

    renderer = mujoco.Renderer(model, 1080, 1920)
    cam = geneva_camera()
    fps = 30
    duration = 6.0
    spf = max(1, int(round((1.0 / fps) / model.opt.timestep)))

    frames = []
    for _ in range(int(duration * fps)):
        for _ in range(spf):
            data.qvel[drv] = DRIVER_OMEGA
            mujoco.mj_step(model, data)
            data.qpos[drn] = driven_angle(data.qpos[drv])
            data.qvel[drn] = 0.0
            mujoco.mj_forward(model, data)
        renderer.update_scene(data, camera=cam)
        frames.append(renderer.render())

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    imageio.mimsave(OUT, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {OUT}  (omega={DRIVER_OMEGA}, {duration}s)")

    d2 = mujoco.MjData(model)
    drv2 = model.joint("driver_spin").id
    drn2 = model.joint("driven_spin").id
    total = int(duration / model.opt.timestep)
    targets = [int(total * k / 7) for k in range(8)]
    imgs, step, gi = [], 0, 0
    while gi < 8:
        d2.qvel[drv2] = DRIVER_OMEGA
        mujoco.mj_step(model, d2)
        d2.qpos[drn2] = driven_angle(d2.qpos[drv2])
        d2.qvel[drn2] = 0.0
        mujoco.mj_forward(model, d2)
        step += 1
        if step >= targets[gi]:
            renderer.update_scene(d2, camera=cam)
            imgs.append(renderer.render())
            gi += 1

    h, w = imgs[0].shape[:2]
    canvas = np.zeros((h * 2, w * 4, 3), dtype=np.uint8)
    for idx, im in enumerate(imgs):
        r, c = idx // 4, idx % 4
        canvas[r * h:(r + 1) * h, c * w:(c + 1) * w] = im
    imageio.imwrite(GRID, canvas)
    print(f"Wrote {GRID}")


if __name__ == "__main__":
    main()
