"""Render galileo_inclined_plane_squared with s = S_MAX*(t/T)^2 motion."""
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S_MAX = 0.88
DURATION = 4.0


def advance_ball(model, data, dt):
    t1 = min(data.time + dt, DURATION)
    s = S_MAX * (t1 / DURATION) ** 2
    jid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "slide")
    qadr = model.jnt_qposadr[jid]
    vadr = model.jnt_dofadr[jid]
    s0 = S_MAX * (data.time / DURATION) ** 2
    data.qpos[qadr] = s
    data.qvel[vadr] = (s - s0) / dt if dt > 0 else 0.0
    data.time = t1
    mujoco.mj_forward(model, data)


def render_mp4(fps=30, width=1920, height=1080):
    xml = "scenes/galileo_inclined_plane_squared.xml"
    mp4 = "out/scenes/galileo_inclined_plane_squared.mp4"
    model = mujoco.MjModel.from_xml_path(xml)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    renderer = mujoco.Renderer(model, height=height, width=width)
    steps = max(1, int(round((1.0 / fps) / model.opt.timestep)))
    frames = []
    for _ in range(int(round(DURATION * fps))):
        for _ in range(steps):
            advance_ball(model, data, model.opt.timestep)
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())
    os.makedirs(os.path.dirname(mp4), exist_ok=True)
    imageio.mimsave(mp4, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {mp4}")


def render_grid(cols=4, rows=2, width=480, height=270):
    xml = "scenes/galileo_inclined_plane_squared.xml"
    grid = "out/galileo_inclined_plane_squared_grid.png"
    model = mujoco.MjModel.from_xml_path(xml)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    renderer = mujoco.Renderer(model, height=height, width=width)
    total = int(round(DURATION / model.opt.timestep))
    targets = [int(round((i + 1) * total / (cols * rows))) for i in range(cols * rows)]
    cells, idx = [], 0
    for step in range(1, total + 1):
        advance_ball(model, data, model.opt.timestep)
        if idx < len(targets) and step >= targets[idx]:
            renderer.update_scene(data, camera="cam")
            cells.append(renderer.render())
            idx += 1
    while len(cells) < cols * rows:
        renderer.update_scene(data, camera="cam")
        cells.append(renderer.render())
    grid_img = np.concatenate(
        [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)], axis=0
    )
    os.makedirs(os.path.dirname(grid), exist_ok=True)
    imageio.imwrite(grid, grid_img)
    print(f"Wrote {grid}")


def main():
    os.chdir(ROOT)
    render_mp4()
    render_grid()
    # Print marker pass times for verification
    for n in (1, 4, 9, 16):
        t = DURATION * (n / 16) ** 0.5
        print(f"marker {n}/16 at t={t:.2f}s  s={S_MAX * n / 16:.3f}m")


if __name__ == "__main__":
    main()
