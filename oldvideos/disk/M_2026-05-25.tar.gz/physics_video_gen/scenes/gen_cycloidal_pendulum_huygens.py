"""
Procedurally generate scenes/cycloidal_pendulum_huygens.xml: Huygens tautochrone
pendulum with extended cycloid cheek guides that flank the full swing arc.
"""
import math
import os

R = 0.22
PX, PY, PZ = 0.0, 0.0, 1.05
N_CHEEK = 18
THETA_MAX = math.pi
SEG_T = 0.014
BOB_M = 0.050
BOB_R = 0.015
ARM = 0.50


def cheek_segments(side):
    lines = []
    sign = 1.0 if side > 0 else -1.0
    mat = "cheek_L" if side > 0 else "cheek_R"
    for i in range(N_CHEEK):
        t0 = (i / N_CHEEK) * THETA_MAX
        t1 = ((i + 1) / N_CHEEK) * THETA_MAX
        x0 = sign * R * (t0 - math.sin(t0))
        z0 = PZ - R * (1 - math.cos(t0))
        x1 = sign * R * (t1 - math.sin(t1))
        z1 = PZ - R * (1 - math.cos(t1))
        lines.append(
            f'    <geom name="cheek_{side}_{i}" type="cylinder" '
            f'fromto="{x0:.4f} {PY:.4f} {z0:.4f}  {x1:.4f} {PY:.4f} {z1:.4f}" '
            f'size="{SEG_T:.4f}" material="{mat}" contype="0" conaffinity="0"/>'
        )
    return "\n".join(lines)


cheek_xml = cheek_segments(+1) + "\n" + cheek_segments(-1)

xml = f"""<mujoco model="cycloidal_pendulum_huygens">
  <!-- Huygens cycloidal pendulum: extended cycloid cheeks (theta=0..pi) flank
       the swing plane; the string rod contacts the cheeks during large swings. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="5" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="pivot_mat" rgba="0.30 0.27 0.24 1" specular="0.2" shininess="0.25"/>
    <material name="cheek_L" rgba="0.78 0.65 0.40 1" specular="0.1" shininess="0.1"/>
    <material name="cheek_R" rgba="0.70 0.55 0.30 1" specular="0.1" shininess="0.1"/>
    <material name="bob_red" rgba="0.86 0.34 0.30 1" specular="0.4" shininess="0.5"/>
    <material name="string_mat" rgba="0.28 0.25 0.22 1" specular="0" shininess="0"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.35 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.45 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.30 0.30 0.36" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>
    <geom type="sphere" pos="{PX:.3f} {PY:.3f} {PZ:.3f}" size="0.012"
          material="pivot_mat" contype="0" conaffinity="0"/>

{cheek_xml}

    <body name="pendulum" pos="{PX:.3f} {PY:.3f} {PZ:.3f}">
      <joint name="hinge" type="hinge" axis="0 1 0" damping="0.0008"/>
      <geom name="rod" type="capsule" fromto="0 0 0  0 0 -{ARM:.3f}"
            size="0.0028" material="string_mat" contype="0" conaffinity="0"
            mass="0"/>
      <geom name="bob" type="sphere" pos="0 0 -{ARM:.3f}" size="{BOB_R:.3f}"
            mass="{BOB_M:.3f}" material="bob_red" contype="0" conaffinity="0"/>
    </body>

    <camera name="cam" pos="0.00 -1.85 {PZ - 0.22:.3f}" fovy="46"
            xyaxes="1 0 0   0 0.10 0.995"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "cycloidal_pendulum_huygens.xml")
with open(out_path, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out_path}  R={R} ARM={ARM} cheek_z=[{PZ-2*R:.2f},{PZ:.2f}]")
print('Suggested: --duration 4.0 --init-qpos "0.62"')
