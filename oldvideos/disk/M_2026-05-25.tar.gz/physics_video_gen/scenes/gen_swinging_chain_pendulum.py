"""
Procedurally generate scenes/swinging_chain_pendulum.xml: a vertical chain of
N links pinned at the top, initially pulled to ~30° from vertical and released.
"""
import math
import os

N = 25
SEG_L = 0.042
LINK_R = 0.005
LINK_M = 0.014
D_HINGE = 0.0012
TILT_DEG = 30.0
TILT = math.radians(TILT_DEG)
ANCHOR_Z = 1.58
ANCHOR_Y = 0.0

COLORS = ["link_steel", "link_bronze", "link_copper", "link_slate"]


def link_body(i):
    indent = "      " + "  " * i
    mat = COLORS[i % len(COLORS)]
    parts = []
    if i > 0:
        parts.append(
            f'{indent}<joint name="h{i}" type="hinge" axis="0 1 0" '
            f'damping="{D_HINGE}"/>'
        )
    parts.append(
        f'{indent}<geom name="link{i}" type="capsule" '
        f'fromto="0 0 0  0 0 -{SEG_L:.4f}" size="{LINK_R:.4f}" '
        f'material="{mat}" mass="{LINK_M}" contype="0" conaffinity="0"/>'
    )
    if i < N - 1:
        child = (
            f'{indent}<body name="link{i + 1}" pos="0 0 -{SEG_L:.4f}">\n'
            f"{link_body(i + 1)}\n"
            f"{indent}</body>"
        )
        parts.append(child)
    return "\n".join(parts)


chain_xml = link_body(0)
chain_len = N * SEG_L
mid_z = ANCHOR_Z - chain_len * 0.5
hinge_angle = TILT / max(N - 1, 1)
init_qpos = ",".join(f"{hinge_angle:.6f}" for _ in range(N - 1))

xml = f"""<mujoco model="swinging_chain_pendulum">
  <!-- Vertical chain pendulum: {N} links, top pinned, ~{TILT_DEG:.0f}° initial tilt. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="frame_wood" rgba="0.78 0.65 0.40 1" specular="0.12" shininess="0.15"/>
    <material name="link_steel"  rgba="0.62 0.64 0.68 1" specular="0.45" shininess="0.55"/>
    <material name="link_bronze" rgba="0.78 0.55 0.32 1" specular="0.40" shininess="0.50"/>
    <material name="link_copper" rgba="0.86 0.48 0.34 1" specular="0.40" shininess="0.50"/>
    <material name="link_slate"  rgba="0.42 0.44 0.48 1" specular="0.35" shininess="0.45"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <geom type="box" size="0.10 0.04 0.025" pos="0 {ANCHOR_Y:.4f} {ANCHOR_Z + 0.08:.4f}"
          material="frame_wood" contype="0" conaffinity="0"/>

    <body name="link0" pos="0 {ANCHOR_Y:.4f} {ANCHOR_Z:.4f}">
{chain_xml}
    </body>

    <camera name="cam" pos="0.30 -2.35 {mid_z:.3f}" fovy="46"
            xyaxes="0.985 0.158 0   -0.011 0.069 0.998"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "swinging_chain_pendulum.xml")
with open(out_path, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out_path}  (N={N}, length={chain_len:.2f} m, tilt={TILT_DEG:.0f}°)")
print(f'Suggested: --duration 5.0 --init-qpos "{init_qpos}"')
print("Suggested init-qvel: all zeros (default)")
