"""Integrate beads along cycloid (tautochrone) and render MP4."""
import math
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SCENE = "scenes/bead_on_cycloid_track_isochrony.xml"
OUT = "out/scenes/bead_on_cycloid_track_isochrony.mp4"

R = 0.25
EPS = 0.08
THETA_END = math.pi
G = 9.81
Y = 0.18
BALL_R = 0.022
PHI0 = [0.18, 0.55 * math.pi, 0.82 * math.pi]
BEADS = ["bead1", "bead2", "bead3"]


def cycloid_xz(phi):
    x = R * (phi - math.sin(phi))
    z = -R * (1 - math.cos(phi))
    return x, z


def cycloid_tangent(phi):
    tx = 1 - math.cos(phi)
    tz = -math.sin(phi)
    n = math.hypot(tx, tz)
    return tx / n, tz / n


def bead_world(phi):
    x, z = cycloid_xz(phi)
    tx, tz = cycloid_tangent(phi)
    nx, nz = -tz, tx
    return x + BALL_R * nx, Y, z + BALL_R * nz


def eom_phi(phi, vphi):
    """Lagrangian EOM on cycloid parameter (tautochrone)."""
    s = math.sin(phi / 2)
    if abs(s) < 1e-6:
        s = 1e-6
    return G * math.cos(phi / 2) / (2 * R * s) - math.cos(phi / 2) * vphi * vphi


def set_mocap(model, data, name, pos):
    bid = model.body(name).id
    mid = model.body_mocapid[bid]
    data.mocap_pos[mid] = pos
    data.mocap_quat[mid] = [1, 0, 0, 0]


def topdown_camera():
    cam = mujoco.MjvCamera()
    cam.type = mujoco.mjtCamera.mjCAMERA_FREE
    cam.lookat[:] = [0.38, 0.18, -0.25]
    cam.distance = 1.5
    cam.azimuth = 90
    cam.elevation = -89
    return cam


def main():
    model = mujoco.MjModel.from_xml_path(SCENE)
    data = mujoco.MjData(model)
    dt = model.opt.timestep

    phis = list(PHI0)
    vphis = [0.0, 0.0, 0.0]

    renderer = mujoco.Renderer(model, 1080, 1920)
    cam = topdown_camera()
    fps = 30
    duration = 2.0
    spf = max(1, int(round((1.0 / fps) / dt)))

    frames = []
    for _ in range(int(duration * fps)):
        for _ in range(spf):
            for i in range(3):
                if phis[i] < THETA_END:
                    a = eom_phi(phis[i], vphis[i])
                    vphis[i] += a * dt
                    phis[i] += vphis[i] * dt
                    if phis[i] > THETA_END:
                        phis[i] = THETA_END
                        vphis[i] = 0.0
            for name, phi in zip(BEADS, phis):
                set_mocap(model, data, name, bead_world(phi))
            mujoco.mj_forward(model, data)

        renderer.update_scene(data, camera=cam)
        frames.append(renderer.render())

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    imageio.mimsave(OUT, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {OUT}")
    print("Final phi:", [round(p, 3) for p in phis])


if __name__ == "__main__":
    main()
