"""Generate scenes/wave_reflection_free.xml: nested chain with free-end pulse."""
import math
import os

N = 35
LINK_L = 0.04
LINK_M = 0.008
STIFF = 60.0
DAMP = 0.25
START_X = -0.70
Y = 0.18
Z = 0.55

def build_chain(i):
    mat = ["dom_cream", "dom_peach", "dom_blue", "dom_dark"][i % 4]
    if i == N - 1:
        inner = ""
    else:
        inner = build_chain(i + 1)
    joint = "" if i == 0 else (
        f'<joint name="h{i}" type="hinge" axis="0 1 0" stiffness="{STIFF}" '
        f'damping="{DAMP}" limited="false"/>\n      '
    )
    return f"""<body name="n{i}" pos="{LINK_L if i > 0 else START_X:.4f} {'0' if i > 0 else f'{Y} {Z:.4f}'}">
      {joint}<geom type="capsule" fromto="0 0 0  {LINK_L} 0 0" size="0.004"
            mass="{LINK_M}" material="{mat}"/>
      {inner}
    </body>"""

# Fix body pos for root
root = f"""    <body name="n0" pos="{START_X:.4f} {Y} {Z:.4f}">
      <geom type="capsule" fromto="0 0 0  {LINK_L} 0 0" size="0.004"
            mass="{LINK_M}" material="dom_cream"/>
"""

inner_parts = []
for i in range(1, N):
    mat = ["dom_cream", "dom_peach", "dom_blue", "dom_dark"][i % 4]
    inner_parts.append(f"""      <body name="n{i}" pos="{LINK_L} 0 0">
        <joint name="h{i}" type="hinge" axis="0 1 0" stiffness="{STIFF}"
               damping="{DAMP}" limited="false"/>
        <geom type="capsule" fromto="0 0 0  {LINK_L} 0 0" size="0.004"
              mass="{LINK_M}" material="{mat}"/>""")

chain_xml = root
for i in range(1, N):
    chain_xml += inner_parts[i-1] if i <= len(inner_parts) else ""
chain_xml += "      </body>\n" * N

# Simpler: build recursively as string
def make_body(idx):
    mat = ["dom_cream", "dom_peach", "dom_blue", "dom_dark"][idx % 4]
    pos = f"{START_X:.4f} {Y} {Z:.4f}" if idx == 0 else f"{LINK_L} 0 0"
    lines = [f'    <body name="n{idx}" pos="{pos}">']
    if idx > 0:
        lines.append(f'      <joint name="h{idx}" type="hinge" axis="0 1 0" '
                     f'stiffness="{STIFF}" damping="{DAMP}" limited="false"/>')
    lines.append(f'      <geom type="capsule" fromto="0 0 0  {LINK_L} 0 0" size="0.004"')
    lines.append(f'            mass="{LINK_M}" material="{mat}"/>')
    if idx < N - 1:
        lines.append(make_body(idx + 1).replace("    ", "      "))
    lines.append('    </body>')
    return "\n".join(lines)

chain_xml = make_body(0)

xml = f"""<mujoco model="wave_reflection_free">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="post_mat" rgba="0.93 0.82 0.58 1" specular="0.1" shininess="0.1"/>
    <material name="dom_cream" rgba="0.96 0.92 0.85 1" specular="0.15" shininess="0.2"/>
    <material name="dom_peach" rgba="0.95 0.78 0.62 1" specular="0.15" shininess="0.2"/>
    <material name="dom_blue" rgba="0.36 0.58 0.82 1" specular="0.25" shininess="0.3"/>
    <material name="dom_dark" rgba="0.32 0.30 0.32 1" specular="0.25" shininess="0.3"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>
    <geom type="box" size="0.04 0.04 0.60" pos="{START_X - 0.02:.4f} {Y} {Z - 0.30:.4f}"
          material="post_mat"/>

{chain_xml}

    <camera name="cam" pos="0 -2.0 0.65" fovy="38"
            xyaxes="1 0 0   0 0.20 0.98"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "wave_reflection_free.xml")
with open(out, "w") as f:
    f.write(xml)
print(f"Wrote {out}")
