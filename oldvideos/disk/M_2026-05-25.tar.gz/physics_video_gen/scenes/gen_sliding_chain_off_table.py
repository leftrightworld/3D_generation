"""Generate scenes/sliding_chain_off_table.xml: nested chain half on frictionless table."""
import os

N = 24
LINK_L = 0.035
LINK_M = 0.012
TABLE_X = 0.0
TABLE_LEN = 0.50
TABLE_W = 0.12
TABLE_Z = 0.45
Y = 0.18
START_X = TABLE_X - TABLE_LEN

def make_body(idx):
    mat = ["dom_cream", "dom_peach", "dom_blue", "dom_dark"][idx % 4]
    if idx == 0:
        pos = f"{START_X:.4f} {Y} {TABLE_Z:.4f}"
    else:
        pos = f"{LINK_L} 0 0"
    lines = [f'    <body name="l{idx}" pos="{pos}">']
    if idx > 0:
        lines.append('      <joint type="hinge" axis="0 1 0" damping="0.05" limited="false"/>')
    lines.append(f'      <geom type="capsule" fromto="0 0 0  {LINK_L} 0 0" size="0.005"')
    lines.append(f'            mass="{LINK_M}" material="{mat}"/>')
    if idx < N - 1:
        lines.append(make_body(idx + 1).replace("    ", "      "))
    lines.append('    </body>')
    return "\n".join(lines)

chain_xml = make_body(0)

xml = f"""<mujoco model="sliding_chain_off_table">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="table_mat" rgba="0.93 0.82 0.58 1" specular="0.12" shininess="0.15"/>
    <material name="dom_cream" rgba="0.96 0.92 0.85 1" specular="0.15" shininess="0.2"/>
    <material name="dom_peach" rgba="0.95 0.78 0.62 1" specular="0.15" shininess="0.2"/>
    <material name="dom_blue" rgba="0.36 0.58 0.82 1" specular="0.25" shininess="0.3"/>
    <material name="dom_dark" rgba="0.32 0.30 0.32 1" specular="0.25" shininess="0.3"/>
  </asset>

  <default>
    <geom friction="0.05 0.005 0.001" solref="0.005 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"
          friction="0.3 0.01 0.001"/>

    <geom type="box" pos="{TABLE_X - TABLE_LEN * 0.5:.4f} {Y} {TABLE_Z - 0.015:.4f}"
          size="{TABLE_LEN * 0.5:.4f} {TABLE_W * 0.5:.4f} 0.015"
          material="table_mat" friction="0 0 0"/>

{chain_xml}

    <camera name="cam" pos="0.3 -1.8 0.55" fovy="38"
            xyaxes="0.98 0.20 0   -0.05 0.25 0.97"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "sliding_chain_off_table.xml")
with open(out, "w") as f:
    f.write(xml)
print(f"Wrote {out}")
