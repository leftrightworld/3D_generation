"""
Generate scenes/bead_on_helix.xml: visible spiral track, bead slides down smoothly.
"""
import math
import os

R = 0.072
PITCH = 0.048
TURNS = 4.0
N_SEG = 60
BEAD_R = 0.010
RAIL_R = 0.0055
RAIL_OFFSET = 0.013
Z0 = 0.22


def helix_pos(t):
    return (
        R * math.cos(t),
        R * math.sin(t),
        Z0 - PITCH * t / (2 * math.pi),
    )


def radial_xy(x, y):
    n = math.hypot(x, y)
    if n < 1e-6:
        return 1.0, 0.0
    return x / n, y / n


visual_segs = []
rail_inner = []
rail_outer = []
t_end = TURNS * 2 * math.pi

for i in range(N_SEG):
    t0 = t_end * i / N_SEG
    t1 = t_end * (i + 1) / N_SEG
    p0 = helix_pos(t0)
    p1 = helix_pos(t1)
    pm = helix_pos(0.5 * (t0 + t1))
    rx, ry = radial_xy(pm[0], pm[1])

    visual_segs.append(
        f'    <geom type="capsule" fromto="{p0[0]:.4f} {p0[1]:.4f} {p0[2]:.4f}  '
        f'{p1[0]:.4f} {p1[1]:.4f} {p1[2]:.4f}" size="0.012" '
        f'material="track_vis" contype="0" conaffinity="0"/>'
    )
    for sign, lst in [(-1, rail_inner), (1, rail_outer)]:
        ox, oy = rx * RAIL_OFFSET * sign, ry * RAIL_OFFSET * sign
        a = (p0[0] + ox, p0[1] + oy, p0[2])
        b = (p1[0] + ox, p1[1] + oy, p1[2])
        lst.append(
            f'    <geom type="capsule" fromto="{a[0]:.4f} {a[1]:.4f} {a[2]:.4f}  '
            f'{b[0]:.4f} {b[1]:.4f} {b[2]:.4f}" size="{RAIL_R:.4f}" '
            f'material="track_rail" friction="0.02 0.001 0.0001"/>'
        )

bead_x, bead_y, bead_z = helix_pos(0.12)
bead_z += BEAD_R + RAIL_R + 0.002
z_bot = Z0 - PITCH * t_end / (2 * math.pi)

xml = f"""<mujoco model="bead_on_helix">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="track_vis" rgba="0.93 0.82 0.58 1" specular="0.15" shininess="0.2"/>
    <material name="track_rail" rgba="0.78 0.65 0.40 1" specular="0.2" shininess="0.25"/>
    <material name="post_mat" rgba="0.55 0.42 0.28 1" specular="0.15" shininess="0.2"/>
    <material name="bead_mat" rgba="0.86 0.34 0.30 1" specular="0.5" shininess="0.6"/>
  </asset>

  <default>
    <geom solref="0.002 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <geom type="cylinder" fromto="0 0 0  0 0 {Z0 + 0.02:.3f}"
          size="0.016" material="post_mat" contype="0" conaffinity="0"/>

{chr(10).join(visual_segs)}

{chr(10).join(rail_inner)}

{chr(10).join(rail_outer)}

    <body name="bead" pos="{bead_x:.4f} {bead_y:.4f} {bead_z:.4f}">
      <freejoint name="bead_free"/>
      <geom name="bead_geom" type="sphere" size="{BEAD_R}" mass="0.018"
            material="bead_mat" friction="0.015 0.0005 0.0001"/>
    </body>

    <camera name="cam" pos="0.42 -0.48 0.20" fovy="46"
            xyaxes="0.78 0.62 0   -0.10 0.13 0.99"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "bead_on_helix.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print("Wrote", out, f"z_top={Z0:.2f} z_bot={z_bot:.2f}")
