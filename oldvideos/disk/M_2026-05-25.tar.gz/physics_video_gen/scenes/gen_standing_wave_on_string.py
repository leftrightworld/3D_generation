"""
Procedurally generate scenes/standing_wave_on_string.xml: a horizontal string
discretized into N segments joined by torsional hinge springs.  The left end
is pinned to a wall; the initial hinge angles follow a sinusoidal fundamental
mode so the string oscillates in a visible standing-wave pattern.
"""
import math
import os

N = 30
SEG_L = 0.035
CROSS = 0.004
M_SEG = 0.008
K_HINGE = 18.0
D_HINGE = 0.004
AMP = 0.22          # peak hinge angle (rad) for the fundamental mode
WALL_X = -0.55
STRING_Y = 0.0
ANCHOR_Z = 0.55

COLORS = [
    "seg_cream",
    "seg_blue",
    "seg_peach",
    "seg_sage",
]


def segment_body(i):
    indent = "      " + "  " * i
    mat = COLORS[i % len(COLORS)]
    if i > 0:
        joint = (
            f'{indent}<joint name="h{i}" type="hinge" axis="0 1 0" '
            f'stiffness="{K_HINGE}" damping="{D_HINGE}"/>'
        )
    else:
        joint = ""
    geom = (
        f'{indent}<geom name="seg{i}" type="box" '
        f'pos="{SEG_L / 2:.4f} 0 0" '
        f'size="{SEG_L / 2:.4f} {CROSS:.4f} {CROSS:.4f}" '
        f'material="{mat}" mass="{M_SEG}"/>'
    )
    if i < N - 1:
        child = (
            f'{indent}<body name="seg{i + 1}_body" pos="{SEG_L:.4f} 0 0">\n'
            f"{segment_body(i + 1)}\n"
            f"{indent}</body>"
        )
        if joint:
            return f"{joint}\n{geom}\n{child}"
        return f"{geom}\n{child}"
    return f"{joint}\n{geom}" if joint else geom


chain_xml = segment_body(0)
string_len = N * SEG_L
end_x = WALL_X + string_len

# Fundamental mode on a fixed-free discrete string: sin(pi * i / N).
init_angles = [
    AMP * math.sin(math.pi * i / N)
    for i in range(1, N)
]
init_qpos = ",".join(f"{a:.6f}" for a in init_angles)


xml = f"""<mujoco model="standing_wave_on_string">
  <!-- Horizontal discretized string: {N} segments, left end pinned.
       Initial hinge angles follow sin(pi i/N) — the fundamental mode. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="frame_wood" rgba="0.78 0.65 0.40 1" specular="0.12" shininess="0.15"/>
    <material name="seg_cream" rgba="0.96 0.92 0.85 1" specular="0.15" shininess="0.2"/>
    <material name="seg_blue"  rgba="0.36 0.58 0.82 1" specular="0.25" shininess="0.3"/>
    <material name="seg_peach" rgba="0.95 0.78 0.62 1" specular="0.15" shininess="0.2"/>
    <material name="seg_sage"  rgba="0.55 0.72 0.58 1" specular="0.20" shininess="0.25"/>
  </asset>

  <default>
    <geom friction="0.04 0.001" solref="0.005 1" solimp="0.95 0.99 0.001"
          contype="0" conaffinity="0"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <!-- Fixed wall / anchor post -->
    <geom type="box" size="0.04 0.06 0.55" pos="{WALL_X - 0.04:.4f} 0 {ANCHOR_Z:.4f}"
          material="frame_wood"/>

    <!-- String: pinned at the left wall, free at the right end. -->
    <body name="seg0_body" pos="{WALL_X:.4f} {STRING_Y:.4f} {ANCHOR_Z:.4f}">
{chain_xml}
    </body>

    <!-- Side view: wave deflection in z is visible. -->
    <camera name="cam" pos="0.05 -1.55 {ANCHOR_Z + 0.08:.4f}" fovy="40"
            xyaxes="0.985 0.158 0   -0.011 0.069 0.998"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "standing_wave_on_string.xml")
with open(out_path, "w") as f:
    f.write(xml)
print(f"Wrote {out_path}  (N={N}, length={string_len:.2f} m, x={WALL_X:.2f}..{end_x:.2f})")
print(f'Suggested: --duration 4.0 --init-qpos "{init_qpos}"')
print("Suggested init-qvel: all zeros (default)")
