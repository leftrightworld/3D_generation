"""Re-render all D-assignment scenes with auto-framed cameras and sustained drives."""
import math
import os
import re
import sys

import mujoco
import numpy as np
import imageio.v2 as imageio

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCENES = os.path.join(ROOT, "scenes")
OUT = os.path.join(ROOT, "out", "scenes")

# name -> duration, qpos list, qvel list, sustain {joint_name: speed} each step
JOBS = {
    "cycloidal_pendulum_huygens": dict(
        dur=4.0, qpos=[0.62], qvel=[], sustain={},
        cam_pos=[0.0, -1.85, 0.83], fovy=46,
    ),
    "rolling_chain": dict(dur=5.0, qpos=[], qvel=[0.55]+[0]*21, sustain={"pull": 0.55}),
    "centrifugal_governor": dict(dur=5.0, qpos=[], qvel=[14.0], sustain={"spin": 14.0},
                                 cam_pos=[0, -3.35, 1.15], fovy=54),
    "pulley_with_inertia": dict(dur=3.0, qpos=[], qvel=[], sustain={}),
    "n_body_1d_collisions": dict(dur=2.0, qpos=[], qvel=[2.2], sustain={},
                                 cam_pos=[-0.15, -2.60, 0.32], fovy=50),
    "block_on_accelerating_wedge": dict(dur=5.0, qpos=[], qvel=[], sustain={},
                                        cam_pos=[0.0, -1.75, 0.45], fovy=46),
    "pendulum_with_lateral_spring": dict(dur=12.0, qpos=[0.4], qvel=[], sustain={}),
    "hanging_slinky_drop": dict(
        dur=2.0, qpos=None, qvel=[], sustain={},
        cam_pos=[0.0, -2.05, 0.82], fovy=46,
    ),
    "standing_wave_on_string": dict(dur=4.0, qpos=None, qvel=[], sustain={}),
    "belt_friction": dict(dur=5.0, qpos=[], qvel=[5.0, 10.0/3.0],
                          sustain={"hinge_small": 5.0, "hinge_large": 10.0/3.0},
                          cam_pos=[0, -1.85, 1.38], fovy=42),
    "block_on_block_static_friction": dict(
        dur=3.0, qpos=[], qvel=[1.2, 1.2, 0, 0, 0, 0, 0, 0],
        sustain={},
        cam_pos=[0.12, -1.75, 0.30], fovy=38,
    ),
    "tumbling_book": dict(dur=5.0, qpos=[], qvel=[0,0,0,0.05,8,0,0.3], sustain={}),
    "swinging_chain_pendulum": dict(dur=5.0, qpos=[0.021817]*24, qvel=[], sustain={}),
    "bead_in_rotating_ring": dict(
        dur=12.0, qpos=[], qvel=[],
        sustain={},
        ctrl_schedule="bead_ring",
    ),
    "block_and_tackle": dict(dur=4.0, qpos=[0.03, -0.06],
                             qvel=[0.045, -0.09],
                             sustain={"j_light": 0.045, "j_heavy": -0.09},
                             cam_pos=[0, -2.35, 1.20], fovy=44),
    "cantilever_load_curve": dict(dur=3.0, qpos=[], qvel=[], sustain={}),
    "symmetry_breaking_ball_on_dome": dict(dur=3.5, qpos=[], qvel=[], sustain={}),
}


def _smoothstep(u):
    u = max(0.0, min(1.0, u))
    return u * u * (3.0 - 2.0 * u)


def _bead_ring_omega(t):
    # Hold at rest with the bead at the bottom, then ramp spin over 7 s.
    if t < 4.0:
        return 0.0
    return 14.0 * _smoothstep(min(1.0, (t - 4.0) / 7.0))


def _bead_ring_ctrl(t):
    w = _bead_ring_omega(t)
    r = 0.125
    g = 9.81
    phi = 0.0 if w * w * r <= g else math.acos(g / (w * w * r))
    return {"ring_vel": w, "bead_eq": phi}


CTRL_SCHEDULES = {
    "bead_ring": _bead_ring_ctrl,
}


def load_gen_init(name):
    gen = os.path.join(SCENES, f"gen_{name}.py")
    if not os.path.isfile(gen):
        return None, None
    import subprocess
    r = subprocess.run(["python", gen], capture_output=True, text=True, cwd=SCENES)
    qpos = qvel = None
    for line in r.stdout.splitlines():
        if "--init-qpos" in line and "Suggested" in line:
            if "--init-qpos=" in line:
                part = line.split("--init-qpos=", 1)[1].strip()
            else:
                part = line.split('--init-qpos "', 1)[1].split('"')[0]
            qpos = [float(x) for x in part.split(",")]
        if "--init-qvel" in line and "Suggested" in line:
            if "--init-qvel=" in line:
                part = line.split("--init-qvel=", 1)[1].strip()
            else:
                part = line.split('--init-qvel "', 1)[1].split('"')[0]
            qvel = [float(x) for x in part.split(",")]
    return qpos, qvel


def _drive_ids(model, job):
    sustain = job.get("sustain", {})
    sustain_ctrl = dict(job.get("sustain_ctrl", {}))
    sched = job.get("ctrl_schedule")
    if sched in CTRL_SCHEDULES:
        for aname in CTRL_SCHEDULES[sched](0.0):
            sustain_ctrl.setdefault(aname, 0.0)
    jids = {}
    for jname in sustain:
        jid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, jname)
        if jid >= 0:
            jids[jname] = model.jnt_dofadr[jid]
    aids = {}
    for aname in sustain_ctrl:
        aid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, aname)
        if aid >= 0:
            aids[aname] = aid
    return jids, aids


def _apply_drives(data, job, jids, aids, t=0.0):
    sched = job.get("ctrl_schedule")
    if sched in CTRL_SCHEDULES:
        for aname, val in CTRL_SCHEDULES[sched](t).items():
            if aname in aids:
                data.ctrl[aids[aname]] = val
        return
    sustain = job.get("sustain", {})
    sustain_ctrl = job.get("sustain_ctrl", {})
    ctrl_ramp = job.get("ctrl_ramp", {})
    for jname, spd in sustain.items():
        if jname in jids:
            data.qvel[jids[jname]] = spd
    for aname, val in sustain_ctrl.items():
        if aname in aids:
            ramp = float(ctrl_ramp.get(aname, 0.0))
            scale = min(1.0, t / ramp) if ramp > 0 else 1.0
            data.ctrl[aids[aname]] = val * scale


def motion_bounds(model, data, job):
    mins = np.full(3, np.inf)
    maxs = -mins
    steps = int(job["dur"] / model.opt.timestep)
    skip = max(1, steps // 100)
    jids, aids = _drive_ids(model, job)
    for t in range(steps + 1):
        if t % skip == 0 or t == steps:
            for i in range(1, model.nbody):
                p = data.xpos[i]
                mins = np.minimum(mins, p)
                maxs = np.maximum(maxs, p)
        if t < steps:
            _apply_drives(data, job, jids, aids, t * model.opt.timestep)
            mujoco.mj_step(model, data)
    center = 0.5 * (mins + maxs)
    extent = max(float(np.max(maxs - mins)), 0.15) * 1.25
    dist = max(extent * 1.4, 0.6)
    cam_pos = np.array([center[0], center[1] - dist, center[2] + extent * 0.15])
    fovy = float(np.clip(38 + 14 * (extent / dist), 36, 54))
    return cam_pos, fovy


def patch_camera(path, cam_pos, fovy):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    new_cam = (
        f'    <camera name="cam" pos="{cam_pos[0]:.3f} {cam_pos[1]:.3f} {cam_pos[2]:.3f}" '
        f'fovy="{fovy:.1f}"\n'
        f'            xyaxes="1 0 0   0 0.14 0.990"/>'
    )
    text, n = re.subn(r'    <camera name="cam"[^/]*/>', new_cam, text, count=1)
    if n:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)


def render_one(name, job, width=1280, height=720, fps=30):
    path = os.path.join(SCENES, f"{name}.xml")
    model = mujoco.MjModel.from_xml_path(path)
    data = mujoco.MjData(model)

    qpos = job.get("qpos")
    qvel = job.get("qvel")
    if qpos is None:
        gp, gv = load_gen_init(name)
        qpos = gp or []
        if not qvel and gv:
            qvel = gv
    if qpos:
        for i, v in enumerate(qpos):
            if i < model.nq:
                data.qpos[i] = v
    if qvel:
        for i, v in enumerate(qvel):
            if i < model.nv:
                data.qvel[i] = v

    jids, aids = _drive_ids(model, job)
    jids_sustain = {}
    for jname, spd in job.get("sustain", {}).items():
        jid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, jname)
        if jid >= 0:
            jids_sustain[jname] = (model.jnt_dofadr[jid], spd)

    if "cam_pos" in job:
        cam_pos = np.array(job["cam_pos"], dtype=float)
        fovy = float(job["fovy"])
    else:
        cam_pos, fovy = motion_bounds(model, data, job)
    patch_camera(path, cam_pos, fovy)

    # reset for render
    mujoco.mj_resetData(model, data)
    if qpos:
        for i, v in enumerate(qpos):
            if i < model.nq:
                data.qpos[i] = v
    if qvel:
        for i, v in enumerate(qvel):
            if i < model.nv:
                data.qvel[i] = v
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)
    steps_pf = max(1, int(round((1.0 / fps) / model.opt.timestep)))
    n_frames = int(round(job["dur"] * fps))
    frames = []
    sim_t = 0.0
    for _ in range(n_frames):
        for _ in range(steps_pf):
            for jname, (adr, spd) in jids_sustain.items():
                data.qvel[adr] = spd
            _apply_drives(data, job, jids, aids, sim_t)
            mujoco.mj_step(model, data)
            sim_t += model.opt.timestep
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())

    out = os.path.join(OUT, f"{name}.mp4")
    os.makedirs(OUT, exist_ok=True)
    imageio.mimsave(out, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"OK {name} -> {out}  cam={cam_pos.round(2)} fovy={fovy:.1f}")


def main():
  os.chdir(ROOT)
  for name, job in JOBS.items():
    render_one(name, job)


if __name__ == "__main__":
    main()
