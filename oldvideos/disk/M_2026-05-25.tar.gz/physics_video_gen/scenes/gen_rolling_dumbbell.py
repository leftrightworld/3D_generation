"""Render rolling_dumbbell: kinematic end-over-end tumble, ~2.5 cycles in 4 s."""
import math
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

DURATION = 4.0
HALF_LEN = 0.075
BALL_R = 0.04
Z_EPS = 0.003

# (time, center_x, tilt_deg)  θ<0 red (left) down; θ>0 blue (right) down
TUMBLE_KEYS = (
    (0.00, 0.12, -38.0),
    (0.75, 0.40, 38.0),
    (1.50, 0.66, -38.0),
    (2.25, 0.90, 38.0),
    (3.00, 1.10, -38.0),
    (4.00, 1.28, 38.0),
)


def _center_z(tilt_rad):
    """Keep the lower ball center on the floor (z = BALL_R)."""
    return BALL_R + HALF_LEN * abs(math.sin(tilt_rad)) + Z_EPS


def _min_geom_z(model, data):
    bid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "dumbbell")
    zmin = 1e9
    for i in range(model.ngeom):
        if model.geom_bodyid[i] != bid:
            continue
        p = data.geom_xpos[i]
        r = model.geom_size[i][0]
        zmin = min(zmin, p[2] - r)
    return zmin


def _interp(keys, t):
    if t <= keys[0][0]:
        return keys[0][1:]
    if t >= keys[-1][0]:
        return keys[-1][1:]
    for (t0, x0, a0), (t1, x1, a1) in zip(keys, keys[1:]):
        if t0 <= t <= t1:
            u = (t - t0) / (t1 - t0)
            return x0 + u * (x1 - x0), a0 + u * (a1 - a0)
    return keys[-1][1:]


def advance_dumbbell(model, data, dt):
    t1 = min(data.time + dt, DURATION)
    x1, ang1 = _interp(TUMBLE_KEYS, t1)
    x0, ang0 = _interp(TUMBLE_KEYS, data.time)
    tilt1 = math.radians(ang1)
    data.qpos[0] = x1
    data.qpos[1] = 0.0
    data.qpos[2] = _center_z(tilt1)
    data.qpos[3] = math.cos(tilt1 / 2)
    data.qpos[4] = 0.0
    data.qpos[5] = math.sin(tilt1 / 2)
    data.qpos[6] = 0.0
    if dt > 0:
        data.qvel[0] = (x1 - x0) / dt
        data.qvel[4] = math.radians(ang1 - ang0) / dt
    data.time = t1
    mujoco.mj_forward(model, data)


def render_mp4(fps=30, width=1920, height=1080):
    model = mujoco.MjModel.from_xml_path("scenes/rolling_dumbbell.xml")
    data = mujoco.MjData(model)
    advance_dumbbell(model, data, 0.0)
    renderer = mujoco.Renderer(model, height=height, width=width)
    steps = max(1, int(round((1.0 / fps) / model.opt.timestep)))
    frames = []
    for _ in range(int(round(DURATION * fps))):
        for _ in range(steps):
            advance_dumbbell(model, data, model.opt.timestep)
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())
    os.makedirs("out/scenes", exist_ok=True)
    out = "out/scenes/rolling_dumbbell.mp4"
    imageio.mimsave(out, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {out}")


def render_grid(cols=4, rows=2, width=480, height=270):
    model = mujoco.MjModel.from_xml_path("scenes/rolling_dumbbell.xml")
    data = mujoco.MjData(model)
    advance_dumbbell(model, data, 0.0)
    renderer = mujoco.Renderer(model, height=height, width=width)
    total = int(round(DURATION / model.opt.timestep))
    targets = [int(round((i + 1) * total / (cols * rows))) for i in range(cols * rows)]
    cells, idx = [], 0
    for step in range(1, total + 1):
        advance_dumbbell(model, data, model.opt.timestep)
        if idx < len(targets) and step >= targets[idx]:
            renderer.update_scene(data, camera="cam")
            cells.append(renderer.render())
            idx += 1
    while len(cells) < cols * rows:
        renderer.update_scene(data, camera="cam")
        cells.append(renderer.render())
    grid = np.concatenate(
        [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)], axis=0
    )
    os.makedirs("out", exist_ok=True)
    path = "out/rolling_dumbbell_grid.png"
    imageio.imwrite(path, grid)
    print(f"Wrote {path}")


def main():
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    model = mujoco.MjModel.from_xml_path("scenes/rolling_dumbbell.xml")
    data = mujoco.MjData(model)
    for t in [0.0, 0.75, 1.5, 2.25, 3.0, 4.0]:
        data.time = 0.0
        advance_dumbbell(model, data, t)
        print(f"t={t:.2f} x={data.qpos[0]:.2f} tilt={math.degrees(2*math.acos(min(1,abs(data.qpos[3])))):.0f} zmin={_min_geom_z(model, data):.4f}")
    render_mp4()
    render_grid()


if __name__ == "__main__":
    main()
