"""
Procedurally generate scenes/cantilever_load_curve.xml: a horizontal cantilever
beam discretized into N segments with torsional hinge springs.  A tip load bends
the beam downward; heavier payload => larger deflection.
"""
import os

N = 8
L = 0.80
SEG_L = L / N
CROSS = 0.010
M_SEG = 0.018
M_TIP = 0.45
K_HINGE = 22.0
D_HINGE = 0.35
TIP_EDGE = 0.06
BASE_W = 0.12
BASE_H = 0.05
BEAM_Z = 0.55


def segment_body(i):
    indent = "      " + "  " * i
    joint = (
        f'{indent}<joint name="h{i}" type="hinge" axis="0 1 0" '
        f'stiffness="{K_HINGE}" damping="{D_HINGE}"/>'
    )
    geom = (
        f'{indent}<geom name="seg{i}" type="box" '
        f'pos="{SEG_L / 2:.4f} 0 0" '
        f'size="{SEG_L / 2:.4f} {CROSS:.4f} {CROSS:.4f}" '
        f'material="beam" mass="{M_SEG}"/>'
    )
    if i < N - 1:
        child = (
            f'{indent}<body name="seg{i + 1}_body" pos="{SEG_L:.4f} 0 0">\n'
            f"{segment_body(i + 1)}\n"
            f"{indent}</body>"
        )
        return f"{joint}\n{geom}\n{child}"
    tip = (
        f'{indent}<geom name="tip_load" type="box" '
        f'pos="{SEG_L + TIP_EDGE / 2:.4f} 0 {-TIP_EDGE / 2:.4f}" '
        f'size="{TIP_EDGE / 2:.4f} {TIP_EDGE / 2:.4f} {TIP_EDGE / 2:.4f}" '
        f'material="payload" mass="{M_TIP}"/>'
    )
    return f"{joint}\n{geom}\n{tip}"


chain_xml = segment_body(0)

xml = f"""<mujoco model="cantilever_load_curve">
  <!-- Horizontal cantilever: {N} segments, hinge stiffness {K_HINGE}, tip load
       {M_TIP} kg.  Gravity pulls the tip down into a smooth bent curve. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="wood_dark" rgba="0.78 0.65 0.40 1" specular="0.1" shininess="0.1"/>
    <material name="beam" rgba="0.86 0.78 0.55 1" specular="0.30" shininess="0.4"/>
    <material name="payload" rgba="0.86 0.34 0.30 1" specular="0.35" shininess="0.4"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>
    <geom type="box" size="{BASE_W:.3f} {BASE_W:.3f} {BASE_H:.3f}"
          pos="0 0 {BEAM_Z:.3f}" material="wood_dark"/>

    <body name="chain_root" pos="0 0 {BEAM_Z + BASE_H:.3f}">
{chain_xml}
    </body>

    <camera name="cam" pos="0.55 -2.0 {BEAM_Z - 0.05:.3f}" fovy="40"
            xyaxes="0.985 0.174 0   -0.040 0.225 0.974"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "cantilever_load_curve.xml")
with open(out_path, "w") as f:
    f.write(xml)
print(f"Wrote {out_path}")
print("Suggested: --duration 3.0")
