"""Compose assignment-A scene mp4s into a single grid showreel.

Mirrors make_showreel.py but only includes scenes rendered in this handoff
package (out/scenes/*.mp4 except showreels themselves).

Usage (from repo root):
    python scenes/gen_a_showreel.py
"""
import math
import os
import subprocess

# Order follows ASSIGNMENT.md; skip entries whose mp4 is not present yet.
MP4S = [
    "out/scenes/bifilar_pendulum.mp4",
    "out/scenes/wilberforce_pendulum.mp4",
    "out/scenes/damped_pendulum_decay.mp4",
    "out/scenes/yoyo_with_reversal.mp4",
    "out/scenes/coin_spiral.mp4",
    "out/scenes/inelastic_collision.mp4",
    "out/scenes/coefficient_of_restitution.mp4",
    "out/scenes/com_pair_track.mp4",
    "out/scenes/beats.mp4",
    "out/scenes/wave_reflection_fixed.mp4",
    "out/scenes/capstan_effect.mp4",
    "out/scenes/falling_chain_classical.mp4",
    "out/scenes/bead_on_helix.mp4",
]

CELL_W = 480
CELL_H = 270
DURATION = 6.0
FPS = 30
BLANK_COLOR = "0xbdaddb"   # scene skybox purple
OUT_PATH = "out/scenes/a_scenes_grid.mp4"


def grid_shape(n):
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    return cols, rows


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    os.chdir(root)

    mp4s = [p for p in MP4S if os.path.isfile(p)]
    missing = [p for p in MP4S if p not in mp4s]
    if missing:
        print("Skipping missing clips:")
        for p in missing:
            print(f"  - {p}")

    if not mp4s:
        raise SystemExit("No assignment-A mp4s found under out/scenes/")

    n_scenes = len(mp4s)
    cols, rows = grid_shape(n_scenes)
    n_total = cols * rows
    n_blanks = n_total - n_scenes

    print(f"{n_scenes} scenes + {n_blanks} blanks -> {cols}x{rows} grid "
          f"({cols * CELL_W}x{rows * CELL_H})")

    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "warning"]
    for mp4 in mp4s:
        cmd += ["-stream_loop", "-1", "-i", mp4]
    for _ in range(n_blanks):
        cmd += ["-f", "lavfi",
                "-i", f"color=c={BLANK_COLOR}:s={CELL_W}x{CELL_H}:"
                       f"d={DURATION}:r={FPS}"]

    filter_parts = []
    for i in range(n_scenes):
        filter_parts.append(
            f"[{i}:v]trim=0:{DURATION},setpts=PTS-STARTPTS,"
            f"scale={CELL_W}:{CELL_H},setsar=1[v{i}]"
        )
    for j in range(n_blanks):
        idx = n_scenes + j
        filter_parts.append(f"[{idx}:v]setsar=1[v{idx}]")

    layout = "|".join(
        f"{c * CELL_W}_{r * CELL_H}"
        for r in range(rows) for c in range(cols)
    )
    inputs_chain = "".join(f"[v{i}]" for i in range(n_total))
    filter_parts.append(
        f"{inputs_chain}xstack=inputs={n_total}:layout={layout}[out]"
    )

    cmd += ["-filter_complex", ";".join(filter_parts)]
    cmd += ["-map", "[out]"]
    cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "medium", "-crf", "20",
            "-r", str(FPS), "-t", str(DURATION)]
    cmd += [OUT_PATH]

    os.makedirs(os.path.dirname(OUT_PATH) or ".", exist_ok=True)
    print("Running ffmpeg...")
    subprocess.run(cmd, check=True)

    size_mb = os.path.getsize(OUT_PATH) / 1e6
    print(f"Wrote {OUT_PATH}  ({size_mb:.1f} MB, "
          f"{cols * CELL_W}x{rows * CELL_H} @ {FPS} fps, {DURATION:.0f} s)")


if __name__ == "__main__":
    main()
