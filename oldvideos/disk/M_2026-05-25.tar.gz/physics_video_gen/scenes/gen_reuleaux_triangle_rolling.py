"""
Generate scenes/reuleaux_triangle_rolling.xml

Reuleaux profile in xz; freejoint rolling with friction.
Top board fixed at constant-width height (no collision).
"""
import math
import os

L = 0.10
THICK = 0.014
SEGMENTS = 14
R_SEG = 0.0065
MASS = 0.12

Rv = L / math.sqrt(3)
verts = [(Rv * math.cos(math.radians(a)), Rv * math.sin(math.radians(a)))
         for a in (0, 120, 240)]


def arc_points(i):
    c = verts[i]
    a = verts[(i + 1) % 3]
    b = verts[(i + 2) % 3]
    ang_a = math.atan2(a[1] - c[1], a[0] - c[0])
    ang_b = math.atan2(b[1] - c[1], b[0] - c[0])
    if ang_b < ang_a:
        ang_b += 2 * math.pi
    return [
        (c[0] + L * math.cos(ang_a + (ang_b - ang_a) * t / SEGMENTS),
         c[1] + L * math.sin(ang_a + (ang_b - ang_a) * t / SEGMENTS))
        for t in range(SEGMENTS + 1)
    ]


def profile_points():
    pts = []
    for i in range(3):
        pts.extend(arc_points(i)[:-1])
    return pts


def seg_geoms():
    lines = []
    mats = ["tri_blue", "tri_dark", "tri_red"]
    z_shift = -min(p[1] for p in profile_points())
    for ai in range(3):
        pts = [(x, z + z_shift) for x, z in arc_points(ai)]
        mat = mats[ai]
        for j in range(len(pts) - 1):
            x0, z0 = pts[j]
            x1, z1 = pts[j + 1]
            z0c = z0 + R_SEG
            z1c = z1 + R_SEG
            lines.append(
                f'      <geom type="capsule" '
                f'fromto="{x0:.5f} {-THICK:.4f} {z0c:.5f} '
                f'{x1:.5f} {THICK:.4f} {z1c:.5f}" '
                f'size="{R_SEG:.4f}" mass="0" material="{mat}"/>'
            )
    return "\n".join(lines)


def main():
    pts = profile_points()
    z_shift = -min(p[1] for p in pts)
    z_max = max(p[1] for p in pts) + z_shift
    z0 = R_SEG + 0.0005
    top_z = z_max + R_SEG + 0.012
    cm_z = z_max * 0.42 + R_SEG
    vx = 0.38
    omega = 12.0

    xml = f"""<mujoco model="reuleaux_triangle_rolling">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="tri_blue" rgba="0.30 0.50 0.78 1" specular="0.35" shininess="0.45"/>
    <material name="tri_dark" rgba="0.30 0.27 0.24 1" specular="0.3" shininess="0.35"/>
    <material name="tri_red" rgba="0.86 0.34 0.30 1" specular="0.35" shininess="0.45"/>
    <material name="cm_marker" rgba="0.96 0.83 0.36 1" specular="0.55" shininess="0.65"/>
    <material name="top_plate" rgba="0.93 0.82 0.58 1" specular="0.12" shininess="0.12"/>
  </asset>

  <default>
    <geom friction="0.65 0.004 0.0001" solref="0.003 1" solimp="0.96 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <geom name="top_board" type="box" size="0.22 0.034 0.002"
          pos="0 0 {top_z:.4f}" material="top_plate"
          contype="0" conaffinity="0"/>

    <body name="reuleaux" pos="-0.35 0 {z0:.4f}">
      <freejoint/>
      <inertial pos="0 0 {cm_z:.4f}" mass="{MASS}"
                diaginertia="0.00012 0.00018 0.00012"/>
{seg_geoms()}
      <geom name="cm" type="sphere" size="0.009" pos="0 0 {cm_z:.4f}"
            mass="0" material="cm_marker" contype="0" conaffinity="0"/>
    </body>

    <camera name="cam" pos="0.10 -1.35 0.12" fovy="38"
            xyaxes="1 0 0   0 0.06 0.998"/>
  </worldbody>
</mujoco>
"""
    out = os.path.join(os.path.dirname(__file__), "reuleaux_triangle_rolling.xml")
    with open(out, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"Wrote {out}  top_z={top_z:.4f}")
    print(f"init-qvel: {vx:.2f} 0 0 0 {omega:.1f} 0")


if __name__ == "__main__":
    main()
