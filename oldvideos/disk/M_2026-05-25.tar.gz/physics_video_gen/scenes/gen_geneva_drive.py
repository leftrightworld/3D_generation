"""Generate scenes/geneva_drive.xml — clean, readable 4-slot Geneva drive."""
import math
import os

DRIVER_R = 0.068
DRIVEN_R = 0.102
CENTER_DIST = 0.138
PIN_R = 0.052
Y = 0.18
Z = 0.56
N_SLOTS = 4

driver_x = -CENTER_DIST * 0.5
driven_x = CENTER_DIST * 0.5

# Four simple radial notches on the driven wheel (dark gaps, no clutter)
slot_geoms = []
for k in range(N_SLOTS):
    ang = k * 2 * math.pi / N_SLOTS
    mx = 0.058 * math.cos(ang)
    mz = 0.058 * math.sin(ang)
    slot_geoms.append(
        f'      <geom type="box" pos="{mx:.4f} 0.016 {mz:.4f}" '
        f'euler="0 {ang:.4f} 0" size="0.048 0.014 0.014" '
        f'material="slot_dark" contype="0" conaffinity="0"/>'
    )

# Single bright index finger on driven rim — rotation is obvious against fixed pointer
slot_geoms.append(
    f'      <geom type="box" pos="{DRIVEN_R - 0.012:.4f} 0.022 0" '
    f'size="0.028 0.010 0.012" material="pin_mat" contype="0" conaffinity="0"/>'
)

slots_xml = "\n".join(slot_geoms)

xml = f"""<mujoco model="geneva_drive">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 0" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="driver_mat" rgba="0.86 0.34 0.30 1" specular="0.4" shininess="0.5"/>
    <material name="driven_mat" rgba="0.30 0.50 0.78 1" specular="0.4" shininess="0.5"/>
    <material name="pin_mat" rgba="0.95 0.82 0.15 1" specular="0.7" shininess="0.8"/>
    <material name="slot_dark" rgba="0.12 0.10 0.08 1" specular="0" shininess="0"/>
    <material name="base_mat" rgba="0.93 0.82 0.58 1" specular="0.1" shininess="0.1"/>
    <material name="hub_mat" rgba="0.55 0.72 0.92 1" specular="0.35" shininess="0.45"/>
    <material name="pointer_mat" rgba="0.20 0.20 0.22 1" specular="0.2" shininess="0.3"/>
  </asset>

  <worldbody>
    <light pos="0 1.5 1.2" dir="0 -0.5 -0.8" directional="true" castshadow="true"
           diffuse="0.88 0.85 0.80" specular="0.2 0.2 0.2"/>
    <light pos="0 -1.2 0.8" dir="0 0.5 -0.6" directional="true" castshadow="false"
           diffuse="0.40 0.40 0.45" specular="0 0 0"/>

    <geom type="box" size="0.22 0.10 0.025" pos="0 {Y} {Z - 0.11:.4f}" material="base_mat"/>
    <!-- Fixed reference pointer (does not rotate — shows driven wheel stepping) -->
    <geom type="box" size="0.004 0.008 0.055" pos="0.108 {Y + 0.022:.4f} {Z + 0.012:.4f}"
          material="pointer_mat" contype="0" conaffinity="0"/>
    <geom type="box" size="0.018 0.008 0.006" pos="0.108 {Y + 0.022:.4f} {Z + 0.068:.4f}"
          material="pointer_mat" contype="0" conaffinity="0"/>

  <!-- Driver: red disc + one yellow drive pin -->
    <body name="driver" pos="{driver_x:.4f} {Y} {Z:.4f}">
      <joint name="driver_spin" type="hinge" axis="0 1 0" damping="0.001"/>
      <geom type="cylinder" size="{DRIVER_R} 0.018" mass="0.10"
            material="driver_mat" euler="1.5708 0 0"/>
      <geom type="cylinder" fromto="{PIN_R - 0.012:.4f} 0.020 0  {PIN_R + 0.022:.4f} 0.020 0"
            size="0.011" material="pin_mat" contype="0" conaffinity="0"/>
      <geom type="sphere" pos="{PIN_R + 0.022:.4f} 0.022 0" size="0.014"
            material="pin_mat" contype="0" conaffinity="0"/>
    </body>

  <!-- Driven: blue disc + four radial slots + yellow index mark -->
    <body name="driven" pos="{driven_x:.4f} {Y} {Z:.4f}">
      <joint name="driven_spin" type="hinge" axis="0 1 0" damping="0.08"/>
      <geom type="cylinder" size="{DRIVEN_R} 0.018" mass="0.14"
            material="driven_mat" euler="1.5708 0 0"/>
      <geom type="cylinder" size="0.030 0.016" mass="0.02"
            material="hub_mat" euler="1.5708 0 0"/>
{slots_xml}
    </body>

    <camera name="cam" pos="0 {Y - 0.82:.4f} {Z:.4f}" fovy="42"
            xyaxes="1 0 0   0 0 1"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "geneva_drive.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out}")
