"""
Compose all C-package scene mp4s into a single grid showreel.

Output: out/scenes/c_all_scenes_grid.mp4

Run from physics_video_gen/:
  python scenes/gen_c_showreel.py
"""
import os
import subprocess

# All C-package scenes (chronological, per RETURN.md).
MP4S = [
    "out/scenes/compound_pendulum_shapes.mp4",
    "out/scenes/triple_pendulum.mp4",
    "out/scenes/spherical_pendulum_2d.mp4",
    "out/scenes/spool_with_string.mp4",
    "out/scenes/mass_through_hole.mp4",
    "out/scenes/reuleaux_triangle_rolling.mp4",
    "out/scenes/rattleback.mp4",
    "out/scenes/basketball_tennis_drop.mp4",
    "out/scenes/line_collision_chain.mp4",
    "out/scenes/two_pendulums_collide.mp4",
    "out/scenes/vertical_spring_mass.mp4",
    "out/scenes/wave_on_heavy_rope.mp4",
    "out/scenes/tipping_vs_sliding.mp4",
    "out/scenes/hanging_chain_catenary.mp4",
    "out/scenes/bead_on_parabolic_wire.mp4",
    "out/scenes/domino_branching.mp4",
    "out/scenes/pyramid_keystone_removal.mp4",
]

COLS = 4
ROWS = 5
CELL_W = 480
CELL_H = 270
DURATION = 5.0
FPS = 30
BLANK_COLOR = "0xbdaddb"
OUT_PATH = "out/scenes/c_all_scenes_grid.mp4"


def main():
    missing = [p for p in MP4S if not os.path.isfile(p)]
    if missing:
        raise FileNotFoundError("Missing mp4(s):\n  " + "\n  ".join(missing))

    n_scenes = len(MP4S)
    n_total = COLS * ROWS
    n_blanks = n_total - n_scenes
    if n_blanks < 0:
        raise ValueError(f"too many scenes ({n_scenes}) for {COLS}x{ROWS} grid")

    print(f"{n_scenes} C scenes + {n_blanks} blank(s) → {COLS}x{ROWS} grid "
          f"({COLS * CELL_W}x{ROWS * CELL_H})")

    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "warning"]
    for mp4 in MP4S:
        cmd += ["-stream_loop", "-1", "-i", mp4]
    for _ in range(n_blanks):
        cmd += ["-f", "lavfi",
                "-i", f"color=c={BLANK_COLOR}:s={CELL_W}x{CELL_H}:d={DURATION}:r={FPS}"]

    filter_parts = []
    for i in range(n_scenes):
        filter_parts.append(
            f"[{i}:v]trim=0:{DURATION},setpts=PTS-STARTPTS,"
            f"scale={CELL_W}:{CELL_H},setsar=1[v{i}]"
        )
    for j in range(n_blanks):
        idx = n_scenes + j
        filter_parts.append(f"[{idx}:v]setsar=1[v{idx}]")

    layout = "|".join(
        f"{c * CELL_W}_{r * CELL_H}"
        for r in range(ROWS) for c in range(COLS)
    )
    inputs_chain = "".join(f"[v{i}]" for i in range(n_total))
    filter_parts.append(
        f"{inputs_chain}xstack=inputs={n_total}:layout={layout}[out]"
    )

    cmd += ["-filter_complex", ";".join(filter_parts)]
    cmd += ["-map", "[out]"]
    cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "medium", "-crf", "20",
            "-r", str(FPS), "-t", str(DURATION)]
    cmd += [OUT_PATH]

    os.makedirs(os.path.dirname(OUT_PATH) or ".", exist_ok=True)
    print("Running ffmpeg…")
    subprocess.run(cmd, check=True)

    size_mb = os.path.getsize(OUT_PATH) / 1e6
    print(f"Wrote {OUT_PATH}  ({size_mb:.1f} MB, "
          f"{COLS * CELL_W}x{ROWS * CELL_H} @ {FPS} fps, {DURATION:.0f} s)")


if __name__ == "__main__":
    main()
