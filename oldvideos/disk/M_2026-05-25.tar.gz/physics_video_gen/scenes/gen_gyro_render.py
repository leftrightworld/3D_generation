"""Render gyroscope_on_string with camera framed on the precessing disc."""
import os

import imageio.v2 as imageio
import mujoco

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SCENE = "scenes/gyroscope_on_string.xml"
OUT = "out/scenes/gyroscope_on_string.mp4"
GRID = "out/gyroscope_on_string_grid.png"

QPOS = [0.9982, 0.06, 0, 0, 0]
QVEL = [0, 0, 0, 80]


def gyro_camera():
    cam = mujoco.MjvCamera()
    cam.type = mujoco.mjtCamera.mjCAMERA_FREE
    cam.lookat[:] = [0.08, 0.18, 1.35]
    cam.distance = 2.5
    cam.azimuth = 95.0
    cam.elevation = -12.0
    return cam


def main():
    model = mujoco.MjModel.from_xml_path(SCENE)
    data = mujoco.MjData(model)
    for i, v in enumerate(QPOS):
        data.qpos[i] = v
    for i, v in enumerate(QVEL):
        data.qvel[i] = v
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, 1080, 1920)
    cam = gyro_camera()
    fps = 30
    duration = 5.0
    spf = max(1, int(round((1.0 / fps) / model.opt.timestep)))

    frames = []
    for _ in range(int(duration * fps)):
        for _ in range(spf):
            mujoco.mj_step(model, data)
        renderer.update_scene(data, camera=cam)
        frames.append(renderer.render())

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    imageio.mimsave(OUT, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {OUT}")

    d2 = mujoco.MjData(model)
    for i, v in enumerate(QPOS):
        d2.qpos[i] = v
    for i, v in enumerate(QVEL):
        d2.qvel[i] = v
    mujoco.mj_forward(model, d2)
    total = int(duration / model.opt.timestep)
    targets = [int(total * k / 7) for k in range(8)]
    imgs, step, gi = [], 0, 0
    while gi < 8:
        mujoco.mj_step(model, d2)
        step += 1
        if step >= targets[gi]:
            renderer.update_scene(d2, camera=cam)
            imgs.append(renderer.render())
            gi += 1

    import numpy as np
    h, w = imgs[0].shape[:2]
    canvas = np.zeros((h * 2, w * 4, 3), dtype=np.uint8)
    for idx, im in enumerate(imgs):
        r, c = idx // 4, idx % 4
        canvas[r * h:(r + 1) * h, c * w:(c + 1) * w] = im
    imageio.imwrite(GRID, canvas)
    print(f"Wrote {GRID}")


if __name__ == "__main__":
    main()
