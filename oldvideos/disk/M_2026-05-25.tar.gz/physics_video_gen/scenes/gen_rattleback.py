"""
Generate scenes/rattleback.xml — Celt stone (rattleback).

Physics: flat sole + skewed inertia (Ixy).  Preferred ωz < 0, wrong ωz > 0.
Demo video (render.py): 2.5s smooth preferred, then wrong-way bob + reverse.
"""
import os

# Side-view hull outline (stern → bow).  Deeper V reads as a boat.
HULL_PROFILE = [
    (-0.062,  0.003),
    (-0.044, -0.003),
    (-0.024, -0.009),
    (-0.002, -0.012),
    ( 0.022, -0.014),
    ( 0.042, -0.008),
    ( 0.060,  0.002),
]
HULL_R = 0.021

INERTIA = "2e-5 8e-5 8.5e-5 2.45e-5 0 0"
Z0 = "0.015"


def hull_capsules():
    lines = []
    for i in range(len(HULL_PROFILE) - 1):
        x0, z0 = HULL_PROFILE[i]
        x1, z1 = HULL_PROFILE[i + 1]
        lines.append(
            f'      <geom type="capsule" '
            f'fromto="{x0:.4f} 0 {z0:.4f}  {x1:.4f} 0 {z1:.4f}" '
            f'size="{HULL_R:.4f}" material="hull" contype="0" conaffinity="0"/>'
        )
    return "\n".join(lines)


XML = f"""<mujoco model="rattleback">
  <!-- Rattleback: Ixy chirality + friction.  render.py plays preferred then wrong spin. -->
  <compiler angle="radian" coordinate="local" autolimits="true" balanceinertia="true"/>
  <option timestep="0.0005" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="5" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="4096" offsamples="4"/>
    <map shadowclip="4" shadowscale="0.6"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="hull" rgba="0.64 0.60 0.55 1" specular="0.22" shininess="0.30"/>
  </asset>

  <default>
    <geom solref="0.008 1" solimp="0.92 0.96 0.003"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"
          friction="0.42 0.005 0.001"/>

    <body name="rattle" pos="0 0 {Z0}">
      <freejoint/>
      <inertial pos="0 0 0" mass="0.05" fullinertia="{INERTIA}"/>

      <!-- Contact sole (symmetric; chirality from inertia). -->
      <geom name="sole" type="ellipsoid" size="0.058 0.024 0.011"
            pos="0 0 -0.001" mass="0" rgba="0 0 0 0"
            friction="0.46 0.008 0.001"/>

      <!-- Hull only — no debug masts / markers / deck strips. -->
{hull_capsules()}
    </body>

    <!-- Centred oblique view on stone at origin. -->
    <camera name="cam" pos="0 -1.05 0.26" fovy="38"
            xyaxes="1 0 0  0 0.12 0.993"/>
  </worldbody>
</mujoco>
"""

if __name__ == "__main__":
    out = os.path.join(os.path.dirname(__file__), "rattleback.xml")
    with open(out, "w", encoding="utf-8") as f:
        f.write(XML)
    print(f"Wrote {out}")
