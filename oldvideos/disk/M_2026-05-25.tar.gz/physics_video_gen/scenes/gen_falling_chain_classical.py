"""
Generate scenes/falling_chain_classical.xml: chain half on table, half over edge.
Links rest ON the tabletop (no z-clipping); table ends exactly at the edge.
"""
import math
import os

N = 22
LINK_LEN = 0.038
LINK_R = 0.0055
LINK_M = 0.010
TABLE_TOP = 0.10          # raised tabletop for clearer fall
TABLE_HALF = 0.025
EDGE_X = 0.0
START_X = -0.48
LINK_Z = TABLE_TOP + LINK_R  # capsule axis center so bottom touches table

bodies = []
for i in range(N):
    x = START_X + (i + 0.5) * LINK_LEN
    z = LINK_Z
    quat = "1 0 0 0"
    # Only links clearly past the edge droop — keep on-table links level
    if x > EDGE_X + LINK_LEN * 0.6:
        over = x - EDGE_X
        droop = min(0.70, 0.25 * over)
        z = LINK_Z - droop
        tilt = min(0.85, 0.28 * over)
        qw = math.cos(tilt * 0.5)
        qy = math.sin(tilt * 0.5)
        quat = f"{qw:.5f} 0 {qy:.5f} 0"
    mat = "link_cream" if i % 2 == 0 else "link_peach"
    if x > EDGE_X:
        mat = "link_blue"
    bodies.append(
        f'    <body name="L{i}" pos="{x:.4f} 0 {z:.4f}" quat="{quat}">\n'
        f'      <joint type="free"/>\n'
        f'      <geom type="capsule" fromto="-{LINK_LEN * 0.5:.4f} 0 0  '
        f'{LINK_LEN * 0.5:.4f} 0 0" size="{LINK_R:.4f}" mass="{LINK_M}" '
        f'material="{mat}"/>\n'
        f'      <site name="s{i}" pos="0 0 0" size="0.004"/>\n'
        f"    </body>"
    )

tendons = []
for i in range(N - 1):
    tendons.append(
        f'    <spatial name="c{i}" stiffness="950" springlength="{LINK_LEN:.4f}"\n'
        f'             damping="0.06" width="0.002" rgba="0.30 0.27 0.24 0.8">\n'
        f'      <site site="s{i}"/>\n'
        f'      <site site="s{i + 1}"/>\n'
        f"    </spatial>"
    )

table_cx = (START_X + EDGE_X) * 0.5
table_half_x = (EDGE_X - START_X) * 0.5

xml = f"""<mujoco model="falling_chain_classical">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.0005" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="5" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="table_mat" rgba="0.78 0.65 0.40 1" specular="0.15" shininess="0.2"/>
    <material name="link_cream" rgba="0.96 0.92 0.85 1" specular="0.15" shininess="0.2"/>
    <material name="link_peach" rgba="0.95 0.78 0.62 1" specular="0.15" shininess="0.2"/>
    <material name="link_blue" rgba="0.36 0.58 0.82 1" specular="0.25" shininess="0.3"/>
  </asset>

  <default>
    <geom friction="0.38 0.015 0.001" solref="0.004 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <!-- Table ends at x=0 so hanging links do not intersect the slab -->
    <geom name="table" type="box" size="{table_half_x:.4f} 0.14 {TABLE_HALF:.4f}"
          pos="{table_cx:.4f} 0 {TABLE_TOP - TABLE_HALF:.4f}" material="table_mat"
          friction="0.42 0.01 0.001"/>

{chr(10).join(bodies)}

    <camera name="cam" pos="0.02 -1.25 0.55" fovy="42"
            xyaxes="0.97 0.24 0   0 0.14 0.99"/>
  </worldbody>

  <tendon>
{chr(10).join(tendons)}
  </tendon>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "falling_chain_classical.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print("Wrote", out)
