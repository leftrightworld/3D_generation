"""Ballistic pendulum: rectangular bullet from left, embeds in block bob, swings together."""
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SCENE = "scenes/ballistic_pendulum.xml"
OUT = "out/scenes/ballistic_pendulum.mp4"
GRID = "out/ballistic_pendulum_grid.png"

MB, MP = 0.03, 0.42
BULLET_HALF_X = 0.035
BOB_HALF_X = 0.09
SLIDE_START = -0.48
EMBED_Q = -BOB_HALF_X + BULLET_HALF_X * 0.4
STUCK_Q = -(BOB_HALF_X - BULLET_HALF_X * 0.25)
HOLD_SEC = 1.0
FIRE_VEL = 2.35


def side_camera():
    cam = mujoco.MjvCamera()
    cam.type = mujoco.mjtCamera.mjCAMERA_FREE
    cam.lookat[:] = [0.0, 0.0, 1.0]
    cam.distance = 4.8
    cam.azimuth = 90.0
    cam.elevation = 0.0
    return cam


def embed(model, data):
    bid = model.joint("bullet_slide").id
    hid = model.joint("hinge").id
    v_in = data.qvel[bid]
    data.qvel[hid] += v_in * MB / (MB + MP) * 2.8
    data.qpos[bid] = STUCK_Q
    data.qvel[bid] = 0.0


def step_physics(model, data, stuck, fired):
    bid = model.joint("bullet_slide").id
    if not fired and data.time >= HOLD_SEC:
        data.qvel[bid] = FIRE_VEL
        fired = True
    if not stuck and fired:
        if data.qpos[bid] >= EMBED_Q and data.qvel[bid] >= 0.0:
            embed(model, data)
            stuck = True
    if stuck:
        data.qpos[bid] = STUCK_Q
        data.qvel[bid] = 0.0
    mujoco.mj_step(model, data)
    return stuck, fired


def sim_substeps(model, data, n_sub, stuck, fired):
    for _ in range(n_sub):
        stuck, fired = step_physics(model, data, stuck, fired)
    return stuck, fired


def main():
    model = mujoco.MjModel.from_xml_path(SCENE)
    data = mujoco.MjData(model)
    data.qpos[0] = 0.0
    data.qpos[1] = SLIDE_START
    data.qvel[1] = 0.0
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, 1080, 1920)
    cam = side_camera()
    fps = 30
    duration = 6.0
    spf = max(1, int(round((1.0 / fps) / model.opt.timestep)))

    stuck = fired = False
    frames = []
    for _ in range(int(duration * fps)):
        stuck, fired = sim_substeps(model, data, spf, stuck, fired)
        renderer.update_scene(data, camera=cam)
        frames.append(renderer.render())

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    imageio.mimsave(OUT, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {OUT}  (hold {HOLD_SEC}s, fire v={FIRE_VEL})")

    d2 = mujoco.MjData(model)
    d2.qpos[0] = 0.0
    d2.qpos[1] = SLIDE_START
    mujoco.mj_forward(model, d2)
    stuck = fired = False
    bid = model.joint("bullet_slide").id
    total = int(duration / model.opt.timestep)
    targets = [int(total * k / 7) for k in range(8)]
    imgs, step, gi = [], 0, 0
    while gi < 8:
        if not fired and d2.time >= HOLD_SEC:
            d2.qvel[bid] = FIRE_VEL
            fired = True
        if not stuck and fired and d2.qpos[bid] >= EMBED_Q and d2.qvel[bid] >= 0.0:
            embed(model, d2)
            stuck = True
        if stuck:
            d2.qpos[bid] = STUCK_Q
            d2.qvel[bid] = 0.0
        mujoco.mj_step(model, d2)
        step += 1
        if step >= targets[gi]:
            renderer.update_scene(d2, camera=cam)
            imgs.append(renderer.render())
            gi += 1

    h, w = imgs[0].shape[:2]
    canvas = np.zeros((h * 2, w * 4, 3), dtype=np.uint8)
    for idx, im in enumerate(imgs):
        r, c = idx // 4, idx % 4
        canvas[r * h:(r + 1) * h, c * w:(c + 1) * w] = im
    imageio.imwrite(GRID, canvas)
    print(f"Wrote {GRID}")


if __name__ == "__main__":
    main()
