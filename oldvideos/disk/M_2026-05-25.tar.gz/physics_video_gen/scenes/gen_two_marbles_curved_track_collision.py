"""Generate scenes/two_marbles_curved_track_collision.xml — U-track + 2 marbles."""
import math
import os

N = 22
A = 0.4  # z = A * x^2
X_MIN, X_MAX = -0.40, 0.40
TRACK_W = 0.08
TRACK_T = 0.008
BALL_R = 0.02
BALL_M = 0.04

segments = []
for i in range(N):
    x0 = X_MIN + (X_MAX - X_MIN) * i / N
    x1 = X_MIN + (X_MAX - X_MIN) * (i + 1) / N
    xm = 0.5 * (x0 + x1)
    zm = A * xm * xm
    dx = x1 - x0
    dz = A * (x1 * x1 - x0 * x0)
    chord = math.hypot(dx, dz) * 1.08
    angle = math.atan2(dz, dx)
    mat = "track_a" if i % 2 == 0 else "track_b"
    segments.append(
        f'    <geom type="box" pos="{xm:.4f} 0 {zm + TRACK_T:.4f}" '
        f'euler="0 {-angle:.4f} 0" size="{chord * 0.5:.4f} {TRACK_W} {TRACK_T}" '
        f'material="{mat}" friction="0 0 0"/>'
    )

x_ball = 0.35
z_ball = A * x_ball * x_ball + BALL_R + TRACK_T * 2

xml = f"""<mujoco model="two_marbles_curved_track_collision">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.0002" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="10" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="track_a" rgba="0.93 0.82 0.58 1" specular="0.12" shininess="0.15"/>
    <material name="track_b" rgba="0.78 0.65 0.40 1" specular="0.12" shininess="0.15"/>
    <material name="ball_red" rgba="0.86 0.32 0.30 1" specular="0.55" shininess="0.7"/>
    <material name="ball_blue" rgba="0.30 0.50 0.78 1" specular="0.55" shininess="0.7"/>
  </asset>

  <default>
    <geom solref="-200000 -20" solimp="0.999 0.9999 0.0001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat" friction="0 0 0"/>

{chr(10).join(segments)}

    <body name="marbleL" pos="{-x_ball:.4f} 0 {z_ball:.4f}">
      <freejoint/>
      <geom type="sphere" size="{BALL_R}" mass="{BALL_M}" material="ball_red" friction="0 0 0"/>
    </body>
    <body name="marbleR" pos="{x_ball:.4f} 0 {z_ball:.4f}">
      <freejoint/>
      <geom type="sphere" size="{BALL_R}" mass="{BALL_M}" material="ball_blue" friction="0 0 0"/>
    </body>

    <camera name="cam" pos="0 -1.5 0.4" fovy="40"
            xyaxes="1 0 0   0 0.15 0.99"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "two_marbles_curved_track_collision.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out}")
