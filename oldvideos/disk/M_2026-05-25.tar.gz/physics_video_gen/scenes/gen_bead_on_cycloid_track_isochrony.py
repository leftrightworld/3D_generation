"""Generate bead_on_cycloid_track_isochrony.xml: cycloid channel + 3 mocap beads."""
import math
import os

R = 0.25
N_SEG = 48
EPS = 0.08
THETA_END = math.pi
TRACK_W = 0.14
TRACK_T = 0.012
WALL_H = 0.028
BALL_R = 0.022
Y = 0.18


def cycloid_xz(th):
    x = R * (th - math.sin(th))
    z = -R * (1 - math.cos(th))
    return x, z


def cycloid_tangent(th):
    tx = 1 - math.cos(th)
    tz = -math.sin(th)
    n = math.hypot(tx, tz)
    return tx / n, tz / n


def cycloid_segment(i):
    th0 = EPS + (THETA_END - EPS) * i / N_SEG
    th1 = EPS + (THETA_END - EPS) * (i + 1) / N_SEG
    thm = 0.5 * (th0 + th1)
    xm, zm = cycloid_xz(thm)
    x0, z0 = cycloid_xz(th0)
    x1, z1 = cycloid_xz(th1)
    chord = math.hypot(x1 - x0, z1 - z0) * 1.06
    tx, tz = cycloid_tangent(thm)
    alpha = -math.atan2(tz, tx)
    half = chord * 0.5
    lines = [
        (f'    <geom type="box" pos="{xm:.4f} {Y} {zm:.4f}" '
         f'euler="0 {alpha:.5f} 0" '
         f'size="{half:.4f} {TRACK_W * 0.5:.4f} {TRACK_T * 0.5:.4f}" '
         f'material="track_cyc" contype="1" conaffinity="1"/>'),
        (f'    <geom type="box" pos="{xm:.4f} {Y - TRACK_W * 0.42:.4f} {zm:.4f}" '
         f'euler="0 {alpha:.5f} 0" '
         f'size="{half:.4f} 0.004 {WALL_H * 0.5:.4f}" '
         f'material="track_cyc" contype="1" conaffinity="1"/>'),
        (f'    <geom type="box" pos="{xm:.4f} {Y + TRACK_W * 0.42:.4f} {zm:.4f}" '
         f'euler="0 {alpha:.5f} 0" '
         f'size="{half:.4f} 0.004 {WALL_H * 0.5:.4f}" '
         f'material="track_cyc" contype="1" conaffinity="1"/>'),
    ]
    return "\n".join(lines)


track_xml = "\n".join(cycloid_segment(i) for i in range(N_SEG))


# Match gen_bead_cycloid_render.py initial angles (avoid cusp singularity)
TH_BEADS = [0.18, 0.55 * math.pi, 0.82 * math.pi]


def bead_mocap_phi(name, phi, mat):
    x, z = cycloid_xz(phi)
    tx, tz = cycloid_tangent(phi)
    nx, nz = -tz, tx
    x += BALL_R * nx
    z += BALL_R * nz
    return (f'    <body name="{name}" mocap="true" pos="{x:.4f} {Y} {z:.4f}">\n'
            f'      <geom type="sphere" size="{BALL_R}" material="{mat}" '
            f'contype="0" conaffinity="0"/>\n'
            f'    </body>')


b1 = bead_mocap_phi("bead1", TH_BEADS[0], "ball_red")
b2 = bead_mocap_phi("bead2", TH_BEADS[1], "ball_blue")
b3 = bead_mocap_phi("bead3", TH_BEADS[2], "ball_yellow")

x_end, z_end = cycloid_xz(THETA_END)
FLOOR_Z = z_end - 0.12
cam_x = x_end * 0.45
cam_z = (z_end + 0.05) * 0.5

xml = f"""<mujoco model="bead_on_cycloid_track_isochrony">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.0005" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="track_cyc" rgba="0.78 0.65 0.40 1" specular="0.15" shininess="0.2"/>
    <material name="ball_red" rgba="0.86 0.32 0.30 1" specular="0.55" shininess="0.7"/>
    <material name="ball_blue" rgba="0.30 0.50 0.78 1" specular="0.55" shininess="0.7"/>
    <material name="ball_yellow" rgba="0.92 0.78 0.36 1" specular="0.55" shininess="0.7"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" pos="0 0 {FLOOR_Z:.3f}" size="40 40 0.1"
          material="floor_mat"/>

{track_xml}

{b1}
{b2}
{b3}

    <camera name="cam" pos="{cam_x:.2f} 0.206 -1.75" fovy="34"
            xyaxes="1 0 0   0 1 0"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "bead_on_cycloid_track_isochrony.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out}")
