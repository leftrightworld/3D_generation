"""
Generate scenes/wave_on_heavy_rope.xml: vertical chain of N links hanging
from a ceiling anchor.  A horizontal pulse at the top propagates downward;
wave speed increases toward the bottom where tension is highest.
"""
import os

N = 28
LINK_LEN = 0.045
LINK_R = 0.012
LINK_M = 0.015
ANCHOR_Z = 2.20
DAMP = 0.08


def nested_links(i):
    """Recursively nest link bodies; link 0 hangs from the anchor post."""
    if i == N - 1:
        return (
            f'    <body name="link{i}" pos="0 0 -{LINK_LEN:.4f}">\n'
            f'      <joint type="ball" damping="{DAMP}"/>\n'
            f'      <geom type="capsule" fromto="0 0 0  0 0 -{LINK_LEN:.4f}" '
            f'size="{LINK_R:.4f}" mass="{LINK_M:.4f}" material="link_mat"/>\n'
            f'    </body>\n'
        )
    inner = nested_links(i + 1)
    return (
        f'    <body name="link{i}" pos="0 0 -{LINK_LEN:.4f}">\n'
        f'      <joint type="ball" damping="{DAMP}"/>\n'
        f'      <geom type="capsule" fromto="0 0 0  0 0 -{LINK_LEN:.4f}" '
        f'size="{LINK_R:.4f}" mass="{LINK_M:.4f}" material="link_mat"/>\n'
        f'{inner}'
        f'    </body>\n'
    )


chain_xml = nested_links(0)

xml = f"""<mujoco model="wave_on_heavy_rope">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="36"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="frame_wood" rgba="0.78 0.65 0.40 1" specular="0.15" shininess="0.2"/>
    <material name="link_mat" rgba="0.55 0.50 0.48 1" specular="0.35" shininess="0.4"/>
  </asset>

  <default>
    <geom friction="0.05 0.005 0.001" solref="0.005 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <geom type="box" size="0.04 0.04 0.15" pos="-0.18 0 {ANCHOR_Z + 0.08:.3f}"
          material="frame_wood" contype="0" conaffinity="0"/>
    <geom type="box" size="0.04 0.04 0.15" pos=" 0.18 0 {ANCHOR_Z + 0.08:.3f}"
          material="frame_wood" contype="0" conaffinity="0"/>
    <geom type="capsule" fromto="-0.18 0 {ANCHOR_Z + 0.15:.3f}  0.18 0 {ANCHOR_Z + 0.15:.3f}"
          size="0.012" material="frame_wood" contype="0" conaffinity="0"/>

    <body name="anchor" pos="0 0 {ANCHOR_Z:.3f}">
      <geom type="sphere" size="0.012" material="frame_wood" contype="0" conaffinity="0"/>
{chain_xml}
    </body>

    <!-- Full rope + frame: anchor z=2.2, bottom ~0.94, include swing room -->
    <camera name="cam" pos="0 -3.2 1.50" fovy="58"
            xyaxes="1 0 0   0 0.10 0.995"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "wave_on_heavy_rope.xml")
with open(out_path, "w") as f:
    f.write(xml)
print(f"Wrote {out_path}  ({N} links, span {N * LINK_LEN:.2f} m)")
