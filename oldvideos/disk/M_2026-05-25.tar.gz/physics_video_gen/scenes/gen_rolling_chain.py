"""
Procedurally generate scenes/rolling_chain.xml: tank-tread chain pulled by a
cart with an integrated drive sprocket.  The chain trails on the floor behind
the sprocket; links pitch up at the front and settle flat at the rear.
"""
import os

N = 22
LINK_LEN = 0.032
LINK_H = 0.009
LINK_W = 0.012
LINK_M = 0.009
SPACING = LINK_LEN * 0.90
D_HINGE = 0.05
PULL_V = 0.55
START_X = -0.15
FLOOR_Z = LINK_H
SPROCKET_R = 0.048
SPROCKET_X = 0.055          # sprocket centre ahead of driver origin (local +x)
SPROCKET_Z = FLOOR_Z + SPROCKET_R

COLORS = ["link_dark", "link_rust", "link_amber", "link_olive"]


def link_body(i):
    indent = "      " + "  " * i
    mat = COLORS[i % len(COLORS)]
    if i > 0:
        joint = (
            f'{indent}<joint name="h{i}" type="hinge" axis="0 1 0" '
            f'limited="true" range="-1.5 1.5" damping="{D_HINGE}"/>'
        )
    else:
        joint = ""
    geom = (
        f'{indent}<geom name="link{i}" type="box" '
        f'pos="{-LINK_LEN / 2:.4f} 0 {LINK_H:.4f}" '
        f'size="{LINK_LEN / 2:.4f} {LINK_W:.4f} {LINK_H:.4f}" '
        f'material="{mat}" mass="{LINK_M}"/>'
    )
    if i < N - 1:
        child = (
            f'{indent}<body name="link{i + 1}" pos="{-SPACING:.4f} 0 0">\n'
            f"{link_body(i + 1)}\n"
            f"{indent}</body>"
        )
        return f"{joint}\n{geom}\n{child}" if joint else f"{geom}\n{child}"
    return f"{joint}\n{geom}" if joint else geom


chain_xml = link_body(0)
tail_len = (N - 1) * SPACING + LINK_LEN
# Chain attaches at the bottom-rear tangent of the sprocket, links run toward -x.
link0_x = SPROCKET_X - SPROCKET_R + 0.006
link0_z = 0.0

xml = f"""<mujoco model="rolling_chain">
  <!-- Tank tread: integrated drive sprocket on the pull cart; chain trails on
       the floor and wraps up at the sprocket (front lift, rear settle). -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="driver_mat" rgba="0.30 0.50 0.78 1" specular="0.40" shininess="0.45"/>
    <material name="link_dark"  rgba="0.32 0.30 0.32 1" specular="0.25" shininess="0.3"/>
    <material name="link_rust"  rgba="0.72 0.38 0.28 1" specular="0.25" shininess="0.3"/>
    <material name="link_amber" rgba="0.88 0.62 0.22 1" specular="0.30" shininess="0.35"/>
    <material name="link_olive"  rgba="0.48 0.58 0.34 1" specular="0.25" shininess="0.3"/>
  </asset>

  <default>
    <geom friction="0.35 0.03 0.001" solref="0.010 1" solimp="0.90 0.97 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <body name="driver" pos="{START_X:.4f} 0 {FLOOR_Z:.4f}">
      <joint name="pull" type="slide" axis="1 0 0" damping="0.002"
             frictionloss="0" range="-0.3 2.5"/>
      <!-- Cart chassis -->
      <geom name="chassis" type="box" size="0.028 0.034 0.012"
            pos="0.018 0 0.010" mass="0.10" material="driver_mat"/>
      <!-- Drive sprocket (part of the cart, not a loose floor prop) -->
      <geom name="sprocket" type="cylinder"
            fromto="{SPROCKET_X:.3f} -0.038 {SPROCKET_R:.3f}  {SPROCKET_X:.3f} 0.038 {SPROCKET_R:.3f}"
            size="{SPROCKET_R:.3f}" material="driver_mat" mass="0.06"/>
      <!-- Chain: trails toward -x on the floor -->
      <body name="link0" pos="{link0_x:.4f} 0 {link0_z:.4f}">
{chain_xml}
      </body>
    </body>

    <camera name="cam" pos="0.20 -0.95 0.20" fovy="42"
            xyaxes="1 0 0   0 0.16 0.987"/>
  </worldbody>
</mujoco>
"""

out_path = os.path.join(os.path.dirname(__file__), "rolling_chain.xml")
with open(out_path, "w") as f:
    f.write(xml)

init_qvel = f"{PULL_V:.4f}" + ",".join(["0"] * (N - 1))
print(f"Wrote {out_path}  (N={N}, tail≈{tail_len:.2f} m, v={PULL_V} m/s)")
print(f"Suggested: --duration 5.0 --init-qvel={init_qvel}")
