"""
Generate symmetry_breaking_ball_on_dome.xml: smooth hemisphere dome (half-ellipsoid
flat on the floor), ball at apex with tiny x-offset → symmetry breaking slide-off.
"""
import os

R = 0.40
BALL_R = 0.015
BALL_M = 0.05
SEED_X = 0.0012
ball_z = R + BALL_R - 0.001

xml = f"""<mujoco model="symmetry_breaking_ball_on_dome">
  <!-- Hemisphere dome: ellipsoid with z half-axis R/2, center at z=R/2 → apex z=R. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="dome_mat" rgba="0.93 0.82 0.58 1" specular="0.18" shininess="0.25"/>
    <material name="ball_blue" rgba="0.30 0.50 0.78 1" specular="0.55" shininess="0.65"/>
  </asset>

  <default>
    <geom friction="0 0 0" solref="0.002 1" solimp="0.97 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"
          friction="0 0 0"/>

    <geom name="dome" type="ellipsoid" size="{R:.3f} {R:.3f} {R/2:.3f}"
          pos="0 0 {R/2:.3f}" material="dome_mat" friction="0 0 0"/>

    <body name="ball" pos="{SEED_X:.4f} 0 {ball_z:.4f}">
      <freejoint/>
      <geom type="sphere" size="{BALL_R:.4f}" mass="{BALL_M:.3f}" material="ball_blue"
            friction="0 0 0"/>
    </body>

    <camera name="cam" pos="0.10 -1.55 0.28" fovy="44"
            xyaxes="1 0 0   0 0.10 0.995"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "symmetry_breaking_ball_on_dome.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print(f"Wrote {out}  R={R} apex_z={R}")
print('Suggested: --duration 3.5')
