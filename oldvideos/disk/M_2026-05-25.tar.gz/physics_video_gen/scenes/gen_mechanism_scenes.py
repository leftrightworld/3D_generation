"""Render mechanism scenes that need constant actuator ctrl during simulation."""
import argparse
import os
import sys

import imageio.v2 as imageio
import mujoco
import numpy as np

SCENES = {
    "planetary_gear_train": {
        "xml": "scenes/planetary_gear_train.xml",
        "mp4": "out/scenes/planetary_gear_train.mp4",
        "grid": "out/planetary_gear_train_grid.png",
        "duration": 3.0,
        "ctrl": 4.0,
    },
    "gear_train_2_gears": {
        "xml": "scenes/gear_train_2_gears.xml",
        "mp4": "out/scenes/gear_train_2_gears.mp4",
        "grid": "out/gear_train_2_gears_grid.png",
        "duration": 3.0,
        "ctrl": 5.0,
    },
    "four_bar_linkage": {
        "xml": "scenes/four_bar_linkage.xml",
        "mp4": "out/scenes/four_bar_linkage.mp4",
        "grid": "out/four_bar_linkage_grid.png",
        "duration": 4.0,
        "ctrl": 4.0,
    },
}


def render_mp4(cfg, width=1920, height=1080, fps=30):
    model = mujoco.MjModel.from_xml_path(cfg["xml"])
    data = mujoco.MjData(model)
    aid = 0 if model.nu > 0 else -1
    if aid >= 0:
        data.ctrl[aid] = cfg["ctrl"]
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)
    steps = max(1, int(round((1.0 / fps) / model.opt.timestep)))
    n_frames = int(round(cfg["duration"] * fps))
    frames = []
    for _ in range(n_frames):
        for _ in range(steps):
            if aid >= 0:
                data.ctrl[aid] = cfg["ctrl"]
            mujoco.mj_step(model, data)
        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())
    os.makedirs(os.path.dirname(cfg["mp4"]) or ".", exist_ok=True)
    imageio.mimsave(cfg["mp4"], frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {cfg['mp4']} ({len(frames)} frames)")


def render_grid(cfg, cols=4, rows=2, width=480, height=270):
    model = mujoco.MjModel.from_xml_path(cfg["xml"])
    data = mujoco.MjData(model)
    aid = 0 if model.nu > 0 else -1
    if aid >= 0:
        data.ctrl[aid] = cfg["ctrl"]
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)
    n_cells = cols * rows
    total = int(round(cfg["duration"] / model.opt.timestep))
    targets = [int(round((i + 1) * total / n_cells)) for i in range(n_cells)]
    cells, idx = [], 0
    for step in range(1, total + 1):
        if aid >= 0:
            data.ctrl[aid] = cfg["ctrl"]
        mujoco.mj_step(model, data)
        if idx < n_cells and step >= targets[idx]:
            renderer.update_scene(data, camera="cam")
            cells.append(renderer.render())
            idx += 1
    while len(cells) < n_cells:
        renderer.update_scene(data, camera="cam")
        cells.append(renderer.render())
    grid = np.concatenate(
        [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)],
        axis=0,
    )
    os.makedirs(os.path.dirname(cfg["grid"]) or ".", exist_ok=True)
    imageio.imwrite(cfg["grid"], grid)
    print(f"Wrote {cfg['grid']}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scene", nargs="?", choices=list(SCENES.keys()) + ["all"], default="all")
    args = ap.parse_args()
    names = list(SCENES.keys()) if args.scene == "all" else [args.scene]
    for name in names:
        cfg = SCENES[name]
        print(f"=== {name} ===")
        render_mp4(cfg)
        render_grid(cfg)


if __name__ == "__main__":
    main()
