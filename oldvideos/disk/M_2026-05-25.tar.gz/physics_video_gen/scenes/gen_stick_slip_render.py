"""Render stick_slip with explicit stick–slip controller (sawtooth motion)."""
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SCENE = "scenes/stick_slip.xml"
OUT = "out/scenes/stick_slip.mp4"
GRID = "out/stick_slip_grid.png"

# Driver index 0, block index 1 (slide joints)
K_SPRING = 55.0
MU_S = 1.05
MU_K = 0.18
REST_LEN = 0.10
DRIVER_V = 0.035


def spring_force(driver_x, block_x):
    stretch = (driver_x + 0.06) - (block_x - 0.06) - REST_LEN
    return K_SPRING * max(0.0, stretch)


def main():
    model = mujoco.MjModel.from_xml_path(SCENE)
    data = mujoco.MjData(model)
    block_mass = 0.45
    f_norm = block_mass * 9.81

    renderer = mujoco.Renderer(model, 1080, 1920)
    fps = 30
    duration = 6.0
    dt = model.opt.timestep
    spf = max(1, int(round((1.0 / fps) / dt)))

    frames = []
    n_frames = int(duration * fps)
    for _ in range(n_frames):
        for _ in range(spf):
            # Slow driver (kinematic)
            data.qpos[0] += DRIVER_V * dt
            data.qvel[0] = DRIVER_V

            drv = data.qpos[0]
            blk = data.qpos[1]
            f = spring_force(drv, blk)

            if f < MU_S * f_norm:
                data.qvel[1] = 0.0
            else:
                # Slip: spring pull minus kinetic friction
                acc = (f - MU_K * f_norm) / block_mass
                data.qvel[1] = max(0.0, data.qvel[1] + acc * dt)
                data.qvel[1] *= 0.985

            data.qpos[1] += data.qvel[1] * dt
            mujoco.mj_forward(model, data)

        renderer.update_scene(data, camera="cam")
        frames.append(renderer.render())

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    imageio.mimsave(OUT, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {OUT}")

    # 2x4 grid
    imgs = []
    d2 = mujoco.MjData(model)
    total_steps = int(duration / dt)
    grid_steps = [int(total_steps * k / 7) for k in range(8)]
    step = gi = 0
    while gi < 8:
        d2.qpos[0] += DRIVER_V * dt
        d2.qvel[0] = DRIVER_V
        drv, blk = d2.qpos[0], d2.qpos[1]
        f = spring_force(drv, blk)
        if f < MU_S * f_norm:
            d2.qvel[1] = 0.0
        else:
            acc = (f - MU_K * f_norm) / block_mass
            d2.qvel[1] = max(0.0, d2.qvel[1] + acc * dt)
            d2.qvel[1] *= 0.985
        d2.qpos[1] += d2.qvel[1] * dt
        mujoco.mj_forward(model, d2)
        step += 1
        if step >= grid_steps[gi]:
            renderer.update_scene(d2, camera="cam")
            imgs.append(renderer.render())
            gi += 1

    h, w = imgs[0].shape[:2]
    canvas = np.zeros((h * 2, w * 4, 3), dtype=np.uint8)
    for idx, im in enumerate(imgs):
        r, c = idx // 4, idx % 4
        canvas[r * h:(r + 1) * h, c * w:(c + 1) * w] = im
    imageio.imwrite(GRID, canvas)
    print(f"Wrote {GRID}")


if __name__ == "__main__":
    main()
