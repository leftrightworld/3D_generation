"""
Generate scenes/wave_reflection_fixed.xml: pulse from the right travels left,
reflects inverted from the fixed (clamped) left end.
"""
import math
import os

N = 34
DX = 0.048
Z0 = 0.20
STIFF = 380
SPRING = DX
DAMP = 0.010

# Pulse launched from the free right end
PULSE_I = N - 9
PULSE_AMP = 0.050
PULSE_SIG = 2.0


def node_body(i):
    x = i * DX
    if i == 0:
        joints = (
            '      <joint name="fix_x" type="slide" axis="1 0 0" '
            'limited="true" range="-0.0001 0"/>\n'
            '      <joint name="z0" type="slide" axis="0 0 1" '
            f'damping="{DAMP}" range="-0.14 0.14"/>\n'
        )
    else:
        joints = (
            f'      <joint name="z{i}" type="slide" axis="0 0 1" '
            f'damping="{DAMP}" range="-0.14 0.14"/>\n'
        )
    mat = "node_red" if i == PULSE_I else "node_cream"
    if i == 0:
        mat = "node_dark"
    return (
        f'    <body name="n{i}" pos="{x:.4f} 0 {Z0:.4f}">\n'
        f"{joints}"
        f'      <geom type="sphere" size="0.011" mass="0.008" material="{mat}"/>\n'
        f'      <site name="s{i}" pos="0 0 0" size="0.004"/>\n'
        f"    </body>"
    )


nodes = "\n".join(node_body(i) for i in range(N))
tendons = []
for i in range(N - 1):
    tendons.append(
        f'    <spatial name="link{i}" stiffness="{STIFF}" springlength="{SPRING:.4f}"\n'
        f'             damping="0.025" width="0.0025" rgba="0.30 0.27 0.24 0.9">\n'
        f'      <site site="s{i}"/>\n'
        f'      <site site="s{i + 1}"/>\n'
        f"    </spatial>"
    )
tendon_xml = "\n".join(tendons)
span = (N - 1) * DX
cam_x = span * 0.5

xml = f"""<mujoco model="wave_reflection_fixed">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="38"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="wall_mat" rgba="0.78 0.65 0.40 1" specular="0.15" shininess="0.2"/>
    <material name="node_cream" rgba="0.96 0.92 0.85 1" specular="0.2" shininess="0.25"/>
    <material name="node_red" rgba="0.86 0.34 0.30 1" specular="0.35" shininess="0.4"/>
    <material name="node_dark" rgba="0.32 0.30 0.32 1" specular="0.25" shininess="0.3"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>
    <geom type="box" size="0.025 0.08 0.16" pos="-0.015 0 {Z0:.3f}" material="wall_mat"/>

{nodes}

    <camera name="cam" pos="{cam_x:.2f} -1.35 {Z0 + 0.02:.2f}" fovy="38"
            xyaxes="0.97 0.24 0   0 0.10 0.995"/>
  </worldbody>

  <tendon>
{tendon_xml}
  </tendon>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "wave_reflection_fixed.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)
print("Wrote", out)
