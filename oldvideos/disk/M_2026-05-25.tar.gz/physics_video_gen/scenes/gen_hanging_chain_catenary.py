"""
Generate scenes/hanging_chain_catenary.xml: chain pinned at both ends.

Starts horizontal; render.py animates sag 0 -> catenary (cosh curve).
"""
import os

N = 40
LINK_R = 0.006
LINK_M = 0.010
X0, X1 = -0.45, 0.45
Z_ANCHOR = 1.0
DAMP = 0.05
DX = (X1 - X0) / (N - 1)


def nested_link(i):
    if i == N - 1:
        return (
            f'    <body name="link{i}" pos="{DX:.5f} 0 0">\n'
            f'      <joint type="hinge" axis="0 1 0" damping="{DAMP}" '
            f'range="-1.55 1.55"/>\n'
            f'      <geom type="capsule" fromto="0 0 0  {DX:.5f} 0 0" '
            f'size="{LINK_R:.4f}" mass="{LINK_M:.4f}" material="link_brass"/>\n'
            f'    </body>\n'
        )
    inner = nested_link(i + 1)
    return (
        f'    <body name="link{i}" pos="{DX:.5f} 0 0">\n'
        f'      <joint type="hinge" axis="0 1 0" damping="{DAMP}" '
        f'range="-1.55 1.55"/>\n'
        f'      <geom type="capsule" fromto="0 0 0  {DX:.5f} 0 0" '
        f'size="{LINK_R:.4f}" mass="{LINK_M:.4f}" material="link_brass"/>\n'
        f'{inner}'
        f'    </body>\n'
    )


chain_xml = nested_link(0)

xml = f"""<mujoco model="hanging_chain_catenary">
  <!-- Horizontal span at t=0; render.py drives catenary sag under gravity. -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="post_wood" rgba="0.78 0.65 0.40 1" specular="0.15" shininess="0.2"/>
    <material name="link_brass" rgba="0.90 0.74 0.36 1" specular="0.65" shininess="0.8"/>
  </asset>

  <default>
    <geom friction="0 0 0" solref="0.005 1" solimp="0.95 0.99 0.001"/>
  </default>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <geom type="box" size="0.028 0.028 0.55" pos="{X0} 0 {Z_ANCHOR - 0.55:.3f}"
          material="post_wood" contype="0" conaffinity="0"/>
    <geom type="box" size="0.028 0.028 0.55" pos="{X1} 0 {Z_ANCHOR - 0.55:.3f}"
          material="post_wood" contype="0" conaffinity="0"/>

    <body name="postL" pos="{X0:.3f} 0 {Z_ANCHOR:.3f}">
      <geom type="sphere" size="0.014" material="post_wood" contype="0" conaffinity="0"/>
{chain_xml}
    </body>

    <body name="postR" pos="{X1:.3f} 0 {Z_ANCHOR:.3f}">
      <geom type="sphere" size="0.014" material="post_wood" contype="0" conaffinity="0"/>
    </body>

    <camera name="cam" pos="0 -2.35 0.88" fovy="50"
            xyaxes="1 0 0   0 0.10 0.995"/>
  </worldbody>

</mujoco>
"""

if __name__ == "__main__":
    out = os.path.join(os.path.dirname(__file__), "hanging_chain_catenary.xml")
    with open(out, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"Wrote {out}  ({N} links, horizontal start)")
