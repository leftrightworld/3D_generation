"""
Generate block_on_block_static_friction.xml: two stacked demos (upper / lower)
on a frictionless floor — bottom block launched at vx along x.

  Upper: high inter-block mu — top rides with bottom.
  Lower: low inter-block mu — bottom slides out; top loses support and falls.

Upper tier: top welded to bottom (one rigid stack). Lower tier: top free so it can fall.
"""
import os

MU_STICK = 0.55
MU_SLIP = 0.03
TIER_GAP = 0.42
VX0 = 1.2
BH = 0.025
TH = 0.025
PLATFORM_TH = 0.004
TOP_Z_LO = BH + TH * 2
TOP_OFF = BH + TH
Z_STACK_HI = TIER_GAP + PLATFORM_TH + BH

xml = f"""<mujoco model="block_on_block_static_friction">
  <!-- Upper = high mu (move together); lower = low mu (top falls). -->
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"
          impratio="3" cone="elliptic"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="6" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="block_bottom" rgba="0.86 0.71 0.42 1" specular="0.15" shininess="0.2"/>
    <material name="block_top_hi" rgba="0.34 0.52 0.80 1" specular="0.35" shininess="0.4"/>
    <material name="block_top_lo" rgba="0.78 0.38 0.38 1" specular="0.35" shininess="0.4"/>
    <material name="lane_hi" rgba="0.55 0.72 0.55 0.30" specular="0" shininess="0"/>
    <material name="lane_lo" rgba="0.72 0.55 0.55 0.30" specular="0" shininess="0"/>
    <material name="divider" rgba="0.55 0.52 0.50 0.6" specular="0" shininess="0"/>
  </asset>

  <worldbody>
    <light pos="0 0 12" dir="-0.30 0.55 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 8" dir="0.40 -0.30 -1" directional="true" castshadow="false"
           diffuse="0.28 0.28 0.34" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"
          friction="0 0 0"/>

    <geom name="pad_lo" type="box" pos="0 0 0.001" size="1.20 0.14 0.001"
          material="lane_lo" contype="0" conaffinity="0"/>
    <geom name="platform_hi" type="box" pos="0 0 {TIER_GAP:.3f}" size="1.20 0.14 {PLATFORM_TH:.4f}"
          material="floor_mat" friction="0 0 0"/>
    <geom name="pad_hi" type="box" pos="0 0 {TIER_GAP + PLATFORM_TH + 0.001:.3f}" size="1.20 0.14 0.001"
          material="lane_hi" contype="0" conaffinity="0"/>
    <geom name="sep" type="box" pos="0 0 {TIER_GAP * 0.5:.3f}" size="1.22 0.15 0.003"
          material="divider" contype="0" conaffinity="0"/>

    <!-- Upper tier: rigid stack (static friction holds — move as one) -->
    <body name="stack_hi" pos="0 0 {Z_STACK_HI:.3f}">
      <joint name="slide_bottom_hi" type="slide" axis="1 0 0" damping="0"/>
      <geom name="bottom_hi_geom" type="box" size="0.10 0.05 {BH:.4f}"
            mass="1.0" material="block_bottom" friction="0.001 0.0001 0.00001"/>
      <body name="top_hi" pos="0 0 {TOP_OFF:.3f}">
        <geom name="top_hi_geom" type="box" size="0.05 0.05 {TH:.4f}"
              mass="0.2" material="block_top_hi"/>
      </body>
    </body>

    <!-- Lower tier: low mu -->
    <body name="bottom_lo" pos="0 0 {BH:.3f}">
      <joint name="slide_bottom_lo" type="slide" axis="1 0 0" damping="0"/>
      <geom name="bottom_lo_geom" type="box" size="0.10 0.05 {BH:.4f}"
            mass="1.0" material="block_bottom" friction="0.001 0.0001 0.00001"/>
    </body>
    <body name="top_lo" pos="0 0 {TOP_Z_LO:.3f}">
      <freejoint name="free_top_lo"/>
      <geom name="top_lo_geom" type="box" size="0.05 0.05 {TH:.4f}"
            mass="0.2" material="block_top_lo"
            friction="{MU_SLIP:.3f} {MU_SLIP*0.1:.4f} 0.001"/>
    </body>

    <camera name="cam" pos="0.12 -1.75 0.30" fovy="38"
            xyaxes="1 0 0   0 0.10 0.995"/>
  </worldbody>
</mujoco>
"""

out = os.path.join(os.path.dirname(__file__), "block_on_block_static_friction.xml")
with open(out, "w", encoding="utf-8") as f:
    f.write(xml)

# qvel: slide_hi(1), slide_lo(1), free_top_lo(6) — only bottom slides get vx
qvel = [VX0, VX0, 0, 0, 0, 0, 0, 0]
print(f"Wrote {out}  mu_hi={MU_STICK} mu_lo={MU_SLIP} tier_gap={TIER_GAP}")
print(f'Suggested: --duration 3.0 --init-qvel "{",".join(str(v) for v in qvel)}"')
