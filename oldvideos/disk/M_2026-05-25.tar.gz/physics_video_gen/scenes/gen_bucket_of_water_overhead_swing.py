"""Generate bucket_of_water_overhead_swing.xml and render with constant omega=4 rad/s."""
import argparse
import os

import imageio.v2 as imageio
import mujoco
import numpy as np

SCENE_DIR = os.path.dirname(os.path.abspath(__file__))
XML_NAME = "bucket_of_water_overhead_swing.xml"
OMEGA = -4.0  # rad/s about +y (counterclockwise side view = full vertical circle)


def write_xml(path: str | None = None) -> str:
    src = os.path.join(SCENE_DIR, XML_NAME)
    if path is None:
        path = src
    # XML is maintained directly; copy-on-write if generating elsewhere.
    if os.path.abspath(path) != os.path.abspath(src):
        with open(src, encoding="utf-8") as f:
            content = f.read()
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
    print(f"Using {path}")
    return path


def render_scene(
    xml_path: str,
    output_path: str,
    duration: float = 3.0,
    fps: int = 30,
    width: int = 1920,
    height: int = 1080,
    camera: str = "cam",
    omega: float = OMEGA,
) -> None:
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    data.qpos[0] = 0.0  # start at bottom
    aid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "spin")
    data.ctrl[aid] = omega
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)
    sim_dt = model.opt.timestep
    steps_per_frame = max(1, int(round((1.0 / fps) / sim_dt)))
    n_frames = int(round(duration * fps))

    bid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "bucket")
    ball = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "water_ball")

    frames = []
    for _ in range(n_frames):
        for _ in range(steps_per_frame):
            data.ctrl[aid] = omega
            mujoco.mj_step(model, data)
        renderer.update_scene(data, camera=camera)
        frames.append(renderer.render())

    turns = abs(data.qpos[0]) / (2 * np.pi)
    rel = np.linalg.norm(data.xpos[ball] - data.xpos[bid])
    print(f"  sim: turns≈{turns:.2f}, bucket_z={data.xpos[bid,2]:.3f}, ball-in-bucket dist={rel:.4f}")

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    imageio.mimsave(output_path, frames, fps=fps, quality=8, macro_block_size=1)
    print(f"Wrote {output_path}  ({len(frames)} frames @ {fps} fps)")


def render_grid(
    xml_path: str,
    output_path: str,
    duration: float = 3.0,
    cols: int = 4,
    rows: int = 2,
    width: int = 480,
    height: int = 270,
    camera: str = "cam",
    omega: float = OMEGA,
) -> None:
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    data.qpos[0] = 0.0
    aid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "spin")
    data.ctrl[aid] = omega
    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)
    n_cells = cols * rows
    total_steps = int(round(duration / model.opt.timestep))
    targets = [int(round((i + 1) * total_steps / n_cells)) for i in range(n_cells)]

    cells = []
    target_idx = 0
    for step in range(1, total_steps + 1):
        data.ctrl[aid] = omega
        mujoco.mj_step(model, data)
        if target_idx < n_cells and step >= targets[target_idx]:
            renderer.update_scene(data, camera=camera)
            cells.append(renderer.render())
            target_idx += 1

    while len(cells) < n_cells:
        renderer.update_scene(data, camera=camera)
        cells.append(renderer.render())

    row_imgs = [np.concatenate(cells[r * cols:(r + 1) * cols], axis=1) for r in range(rows)]
    grid = np.concatenate(row_imgs, axis=0)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    imageio.imwrite(output_path, grid)
    times = [round(duration * (i + 1) / n_cells, 2) for i in range(n_cells)]
    print(f"Wrote {output_path}  ({rows}x{cols}, times: {', '.join(f'{t:.2f}s' for t in times)})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-render", action="store_true")
    ap.add_argument("--duration", type=float, default=3.0)
    args = ap.parse_args()

    write_xml()
    if args.no_render:
        return

    xml_rel = os.path.join("scenes", XML_NAME)
    render_scene(xml_rel, os.path.join("out", "scenes", "bucket_of_water_overhead_swing.mp4"),
                 duration=args.duration)
    render_grid(xml_rel, os.path.join("out", "bucket_of_water_overhead_swing_grid.png"),
                duration=args.duration)


if __name__ == "__main__":
    main()
