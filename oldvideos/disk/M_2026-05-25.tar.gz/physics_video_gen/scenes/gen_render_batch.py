"""Render polished demo scenes (subset with fixes)."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from render import render_scene


if __name__ == "__main__":
    os.chdir(ROOT)
    jobs = [
        ("scenes/yoyo_with_reversal.xml", "out/scenes/yoyo_with_reversal.mp4", 9, None, None),
        ("scenes/coin_spiral.xml", "out/scenes/coin_spiral.mp4", 10,
         [0, 0, 0.034, 0.7193398003386512, 0.6946583704589973, 0, 0],
         [0, 0, 0, 0, -33.97928811864926, 1.1865828878850389]),
        ("scenes/com_pair_track.xml", "out/scenes/com_pair_track.mp4", 5,
         [0.15, -0.15], None),
        ("scenes/capstan_effect.xml", "out/scenes/capstan_effect.mp4", 7, None, None),
        ("scenes/falling_chain_classical.xml", "out/scenes/falling_chain_classical.mp4", 3.5, None, None),
        ("scenes/bead_on_helix.xml", "out/scenes/bead_on_helix.mp4", 7.5, None, None),
    ]
    for scene, out, dur, qp, qv in jobs:
        render_scene(scene, out, duration=dur, init_qpos=qp, init_qvel=qv)
