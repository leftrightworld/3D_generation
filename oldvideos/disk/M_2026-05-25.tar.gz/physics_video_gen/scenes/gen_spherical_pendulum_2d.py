"""
Generate scenes/spherical_pendulum_2d.xml — spherical pendulum on a yaw+tilt
gimbal with a precomputed floor trail (rosette / Lissajous-like path).
"""
import math
import os

import mujoco
import numpy as np

# ---- physics / launch -------------------------------------------------------
L = 0.68
BOB_R = 0.060
BOB_M = 0.12
PIVOT_Z = 2.12
TILT0 = 0.58
YAW_VEL = 0.52
TILT_VEL = 0.44
DAMPING = 0.00012
SIM_DT = 0.001
TRAIL_DURATION = 14.0
TRAIL_STEP = 0.07

BASE_XML = f"""<mujoco model="spherical_pendulum_2d">
  <compiler angle="radian" coordinate="local" autolimits="true"/>
  <option timestep="{SIM_DT}" gravity="0 0 -9.81" integrator="implicitfast"/>

  <visual>
    <headlight diffuse="0 0 0" ambient="0.50 0.48 0.55" specular="0 0 0"/>
    <rgba haze="0.94 0.91 0.90 1"/>
    <global azimuth="120" elevation="-15" offwidth="1920" offheight="1080" fovy="40"/>
    <quality shadowsize="8192" offsamples="8"/>
    <map shadowclip="5" shadowscale="0.7"/>
  </visual>

  <asset>
    <texture type="skybox" builtin="flat"
             rgb1="0.74 0.68 0.86" rgb2="0.74 0.68 0.86"
             width="512" height="512" mark="none" markrgb="0 0 0"/>
    <material name="floor_mat" rgba="0.94 0.91 0.90 1" specular="0" shininess="0"/>
    <material name="wood" rgba="0.93 0.82 0.58 1" specular="0.1" shininess="0.1"/>
    <material name="bob_red" rgba="0.86 0.34 0.30 1" specular="0.45" shininess="0.55"/>
    <material name="string_mat" rgba="0.28 0.25 0.22 1" specular="0" shininess="0"/>
    <material name="ring_mat" rgba="0.55 0.48 0.72 0.35" specular="0" shininess="0"/>
    <material name="trail_mat" rgba="0.86 0.34 0.30 0.55" specular="0" shininess="0"/>
  </asset>

  <worldbody>
    <light pos="2 -2 10" dir="-0.2 0.2 -1" directional="true" castshadow="true"
           diffuse="0.85 0.82 0.78" specular="0.15 0.15 0.15"/>
    <light pos="0 0 9" dir="0 0 -1" directional="true" castshadow="false"
           diffuse="0.35 0.35 0.40" specular="0 0 0"/>

    <geom name="floor" type="plane" size="40 40 0.1" material="floor_mat"/>

    <!-- Central ceiling mount (centered for top-down framing). -->
    <geom type="capsule" fromto="0 0 0.05  0 0 {PIVOT_Z}"
          size="0.022" material="wood"/>
    <geom type="sphere" pos="0 0 {PIVOT_Z}" size="0.028"
          material="wood" contype="0" conaffinity="0"/>

    <!-- Reference rings on the floor (decorative). -->
    <geom type="cylinder" size="0.14 0.14 0.0008" pos="0 0 0.0008"
          material="ring_mat" contype="0" conaffinity="0"/>
    <geom type="cylinder" size="0.24 0.24 0.0008" pos="0 0 0.0008"
          material="ring_mat" contype="0" conaffinity="0"/>
    <geom type="cylinder" size="0.34 0.34 0.0008" pos="0 0 0.0008"
          material="ring_mat" contype="0" conaffinity="0"/>

    <!-- Yaw (azimuth) + tilt (polar): standard spherical-pendulum gimbal. -->
    <body name="yaw_frame" pos="0 0 {PIVOT_Z}">
      <joint name="yaw" type="hinge" axis="0 0 1" damping="{DAMPING}"/>
      <geom type="sphere" size="0.0015" mass="0.0001"
            rgba="0.28 0.25 0.22 1" contype="0" conaffinity="0"/>

      <body name="tilt_frame">
        <joint name="tilt" type="hinge" axis="0 1 0" damping="{DAMPING}"/>
        <geom type="capsule" fromto="0 0 0  0 0 -{L}"
              size="0.0045" material="string_mat"
              contype="0" conaffinity="0"/>
        <geom name="bob" type="sphere" pos="0 0 -{L}" size="{BOB_R}"
              mass="{BOB_M}" material="bob_red"
              contype="0" conaffinity="0"/>
      </body>
    </body>

    <!-- TRAIL_DOTS -->

    <!-- Top-down: centered on pivot, wide enough for full rosette. -->
    <camera name="cam_top" pos="0 0 3.85" fovy="34"
            xyaxes="1 0 0   0 1 0"/>
    <camera name="cam" pos="1.2 -2.2 1.55" fovy="38"
            xyaxes="0.85 0.53 0   -0.05 0.08 0.995"/>
  </worldbody>
</mujoco>
"""


def simulate_trail():
    m = mujoco.MjModel.from_xml_string(BASE_XML.replace("    <!-- TRAIL_DOTS -->\n", ""))
    d = mujoco.MjData(m)
    d.qpos[:] = [0.0, TILT0]
    d.qvel[:] = [YAW_VEL, TILT_VEL]
    gid = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, "bob")
    steps = int(TRAIL_DURATION / SIM_DT)
    stride = max(1, int(TRAIL_STEP / SIM_DT))
    pts = []
    for i in range(steps):
        mujoco.mj_step(m, d)
        if i % stride == 0:
            pts.append((float(d.geom_xpos[gid, 0]), float(d.geom_xpos[gid, 1])))
    return pts


def trail_geoms(pts):
    n = len(pts)
    lines = []
    for i, (x, y) in enumerate(pts):
        t = i / max(n - 1, 1)
        alpha = 0.12 + 0.50 * t
        r = 0.006 + 0.004 * t
        lines.append(
            f'    <geom type="sphere" size="{r:.4f}" '
            f'pos="{x:.5f} {y:.5f} 0.004" '
            f'rgba="0.86 0.34 0.30 {alpha:.3f}" '
            f'contype="0" conaffinity="0"/>'
        )
    return "\n".join(lines)


def main():
    pts = simulate_trail()
    trail = trail_geoms(pts)
    xml = BASE_XML.replace("    <!-- TRAIL_DOTS -->", trail)
    out = os.path.join(os.path.dirname(__file__), "spherical_pendulum_2d.xml")
    with open(out, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"Wrote {out}  ({len(pts)} trail dots, span "
          f"x={np.ptp([p[0] for p in pts]):.2f} "
          f"y={np.ptp([p[1] for p in pts]):.2f})")


if __name__ == "__main__":
    main()
