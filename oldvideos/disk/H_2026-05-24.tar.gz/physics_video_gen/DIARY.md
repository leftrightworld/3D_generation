# physics_video_gen 开发日志

## 项目目标
基于 MuJoCo 的物理场景渲染器，产出一系列 IPhO 力学题型的高质量演示视频。
作为 Sim2Reason / P1 流水线（物理仿真 → 题目生成 → RL 训练）的前端。

风格：紫色 flat skybox + 浅米色地面 + 暖木质结构 + 黄铜/红蓝点缀，
两灯（暖 key + 冷 fill），3/4 视角为主。详见 `~/.claude/.../style_guide.md`。

## 进度（2026-05-23）

**23 个力学场景已完成。**

输出位置：
- 最早的 4 个：`out/`（bowling, marble, pendulum, projectile_jenga）
- 新增 18 个：`out/new_scenes/`

⚠️ 约定：所有**新场景** mp4 渲染到 `out/new_scenes/`，不要往 `out/` 根目录里放。
verify 用的 `*_grid.png` 可以留在 `out/`。

### 已完成清单
| # | 场景 | 物理点 | 备注 |
|---|------|--------|------|
| 1 | bowling | 碰撞 + 摩擦 | 早期 |
| 2 | marble ramp | 重力 + 滚动 | 早期 |
| 3 | pendulum | 单摆周期 | 早期 |
| 4 | projectile + jenga | 抛体 + 塔的稳定性 | 早期 |
| 5 | Newton's cradle | 弹性碰撞 + 动量传递 | 需要刚硬接触 + 小 timestep |
| 6 | double pendulum | 混沌 | |
| 7 | incline + friction | μ 对照（共享面 μ→0） | gotcha #1 |
| 8 | dominoes | 链式倒塌 | 注意 hinge 轴向（gotcha #3） |
| 9 | spring-mass | SHM | tendon 当弹簧 |
| 10 | Atwood | 不可伸长绳 | joint equality（gotcha #6） |
| 11 | spinning top | 进动 + 章动 | ω_min, Ω 初始条件（gotcha #11-13） |
| 12 | conical pendulum | 锥摆 | gimbal 代 ball joint（gotcha #8） |
| 13 | loop-the-loop | 离心力 | 闭环 + 初速度（gotcha #9） |
| 14 | rolling race | I/MR² 对比 | inertial override（gotcha #14） |
| 15 | pendulum waves | 多摆同步图样 | 程序化生成 |
| 16 | coupled pendulums | 拍频 | |
| 17 | block overhang | 调和级数 ∑L/(2k) | |
| 18 | Galileo dropballs | 自由落体等时 | |
| 19 | elastic collision | 等质量速度交换 | freejoint + 刚硬接触（gotcha #16） |
| 20 | brachistochrone | 最速降线 vs 直线 | 程序化生成（cycloid） |
| 21 | Maxwell wheel | 转动 + 平动能量 | slide+hinge equality（gotcha #6 扩展） |
| 22 | beam buckling | Euler 屈曲 | 10 段离散梁 + 扭簧，margin 1.22（gotcha #17） |
| 23 | **rotating fluid** | 离心抛物面（颗粒近似） | 72 颗球当"水"，top-down 视角看出干涸中心 + 环形堆积（gotcha #18） |

### 本次 session 新做的
- **brachistochrone**（之前 session 留下的，已迁到 new_scenes/）
- **Maxwell wheel**（新做，slide+hinge joint equality 实现绳不滑）
- **beam buckling**（新做，离散柱+扭簧+顶端重物，调参三轮才稳）
- **rotating fluid**（新做，颗粒近似流体，160 球太慢→减到 72，侧视看不出来→换 top-down 出环形分布）

### 还没做的
1. **hydrostatic buoyancy**（静水浮力）

颗粒近似在 rotating fluid 里勉强 work（top-down 视角能看出离心环形分布 + 中央干涸），但对浮力来说颗粒比流体差更多——没有静压梯度，浮力本质需要连续介质。可选方案：
- 用颗粒勉强做，效果可能很差
- 跳过，把力学部分宣告收官
- 切换技术栈（Taichi / Genesis / Bullet+SPH）做浮力

### Pipeline
```
渲染：  python3 render.py    --scene scenes/X.xml --out out/new_scenes/X.mp4    --duration T [--init-qpos ...]
验证：  python3 make_grid.py --scene scenes/X.xml --out out/X_grid.png          --duration T --cols 4 --rows 2 [--init-qpos ...]
```
约定：声明做完之前必须看 grid PNG，视频会藏取景/物理问题。

程序化场景的生成脚本：`scenes/gen_*.py`，运行后会写出对应的 `scenes/*.xml`。

## 已踩坑总结
（详见 `~/.claude/projects/-Users-maiwang-physics-video-gen/memory/mujoco_gotchas.md`）

17 条坑，覆盖：
- 接触/摩擦的合成规则
- `<tendon>` 顶层放置
- hinge 轴方向 / 自由关节 qvel 的坐标系
- 弹性碰撞所需的刚硬接触参数
- ball joint 的坑（用 gimbal 替代）
- 顶部稳定性 ω_min, Ω 联立条件
- I/MR² 通过 inertial 覆盖
- Euler 屈曲的 margin/damping 窄窗口

## 下一步
等用户决定要不要做流体那两个；如果跳过，力学部分基本就收官了。
之后顺着 Sim2Reason / P1 思路往下是：
- 给每个场景加上"题目"标注（初末状态、未知量、答案）
- 接入 LLM 做物理 QA 生成
- 用这些场景训练 / 评测物理推理

但那是另一个 repo / 另一个工作流的事，这个 repo 的范围目前是 "scenes + render"。

## Handoff 准备（2026-05-23）

仓库已经整理成可以打包发给员工 / AI agents 继续 scaling 的状态。新增了：

- **[CLAUDE.md](CLAUDE.md)** — AI agents 进 repo 第一个读的文件，告诉它工作流、约定、禁忌
- **[README.md](README.md)** — 人类 onboarding 文档，含 5 步加新场景的 recipe
- **[BACKLOG.md](BACKLOG.md)** — ~70 个候选场景按难度分 3 tier，员工可以 claim
- **[docs/style_guide.md](docs/style_guide.md)** — 视觉风格配方（从 memory 搬进来）
- **[docs/gotchas.md](docs/gotchas.md)** — 18 条已踩坑（从 memory 搬进来）

理论 scaling 上限估算：Tier 1 (~30) + Tier 2 (~25) + Tier 3 (~10) + 已完成 (23)
≈ **88 个力学场景**。5 人并行 1 周可达。再往后就是参数变体，意义递减。

流体 / 电磁 / 光学 / 热力学不在 MuJoCo 适配范围内，已在 BACKLOG Tier 4 明确列出。
