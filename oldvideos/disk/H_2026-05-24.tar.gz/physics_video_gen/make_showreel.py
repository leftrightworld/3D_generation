"""Compose all 23 scene mp4s into a single 5×5 grid showreel video.

   * Each cell: 384×216 (16:9), 30 fps
   * Output:    1920×1080 H.264
   * Per-cell duration: 5 s.  Shorter clips loop; longer ones are trimmed
     from the start.
   * Two cells in the last row are filled with the project's purple skybox
     colour (rgb 0xbdaddb), matching the scene aesthetic.
"""

import os
import subprocess

# Scene order matches DIARY.md (roughly chronological / by topic).
mp4s = [
    "out/bowling.mp4",
    "out/marble.mp4",
    "out/pendulum.mp4",
    "out/projectile_jenga.mp4",
    "out/new_scenes/newton_cradle.mp4",
    "out/new_scenes/double_pendulum.mp4",
    "out/new_scenes/incline_friction.mp4",
    "out/new_scenes/dominoes.mp4",
    "out/new_scenes/spring_mass.mp4",
    "out/new_scenes/atwood.mp4",
    "out/new_scenes/spinning_top.mp4",
    "out/new_scenes/conical_pendulum.mp4",
    "out/new_scenes/loop_the_loop.mp4",
    "out/new_scenes/rolling_race.mp4",
    "out/new_scenes/pendulum_waves.mp4",
    "out/new_scenes/coupled_pendulums.mp4",
    "out/new_scenes/block_overhang.mp4",
    "out/new_scenes/galileo_dropballs.mp4",
    "out/new_scenes/elastic_collision.mp4",
    "out/new_scenes/brachistochrone.mp4",
    "out/new_scenes/maxwell_wheel.mp4",
    "out/new_scenes/beam_buckling.mp4",
    "out/new_scenes/rotating_fluid.mp4",
]

CELL_W   = 384
CELL_H   = 216
COLS     = 5
ROWS     = 5
DURATION = 5.0
FPS      = 30
BLANK_COLOR = "0xbdaddb"   # matches scene skybox purple
OUT_PATH = "out/new_scenes/all_scenes_grid.mp4"

n_scenes = len(mp4s)
n_total  = COLS * ROWS
n_blanks = n_total - n_scenes
assert n_blanks >= 0, f"too many scenes for {COLS}x{ROWS} grid"
print(f"{n_scenes} scenes + {n_blanks} blanks → {COLS}x{ROWS} grid "
      f"({COLS*CELL_W}x{ROWS*CELL_H})")

# ---- build ffmpeg command ----------------------------------------------------
cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "warning"]

# Inputs: looping scene mp4s + blank colour streams for the empty cells.
for mp4 in mp4s:
    cmd += ["-stream_loop", "-1", "-i", mp4]
for _ in range(n_blanks):
    cmd += ["-f", "lavfi",
            "-i", f"color=c={BLANK_COLOR}:s={CELL_W}x{CELL_H}:d={DURATION}:r={FPS}"]

# Per-input filter: trim → reset PTS → scale → square pixels.
filter_parts = []
for i in range(n_scenes):
    filter_parts.append(
        f"[{i}:v]trim=0:{DURATION},setpts=PTS-STARTPTS,"
        f"scale={CELL_W}:{CELL_H},setsar=1[v{i}]"
    )
for j in range(n_blanks):
    idx = n_scenes + j
    filter_parts.append(f"[{idx}:v]setsar=1[v{idx}]")

# xstack layout: row-major.
layout = "|".join(
    f"{c*CELL_W}_{r*CELL_H}"
    for r in range(ROWS) for c in range(COLS)
)
inputs_chain = "".join(f"[v{i}]" for i in range(n_total))
filter_parts.append(
    f"{inputs_chain}xstack=inputs={n_total}:layout={layout}[out]"
)

cmd += ["-filter_complex", ";".join(filter_parts)]
cmd += ["-map", "[out]"]
cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-preset", "medium", "-crf", "20",
        "-r", str(FPS), "-t", str(DURATION)]
cmd += [OUT_PATH]

os.makedirs(os.path.dirname(OUT_PATH) or ".", exist_ok=True)
print("Running ffmpeg…")
subprocess.run(cmd, check=True)

# Report final file size
size_mb = os.path.getsize(OUT_PATH) / 1e6
print(f"Wrote {OUT_PATH}  ({size_mb:.1f} MB, "
      f"{COLS*CELL_W}x{ROWS*CELL_H} @ {FPS} fps, {DURATION:.0f} s)")
