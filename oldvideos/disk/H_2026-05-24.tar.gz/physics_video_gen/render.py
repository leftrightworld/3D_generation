import argparse
import os
import sys

import mujoco
import numpy as np
import imageio.v2 as imageio


def render_scene(xml_path, output_path,
                 duration=5.0, fps=30,
                 width=1920, height=1080,
                 init_qpos=None, init_qvel=None, camera="cam"):
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    if init_qpos is not None:
        for i, v in enumerate(init_qpos):
            if i < model.nq:
                data.qpos[i] = v

    if init_qvel is not None:
        for i, v in enumerate(init_qvel):
            if i < model.nv:
                data.qvel[i] = v

    mujoco.mj_forward(model, data)

    renderer = mujoco.Renderer(model, height=height, width=width)

    sim_dt = model.opt.timestep
    frame_dt = 1.0 / fps
    steps_per_frame = max(1, int(round(frame_dt / sim_dt)))
    n_frames = int(round(duration * fps))

    frames = []
    for i in range(n_frames):
        for _ in range(steps_per_frame):
            mujoco.mj_step(model, data)
        renderer.update_scene(data, camera=camera)
        frame = renderer.render()
        frames.append(frame)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    imageio.mimsave(output_path, frames, fps=fps, quality=8,
                    macro_block_size=1)
    print(f"Wrote {output_path}  ({len(frames)} frames @ {fps} fps, {width}x{height})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scene", required=True, help="MuJoCo XML path")
    ap.add_argument("--out", required=True, help="Output MP4 path")
    ap.add_argument("--duration", type=float, default=5.0)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--init-qpos", type=str, default=None,
                    help="Comma-separated initial joint positions")
    ap.add_argument("--init-qvel", type=str, default=None,
                    help="Comma-separated initial joint velocities")
    ap.add_argument("--camera", type=str, default="cam")
    args = ap.parse_args()

    init_qpos = None
    if args.init_qpos:
        init_qpos = [float(x) for x in args.init_qpos.split(",")]
    init_qvel = None
    if args.init_qvel:
        init_qvel = [float(x) for x in args.init_qvel.split(",")]

    render_scene(args.scene, args.out,
                 duration=args.duration, fps=args.fps,
                 width=args.width, height=args.height,
                 init_qpos=init_qpos, init_qvel=init_qvel,
                 camera=args.camera)


if __name__ == "__main__":
    main()
