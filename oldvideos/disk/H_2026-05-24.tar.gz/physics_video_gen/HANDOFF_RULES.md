# Handoff package rules

You're working in a generated employee handoff package, not the master repo.
Read this file in addition to `CLAUDE.md`. In summary:

- **Read `ASSIGNMENT.md` at the root.** That's your specific task list for
  this round. Don't pick scenes from `BACKLOG.md` that aren't in your
  assignment.
- **Only ADD files**, never modify existing ones, in these locations:
  - `scenes/*.xml`
  - `scenes/gen_*.py`
  - `out/new_scenes/*.mp4`
- **Never modify** `render.py`, `make_grid.py`, `make_showreel.py`,
  `CLAUDE.md`, `README.md`, `BACKLOG.md`, `DIARY.md`, this file, or anything
  under `docs/`. If you have suggestions for those, write them in
  `RETURN.md` and the master keeper will merge them in.
- **If a scene is blocked or impossible:** don't substitute a different
  scene. Mark it incomplete in `RETURN.md` with an explanation.
- **Fill in `RETURN.md` before sending the package back.** Include any new
  gotchas you discovered — those go into the shared docs for everyone's
  benefit.
- The master keeper merges everyone's returns into the master each day and
  re-issues new packages with updated assignments. Existing scenes,
  gotchas, and backlog status visible in your package reflect the state at
  the time it was built — there may be newer work happening in parallel.
