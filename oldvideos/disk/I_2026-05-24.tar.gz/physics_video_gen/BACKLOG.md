# Scene Backlog

**Status (2026-05-23):** 23 done, **~90 candidates** queued with full
descriptions, ~10 explicitly out-of-scope. Theoretical ceiling ≈ 88–92
genuinely-distinct mechanics scenes (no parameter sweeps); beyond that, the
next idea is just "the same with different numbers".

## How to use this file

1. **Pick an item** from your `ASSIGNMENT.md` (in handoff packages) or any
   unclaimed item here (master only).
2. **Read its full description** — `Physics`, `Setup`, `Expected motion`,
   `Template`, `Hints`. The Template line tells you which existing scene to
   copy from as a starting point. Don't write from scratch.
3. **Build it** following the 5-step recipe in `CLAUDE.md` / `README.md`.
4. **Mark done** in `DIARY.md` when finished, strike the line here.

## Conventions for each entry

```
### `scene_filename` — Topic tag

**Physics:** One sentence on the concept being demonstrated.
**Setup:** Physical arrangement, initial conditions, what bodies + joints exist.
**Motion:** What the rendered clip should show.
**Template:** Which existing scene to copy from as a starting point.
**Hints:** Key parameter values, common pitfalls, gotchas to watch (cross-ref `docs/gotchas.md` when relevant).
```

---

## ✅ Done (23 scenes)

See `DIARY.md` for the inventory and notes. mp4s in `out/` (original 4) and
`out/new_scenes/` (the rest). Showreel at
`out/new_scenes/all_scenes_grid.mp4`.

| # | scene | topic |
|---|-------|-------|
| 1 | bowling | collision + friction |
| 2 | marble | gravity + rolling |
| 3 | pendulum | simple oscillation |
| 4 | projectile_jenga | projectile + stability |
| 5 | newton_cradle | elastic chain |
| 6 | double_pendulum | chaos |
| 7 | incline_friction | μ comparison |
| 8 | dominoes | chain reaction |
| 9 | spring_mass | SHM |
| 10 | atwood | inextensible string |
| 11 | spinning_top | precession + nutation |
| 12 | conical_pendulum | circular motion |
| 13 | loop_the_loop | centripetal force |
| 14 | rolling_race | I/MR² |
| 15 | pendulum_waves | multi-pendulum sync |
| 16 | coupled_pendulums | normal modes |
| 17 | block_overhang | ∑L/(2k) harmonic series |
| 18 | galileo_dropballs | equivalence of fall time |
| 19 | elastic_collision | momentum transfer |
| 20 | brachistochrone | cycloid vs straight |
| 21 | maxwell_wheel | rotational+translational KE |
| 22 | beam_buckling | Euler instability |
| 23 | rotating_fluid | centrifugal pile-up |

---

## 🔵 Tier 1 — Quick wins (1–2 hr each, copy + tweak)

### Pendulum / oscillation (7)

#### `bifilar_pendulum` — Oscillation
**Physics:** Mass suspended by two parallel strings swings, but rotation about the vertical is geometrically blocked. Period depends on string length and lateral separation.
**Setup:** A horizontal rod (or thin plate) hangs from two vertical strings at its two ends. Push it sideways; it swings without rotating.
**Motion:** Rod translates sideways in pure swing; no twisting about its own axis.
**Template:** `pendulum.xml`. Use two tendons instead of one.
**Hints:** Use spatial tendons (`<tendon><spatial>`) for the two strings — see gotcha #2 for placement. Rod needs a freejoint or a slide+slide joint pair; constraints from the two tendons enforce no rotation. Render ~4 s.

#### `trifilar_pendulum` — Oscillation
**Physics:** Disc suspended by three equally spaced strings; angular oscillation period is sensitive to the disc's moment of inertia (this is how I is measured experimentally).
**Setup:** Horizontal disc hung from a ceiling triangle by three vertical strings (radius r, length L). Twist the disc slightly about the vertical axis; it oscillates torsionally.
**Motion:** Disc rotates back and forth about its vertical axis with period T = 2π·sqrt(I·L/(m·g·r²)).
**Template:** `pendulum.xml` + `atwood.xml` (for the tendon-as-string idea). Three tendons, one disc, init-qpos a small yaw.
**Hints:** Use a single hinge joint about z for the disc, with NO stiffness. The "restoring" comes purely from the three-string geometry — strings tilt as the disc rotates, giving a gravitational restoring torque. Disc body needs a freejoint or constrained body.

#### `compound_pendulum_shapes` — Oscillation
**Physics:** Period of a rigid-body pendulum depends on I_pivot, not just mass — three different shapes pivoted at one end swing at different periods even with the same mass.
**Setup:** Three pendulums side-by-side: a thin rod, a flat plate, and a thin triangular plate, all pivoted at their top with hinge joints. Same mass each.
**Motion:** Released from the same angle, the three swing at visibly different periods.
**Template:** `pendulum.xml`. Replicate 3× with different geom types.
**Hints:** Compute I_pivot for each shape (parallel-axis theorem). Use `<inertial>` to override if needed — gotcha #14. Side-view camera, fovy ~40.

#### `wilberforce_pendulum` — Oscillation / coupling
**Physics:** Mass hangs on a spring with both longitudinal and torsional stiffness. With matched periods, energy slowly trades between bobbing and twisting.
**Setup:** Cylindrical bob hangs from a long thin coiled "spring" (modelled by a tendon for visual + a custom stiff+damped joint pair). Bob has a slide joint (z) and a hinge joint (about z). Both joints have stiffness and similar periods.
**Motion:** Initially the bob bobs up-and-down; over 5–10 oscillations the bobbing dies and the bob is twisting; then it twists back to bobbing. Beats.
**Template:** `spring_mass.xml` + `spinning_top.xml`.
**Hints:** Tune k_slide and k_torsion so periods match within 5%. Add small initial qvel in slide only; the coupling (which we'd add via a constraint or pre-existing geometry) will transfer energy. If pure-MuJoCo coupling is hard, use a small `<equality>` linking the two joints with a tiny polycoef. Render 15+ s.

#### `damped_pendulum_decay` — Oscillation
**Physics:** A pendulum with viscous damping shows exponential decay of amplitude: θ(t) = θ₀·e^(-γt)·cos(ωt). Period is nearly unchanged for light damping.
**Setup:** Single pendulum with a moderate joint damping value.
**Motion:** ~8–10 visible swings, each successively smaller; eventually settles to rest.
**Template:** `pendulum.xml`. Add `damping="0.05"` to the hinge.
**Hints:** Pick damping so the envelope decay is visible within 8 s (try 0.04). Camera: same as `pendulum.xml`. Grid PNG should show monotonically decreasing amplitude.

#### `pendulum_with_air_drag` — Oscillation
**Physics:** Quadratic drag (∝ ω²) decays a pendulum faster at large amplitudes than viscous damping; the envelope curves rather than being a clean exponential.
**Setup:** Same as damped pendulum but with quadratic damping if MuJoCo supports it, otherwise high linear damping that mimics drag.
**Motion:** Initially fast amplitude decay, slowing as amplitude shrinks.
**Template:** `pendulum.xml`.
**Hints:** MuJoCo joint damping is linear in ω. To fake quadratic, use a large linear damping and accept the qualitative behavior. Side-by-side render with `damped_pendulum_decay` would be ideal but each scene is rendered alone.

#### `triple_pendulum` — Chaos
**Physics:** Adding a third link to the double pendulum increases chaotic sensitivity; the trajectory is wildly path-dependent on initial conditions.
**Setup:** Three rigid arms connected by hinges in series, top pivot fixed. Link lengths 0.30 / 0.25 / 0.20 m, masses 0.15 / 0.12 / 0.10 kg (decreasing as you go down — like double_pendulum). Each hinge has axis y, damping=0.005.
**Motion:** From `init-qpos="1.4, 0, 0"` (top link near horizontal, others vertical), the system rapidly transitions to chaotic flailing where all three links swing wildly.
**Template:** `double_pendulum.xml`. Add a third nested body with the same hinge axis.
**Hints:** Render 8 s — chaos takes a few seconds to fully develop. Camera same as double_pendulum (front view, fovy 38). Damping smaller than double_pendulum so motion lasts longer.

### Rolling / rotation (4)

#### `yoyo_with_reversal` — Rotation
**Physics:** Like Maxwell wheel but the wheel hits the lower string limit and re-ascends — the string catches and the rotation direction reverses with respect to descent.
**Setup:** Modified Maxwell wheel where the slider joint hits a "stop" at the bottom, causing the equality constraint to allow re-ascent.
**Motion:** Disc descends, rotates, hits bottom, climbs back up while spinning the same way.
**Template:** `maxwell_wheel.xml`. Add a slider range stop at the bottom.
**Hints:** The polycoef equality may bind oddly at the range limit — use stiff `solref` for the slider's range so the bounce is mostly elastic. Render 6–8 s to see one full cycle.

#### `rolling_cone` — Rotation
**Physics:** A cone rolling on its side traces a circular path centered on its apex (precession of the rolling axis).
**Setup:** A cone (apex on the floor) rolls in a circular path. Use a thin cone geom or build from segments.
**Motion:** Cone rolls around its apex, completing a circle in proportion to its half-angle.
**Template:** `rolling_race.xml`.
**Hints:** Body needs a freejoint + rolling-without-slip via friction. Initial spin matters: give it angular velocity so it starts rolling, not skidding. fovy ~38, top-down 3/4 camera. Render 4–6 s.

#### `spool_with_string` — Rotation / counter-intuitive
**Physics:** A spool with string wrapped underneath — pulling the string horizontally rolls the spool TOWARD you (not away). Surprising visual.
**Setup:** Spool (cylinder with a smaller axle) on the floor. String wraps under the axle and exits horizontally toward +x. Pull the string by ramping a tension.
**Motion:** Spool rolls in +x direction while string unwinds and the spool's axle moves toward you.
**Template:** `marble.xml` + `maxwell_wheel.xml`.
**Hints:** No actuator needed if you set the spool's initial qvel so it's already in motion. Alternatively, attach the string end to a stationary point and give the spool a small push so the tension acts. Camera: side view.

#### `rolling_chain` — Rotation
**Physics:** A flexible chain laid flat on the floor can be pulled like a tank tread — the chain "rolls" by having parts continuously transition between contact and free-fall.
**Setup:** Long chain of small linked bodies on the floor; one end is given a horizontal velocity.
**Motion:** The chain moves like a tractor tread, with the leading end being lifted by tension and falling at the rear.
**Template:** `dominoes.xml` (chain layout) + `atwood.xml` (linked bodies).
**Hints:** Probably needs ~30 small links with friction-enabled contact. Render 4–5 s. May need a programmatic generator (`gen_rolling_chain.py`).

### Collision / momentum (6)

#### `inelastic_collision` — Collision
**Physics:** Two bodies stick together after impact; kinetic energy is lost but momentum is conserved.
**Setup:** Two cubes on a frictionless track; one moving toward the other. On contact, they stick (via high-damping contact or an equality constraint that activates).
**Motion:** Moving block hits stationary block, both move off together at half the original velocity (for equal masses).
**Template:** `elastic_collision.xml`.
**Hints:** Disable elastic contact: set `solref` and `solimp` to soft values so the impact dissipates. Or use a tendon equality that snaps in on contact (advanced). Camera: same as elastic_collision.

#### `coefficient_of_restitution` — Collision
**Physics:** A ball bouncing on a floor loses a fixed fraction of energy per bounce. Successive bounce heights follow h_n = h_0 · e^(2n), giving geometric decay.
**Setup:** Single ball dropped from a height onto a hard floor, with contact `solref/solimp` tuned for partially elastic collision.
**Motion:** Ball bounces with decreasing height; the envelope shows geometric decay over 5–8 bounces.
**Template:** `bowling.xml` (for floor + ball pattern).
**Hints:** Use `solref="-100000 -8" solimp="0.98 0.999 0.001"` for ~85% restitution. Camera: side view, frame from 0 to drop height. Render 4–5 s.

#### `ballistic_pendulum` — Collision + oscillation
**Physics:** A "bullet" embeds in a pendulum bob; momentum conservation gives the bob's swing velocity; energy conservation gives the swing height. The combo lets you measure the bullet's speed.
**Setup:** Small fast cube (the bullet) flies horizontally into a heavier cube hanging on a string (the bob). On contact, the bullet sticks (inelastic).
**Motion:** Bullet → impact → bob+bullet swing as one pendulum to a measurable height.
**Template:** `pendulum.xml` + `projectile_jenga.xml`.
**Hints:** Inelastic contact (soft solref) on the bob-bullet pair. Mass ratio matters: bullet/bob ≈ 0.05 gives a visible but modest swing. Camera: side view.

#### `basketball_tennis_drop` — Collision / energy transfer
**Physics:** Stacked balls dropped together; the bottom one bounces off the floor and immediately collides with the top one, transferring kinetic energy upward. The small top ball can shoot up at ~3× the drop speed.
**Setup:** Two balls stacked vertically (small one on top of big one), released from a height.
**Motion:** Big ball hits floor and rebounds; immediately collides with small ball mid-air; small ball flies up far higher than its drop height.
**Template:** `bowling.xml` + `elastic_collision.xml`.
**Hints:** Use very high contact stiffness (`solref="-200000 -20"`) for both bottom-ball-to-floor AND ball-to-ball contacts. Initial separation between balls: 0.01 m (almost touching). Mass ratio ~10:1 (heavy:light) gives the cleanest effect.

#### `glancing_2d_collision` — Collision
**Physics:** Equal-mass elastic collision at an angle: the two balls fly off at 90° to each other. Their final velocity vectors form a right angle.
**Setup:** Two pucks on a frictionless table; one moving, the other stationary, with a small lateral offset so the impact is glancing (not head-on).
**Motion:** Moving puck strikes glancingly; both pucks scatter at angles that sum to 90°.
**Template:** `elastic_collision.xml`. Switch to 2D (top-down camera).
**Hints:** Pucks on a slide-x and slide-y joint pair (no rotation). High contact stiffness, zero friction between pucks and floor. Top-down camera. Render 2 s.

#### `line_collision_chain` — Collision
**Physics:** Newton's cradle without the strings — a row of touching balls. Striking the leftmost transmits momentum along the line; only the rightmost moves off.
**Setup:** 5 balls in a horizontal row on a frictionless track, just barely touching. Add 1 more ball arriving from the left with some velocity.
**Motion:** Incoming ball strikes, momentum "walks" down the line in an instant, the rightmost ball leaves at the incoming velocity.
**Template:** `newton_cradle.xml` (for contact tuning) + `elastic_collision.xml` (for track).
**Hints:** Use the same stiff contact + small timestep recipe as Newton's cradle (gotcha #4). Balls on freejoints, frictionless track. Energy still leaks (not perfectly elastic) but the qualitative effect is striking.

### Spring / oscillator (4)

#### `beats` — Oscillation
**Physics:** Two mass-spring oscillators with slightly different frequencies appear to slowly modulate each other's amplitude when started in phase. The envelope frequency is the difference frequency.
**Setup:** Two separate mass-spring systems side-by-side, with k values differing by ~5%. Both released with the same initial displacement.
**Motion:** Both bodies oscillate; their RELATIVE phase drifts. Watched together, the visual "beats" pattern is the slow envelope.
**Template:** `spring_mass.xml`. Replicate 2× with slightly different k.
**Hints:** Need to render long enough for the difference frequency to manifest — beat period = 2π/(ω₁-ω₂). If ω₁=2π, ω₂=2π·0.95, beat period = 2π/0.314 ≈ 20 s. Render 25 s or use larger Δk. Camera: front view showing both side by side.

#### `normal_modes_2mass` — Oscillation
**Physics:** Two masses with three springs (wall–m–m–wall) have two normal modes: symmetric (both move together) at lower frequency, antisymmetric (move oppositely) at higher frequency.
**Setup:** Two masses on a horizontal frictionless track, three springs in series. Initial conditions chosen to excite ONE mode only (e.g., symmetric: both same displacement; antisymmetric: equal but opposite).
**Motion:** Demonstrates pure mode: in symmetric mode the gap between masses stays constant; in antisymmetric mode the gap oscillates twice per cycle.
**Template:** `spring_mass.xml`.
**Hints:** Use tendons as visual springs + slide joints with stiffness for the dynamics. Render two versions (one for each mode) if desired, or just pick antisymmetric (more visually striking). Camera: side view.

#### `vertical_spring_mass` — Oscillation
**Physics:** Mass on a vertical spring oscillates about its STRETCHED equilibrium (where spring force = mg), not the unstretched length. Period is unchanged: T = 2π·sqrt(m/k).
**Setup:** Spring (tendon + stiffness) hanging from a ceiling point; mass attached at the bottom. Release from above the equilibrium (or below).
**Motion:** Mass oscillates vertically about the equilibrium height; equilibrium is BELOW the unstretched-spring height.
**Template:** `spring_mass.xml`.
**Hints:** k tuned so equilibrium stretch is visible (e.g., 5–10 cm). Mark the equilibrium with a thin horizontal line for clarity. Camera: side view.

#### `pendulum_with_lateral_spring` — Oscillation / coupling
**Physics:** A pendulum attached to a horizontal wall-spring shows mode coupling: pure swing and pure spring oscillation are eigenstates only when carefully tuned; otherwise energy sloshes between them.
**Setup:** Hinge-pivoted pendulum with a spring connecting its mass to a horizontal wall.
**Motion:** Initially energy goes into the pendulum swing; over time it transfers to the spring's vibration, then back.
**Template:** `pendulum.xml` + `spring_mass.xml`.
**Hints:** Tune string length and spring k so the periods are close — that gives the strongest beats-like transfer. Render 15 s.

### Constraint / mechanical advantage (3)

#### `block_and_tackle` — Mechanical advantage
**Physics:** A 2:1 pulley system halves the force needed to lift a mass (and doubles the distance). This is Atwood with an extra pulley.
**Setup:** Heavy mass on one end of a rope; rope goes over a fixed pulley, around a movable pulley attached to a lighter mass, and ends fixed to the ceiling.
**Motion:** Heavy mass descends slowly; the light load lifts up (also slowly) because the rope on the movable pulley side bears HALF the tension.
**Template:** `atwood.xml`. Add a second pulley + joint-equality coupling: q_heavy + 2·q_light = 0.
**Hints:** Polycoef "0 -0.5 0 0 0" enforces q_heavy = -0.5·q_light (i.e., 2:1 ratio). Mass ratio matters: heavy ≈ 1.0, light ≈ 0.45 to see clean lifting at moderate damping.

#### `mass_on_frictionless_incline` — Constraint
**Physics:** Block on a frictionless inclined plane has acceleration a = g·sin(θ) regardless of mass.
**Setup:** Inclined ramp + a block constrained to slide along its surface (slide joint along the ramp's surface direction).
**Motion:** Block accelerates down the ramp; with no friction, motion is pure linear acceleration along the slope.
**Template:** `incline_friction.xml`. Drop friction to 0.
**Hints:** Set ALL friction values to 0 (block AND ramp — gotcha #1!). Slide joint along the ramp surface gives clean physics without contact instability. Camera: side view. Render 2 s.

#### `incline_with_pulley` — Constraint / Atwood variant
**Physics:** Mass on an incline connected over a pulley to a hanging mass — system accelerates if hanging weight > sin(θ)·incline weight. Classic IPhO-style problem.
**Setup:** Inclined ramp + a block on it + a pulley at the top of the ramp + a string over the pulley + a hanging mass on the other side.
**Motion:** If hanging mass is heavy enough, it descends and pulls the incline block up the ramp; otherwise the reverse.
**Template:** `atwood.xml` + `incline_friction.xml`.
**Hints:** Use joint equality (Atwood-style) between the slide joint on incline and the slide joint of the hanging mass. Adjust masses so the dynamics are visible over 3–4 s. Damping in both joints.

### Friction (4)

#### `capstan_effect` — Friction / wrap
**Physics:** A rope wrapped around a fixed cylinder needs only a small holding force to resist a large pulling force; the ratio scales exponentially with wrap angle: F_pull/F_hold = e^(μθ).
**Setup:** Vertical post on the floor; rope wrapped 1.5 turns around it; one end has a heavy weight (10 kg); the other end has a light weight (0.5 kg, hanging just over the edge).
**Motion:** Despite the huge mass ratio, the rope holds — light weight doesn't get lifted because friction along the wrap absorbs the tension.
**Template:** `atwood.xml` (for tendons + hanging weights) + `dominoes.xml` (post setup).
**Hints:** Use a thin spatial tendon for the rope; friction interaction may be approximate. Could fake the effect with a 2:1 joint equality if direct wrap-friction is too hard. Render 5 s.

#### `stick_slip` — Friction
**Physics:** Block dragged by a spring shows alternating stick-and-slip: builds tension until static friction breaks, then slips forward, then sticks again. Generates characteristic sawtooth motion.
**Setup:** Block on floor with high static friction; attached by a spring to a slowly-moving driver. (Driver moves via init-qvel.)
**Motion:** Block sits still while spring stretches, then suddenly jumps forward; then sits still while spring stretches again; repeats.
**Template:** `incline_friction.xml` + `spring_mass.xml`.
**Hints:** μ_static must be > μ_kinetic — MuJoCo distinguishes these via `friction` and `solimp` settings. Driver needs a sustained low velocity, so give it big mass and high init-qvel so it barely slows over the render. Render 6 s.

#### `tipping_vs_sliding` — Friction / statics
**Physics:** A tall block on an inclined plane either tips over or slides, depending on the ratio of its height/width vs μ — the tipping angle is arctan(w/h), the sliding angle is arctan(μ).
**Setup:** Two side-by-side blocks on the same incline: one tall (high h/w), one short (low h/w). Same μ for both. Increase incline gradually.
**Motion:** As the incline tilts, the tall block tips first while the short one is still static; then the short block slides.
**Template:** `incline_friction.xml`. Two blocks with different aspect ratios.
**Hints:** Use a hinged or sliding incline (joint with init velocity to gradually tilt) or just set the incline at a critical angle showing both behaviors at once. Side view camera. Render 4 s.

#### `belt_friction` — Friction / coupled rotation
**Physics:** A belt connecting two pulleys couples their rotation — if pulley radii differ, the angular velocities differ inversely. With sufficient slip, the belt slides instead of driving.
**Setup:** Two pulleys (different radii) connected by a closed loop tendon "belt". One pulley is driven (initial spin); the other should follow.
**Motion:** Driven pulley spins; belt transfers motion; driven pulley spins at scaled velocity.
**Template:** `maxwell_wheel.xml` + `atwood.xml` (for tendon as belt).
**Hints:** Belt as a tendon-loop is approximate — true belt-pulley coupling needs friction simulation along the tendon, which MuJoCo doesn't do well. Workaround: use a joint equality coupling the two hinges directly (polycoef = -r₁/r₂). The tendon is purely visual. Render 4 s.

---

## 🟣 Tier 1 — Quick wins, brand new (~20 more)

### Kinematics / projectile (4)

#### `monkey_and_hunter` — Kinematics
**Physics:** Both projectiles fall the same Δh in the same time. A dart aimed at the monkey's initial position will hit it regardless of dart speed (within ballistic range), provided both are released at the same instant.
**Setup:** A "cannon" (small box) on the floor angled at ~30° toward a "monkey" ball suspended at height 0.8 m, 1 m away. The monkey is held by a "release point" that activates at t=0.
**Motion:** Cannon fires a small ball at angle; monkey simultaneously begins free-fall. They collide in mid-air regardless of initial dart velocity.
**Template:** `projectile_jenga.xml` (strip the tower).
**Hints:** Both are freejoint balls. The "monkey" has zero initial qvel; the dart has angled init-qvel pointing at monkey. Make 2-3 scenes' worth: vary dart speed, all still collide. Camera: x-z side view, fovy 38.

#### `projectile_max_range_45` — Kinematics
**Physics:** For projectiles launched at the same speed from ground level, the 45° angle maximizes range; angles equidistant from 45° (e.g. 30° and 60°) give equal but shorter ranges.
**Setup:** Three projectiles launched simultaneously at 30°, 45°, 60° from the same point, same initial speed.
**Motion:** All three follow parabolic arcs; the 45° lands furthest; the 30° and 60° land the same distance away but at different times.
**Template:** `projectile_jenga.xml`.
**Hints:** Three freejoint balls with carefully tuned init-qvel (each (v·cos θ, 0, v·sin θ)). Side view camera with wide fovy. Render 1.5 s.

#### `com_pair_track` — Momentum
**Physics:** Two masses on a frictionless track connected by a compressed spring — when released, they fly apart, but the center of mass stays still (momentum conservation).
**Setup:** Two cubes on a horizontal frictionless slider track, with a compressed (or stretched) spring between them. Spring releases at t=0.
**Motion:** The two masses fly apart in opposite directions; visibly, their midpoint never moves.
**Template:** `spring_mass.xml` + `elastic_collision.xml`.
**Hints:** Initialize the spring with stored energy (tendons may need init-qvel that gives them stored PE, or use a stiff hinge with init torsion). A pre-marked "COM" indicator (a thin vertical line at the midpoint) makes the demo visually obvious. Mass ratio 2:1 gives unequal velocities but same COM. Camera: side view.

#### `cannon_recoil` — Momentum
**Physics:** Cannon on wheels firing a projectile experiences recoil; final momenta sum to zero (cannon backward, ball forward).
**Setup:** Heavy cannon (box on wheels — slide joint horizontal) holding a smaller projectile. At t=0, the projectile is given a strong forward velocity; the cannon must accordingly receive backward momentum.
**Motion:** Projectile shoots forward; cannon visibly rolls backward.
**Template:** `marble.xml` (for cart on wheels) + `projectile_jenga.xml`.
**Hints:** Use a freejoint for both bodies but connect them with a "spring" or "rod" until t=0 (then somehow release). Simpler: just give both bodies opposite initial qvel, scaled by inverse mass. Render 2.5 s.

### Rotational / gyroscopic (5)

#### `bicycle_wheel_gyroscope` — Rotation / precession
**Physics:** A spinning wheel suspended by a string at one end of its axle precesses horizontally rather than falling — gyroscopic stabilization. Precession rate Ω = M·g·L / (I·ω) where L is distance from string to wheel center.
**Setup:** A heavy wheel: cylinder, R=0.10 m, thickness 0.015 m, M=0.5 kg. Mounted on a thin axle (length 0.18 m) sticking through its center. One axle end is connected by a 0.4 m vertical string (tendon) to the ceiling. Initial state: axle horizontal, wheel at world position (0.09, 0, 0.6), and `init-qvel` gives the wheel a spin of ω=60 rad/s about its axle axis.
**Motion:** Wheel doesn't fall; instead, its axle slowly rotates horizontally about the suspension point with Ω ≈ 2-3 rad/s. Render at least one half-revolution.
**Template:** `spinning_top.xml` (for spin physics) + `maxwell_wheel.xml` (for tendon as string).
**Hints:** Use a freejoint on the wheel body. Initial qvel: linear=(0,0,0), angular=(0,ω,0) — see gotcha #10 for world-frame angular qvel. Wheel inertia I_axle = ½MR² = 0.0025. Render 5 s. Camera: side view at the suspension point, pos (1.2, -0.5, 0.7), fovy 38.

#### `gyroscope_on_string` — Rotation
**Physics:** Same gyroscopic precession as the bicycle wheel demo, but with a thin disc (rather than wheel) emphasizing the rotor character. Different aspect ratio yields different I/I_perpendicular ratio.
**Setup:** Thin heavy disc: cylinder R=0.08 m, thickness 0.005 m, M=0.4 kg, on an axle (length 0.15 m). One axle end connected by a 0.4 m tendon to the ceiling. Disc starts at world (0.075, 0, 0.65), axle horizontal, spinning at ω=80 rad/s.
**Motion:** Disc precesses about the vertical through the suspension point.
**Template:** `bicycle_wheel_gyroscope` (copy after building that one first; this is its sibling).
**Hints:** Thinner disc + higher ω compared to bicycle_wheel scene. Precession rate Ω = Mg·L/(½MR²·ω). Render 5 s. Side view, pos (1.0, -0.4, 0.75), fovy 38.

#### `mass_through_hole` — Angular momentum
**Physics:** A mass on a string passing through a hole in a frictionless table is pulled inward; as the radius shrinks, the angular velocity grows (L = mvr conserved).
**Setup:** A puck on a frictionless table, attached to a string that passes through a central hole. Below the table, the string's lower end is given a downward velocity (or a hanging mass below pulling it).
**Motion:** Puck spirals inward while spinning faster and faster.
**Template:** `conical_pendulum.xml` + `atwood.xml`.
**Hints:** Tricky to set up — the string going through a hole needs to be modelled as a tendon with a fixed point in space (the hole). Alternative: use a slide joint to model the radius and a hinge joint for the angle. Camera: top-down or 3/4.

#### `reuleaux_triangle_rolling` — Rotation / geometry
**Physics:** A Reuleaux triangle (constant-width non-circular shape) rolls along a flat surface keeping the TOP face at a constant height — but the centroid of the shape bobs up and down by ~6.7% of the width as it rolls.
**Setup:** Reuleaux triangle of side L=0.10 m, thickness (z-extent) 0.05 m. Construct programmatically: for each of 3 vertices (at angles 0°, 120°, 240° on a circle of radius L/sqrt(3)), generate an arc of radius L centered on the OPPOSITE vertex. Approximate each arc with 8 small `<geom type="box">` segments. The triangle is given an initial linear velocity (vx=0.3 m/s) and matching rolling angular velocity (ω_y = vx / (centroid_height)).
**Motion:** Triangle rolls; the upper face holds a near-constant height (so a board on top wouldn't tilt). The centroid (and thus a marker glued to the centroid) bobs visibly up and down with 3× the rolling angular period.
**Template:** Programmatic gen (`gen_reuleaux.py`). Reuse rolling pattern from `marble.xml`.
**Hints:** ~24 box geoms total (3 arcs × 8). Friction tuned for rolling without slip: `friction="0.6 0.005 0.0001"`. Side view, camera pos (0, -1.5, 0.15), fovy 40. Render 4 s.

#### `coin_spiral` — Rotation / friction
**Physics:** A coin set on its edge and given a small wobble spins down in a spiral, transitioning from tall precession to flat rotation with characteristic increasing pitch. Energy lost to floor friction.
**Setup:** A thin cylinder ("coin") on the floor, given an initial vertical orientation with a small tilt and large initial spin about its vertical axis.
**Motion:** Coin spins on edge, gradually tilts more, and finally settles flat after a few seconds of accelerating-pitch oscillation.
**Template:** `spinning_top.xml`.
**Hints:** Use a freejoint with a carefully tuned initial state including a small tilt and large ω. Camera at 3/4 to capture the spiral motion. Render 6–8 s.

### Waves on strings (3)

#### `wave_reflection_fixed` — Waves
**Physics:** A pulse traveling along a string reflects off a fixed (clamped) end with an inverted polarity.
**Setup:** Long discretized horizontal string (chain of small bodies linked by spring-like hinges), one end pinned to a wall, other end free. Initial pulse generated by displacing the free end then releasing.
**Motion:** Pulse travels along the string toward the wall; upon hitting the wall, returns as an inverted pulse traveling back.
**Template:** `dominoes.xml` (chain) + `spring_mass.xml`.
**Hints:** Use ~40 nodes, hinge joints with stiffness, low damping. Initial qpos gives the pulse shape (e.g., one peak at the middle). Render 4 s. Side view.

#### `wave_reflection_free` — Waves
**Physics:** A pulse traveling along a string reflects off a free end with the same polarity (no inversion).
**Setup:** Same as above but with the second end completely free (no wall).
**Motion:** Pulse propagates → reflects from free end → returns SAME-SIDE.
**Template:** Same as `wave_reflection_fixed` but free-end boundary.
**Hints:** Discrete chain endpoint has a freejoint (no constraint). Render side-by-side with the fixed case for the educational contrast — but each is its own scene.

#### `wave_on_heavy_rope` — Waves
**Physics:** Wave speed in a vertical hanging rope varies with height: v(h) = sqrt(g·h). A pulse at the top moves faster than at the bottom (heavy lower portion has lower tension).
**Setup:** Vertical chain of small bodies hanging by gravity, top fixed, bottom free.
**Motion:** A pulse displaced at one end propagates downward and speeds up (or vice versa).
**Template:** `dominoes.xml` (chain) + `spring_mass.xml`.
**Hints:** Use ~30 nodes; gravity creates the tension gradient automatically. Initial qpos for the pulse. Render 3 s.

### Statics / structures (4)

#### `arch_compression` — Statics
**Physics:** A Roman arch supports a heavy load above by transferring the weight through compressive force along its curved spine. Remove the keystone and the arch collapses.
**Setup:** Roman semi-circular arch made of N wedge-shaped blocks; a heavy load on top. Compare with-keystone vs without-keystone.
**Motion:** With keystone in place, the arch holds the load indefinitely. Without (drop the keystone), the arch buckles inward.
**Template:** `block_overhang.xml`. Programmatic generator likely needed.
**Hints:** Use ~10-12 wedge-shaped blocks per arch. Block-block friction tuned moderately. Initial qpos placing each block precisely. Render 4 s. Side view.

#### `balance_beam_lever` — Statics / equilibrium
**Physics:** A lever in static equilibrium: F1·d1 = F2·d2 (torque balance about the fulcrum).
**Setup:** Horizontal rod pinned at center on a fulcrum. Two different weights hanging at different distances from the fulcrum, balanced.
**Motion:** Static initially. Add a small perturbation (a third mass briefly applied), then released — beam returns to equilibrium.
**Template:** `pendulum.xml`. The rod is essentially a pendulum but pinned at center.
**Hints:** The fulcrum is a hinge joint with no stiffness. Two weights attached as nested bodies at different x offsets. Render 3 s.

#### `pyramid_keystone_removal` — Statics
**Physics:** A pyramid of blocks held together by gravity and friction; remove a load-bearing block and the structure collapses.
**Setup:** ~10 blocks stacked in a pyramidal arrangement (4 on bottom, 3 on next, etc.). At some moment, one block is removed (via temporary support that disappears).
**Motion:** Pyramid initially static; after key block removal, it collapses progressively.
**Template:** `block_overhang.xml`.
**Hints:** Initially over-constrain so the stack is stable (high friction, soft contacts). To "remove" a block, just don't render it or use a slide joint with init-qvel to slide it out. Render 3 s.

#### `ladder_slipping_off_wall` — Friction / statics
**Physics:** A ladder leans against a wall, supported by friction at the floor and the wall. If μ is too low, the ladder slips outward (foot slides, top slides down).
**Setup:** A long thin rod leaning at ~60° against a vertical wall. Friction values at the floor and wall contact tuned.
**Motion:** With high μ: static. With low μ: ladder slips outward.
**Template:** `incline_friction.xml`.
**Hints:** Use a freejoint for the ladder body. Floor and wall geoms. Tune friction so the demo is at the edge of stability. Render 3–4 s.

### Mechanisms (3)

#### `slider_crank_mechanism` — Mechanism
**Physics:** Converts rotational motion to linear (reciprocating) motion via a crank arm and connecting rod. Used in every IC engine.
**Setup:** A spinning crank (hinge joint with init-qvel); connecting rod attached at one end of the crank; piston (slide joint) attached at the other end of the rod.
**Motion:** Crank spins continuously → piston reciprocates back and forth.
**Template:** `maxwell_wheel.xml`. Custom rod via hinge joints.
**Hints:** Initial qvel on the crank hinge to make it spin; geometric constraints (the rod's length) drive the piston. Render 3 s, several cycles. Side view.

#### `geneva_drive` — Mechanism
**Physics:** Converts continuous rotation into intermittent indexed rotation — a driver wheel with a single pin engages a slotted driven wheel, causing the driven wheel to step by 360°/N per pin engagement.
**Setup:** Driving wheel: cylinder R=0.08 m, thickness 0.02 m, with a small box pin of half-extent (0.005, 0.005, 0.015) at offset 0.04 m from center. Driven wheel: cylinder R=0.10 m, thickness 0.02 m, with 4 radial slots cut at 90° spacing. Each slot is a 0.012 m wide × 0.04 m deep rectangular channel approximated by box geoms forming the slot walls. The two wheel centers are 0.13 m apart on the same y-line so the pin clears the driven wheel's body but enters the slots. Driver gets init-qvel ω=2 rad/s on its hinge.
**Motion:** Driver rotates continuously; driven wheel sits still for ~270° of driver rotation, then jumps forward by 90° in ~90° of driver rotation, then sits still again. Render shows 2-3 indexing steps.
**Template:** Programmatic gen `gen_geneva_drive.py`. Closest existing: `dominoes.xml` (for chain reaction style).
**Hints:** Slot width must be slightly larger than pin width (1.5x for clean engagement). Damping on driven wheel hinge (0.05) to prevent oscillation. Friction off between pin and slot walls. Render 5 s. Top-down camera, pos (0.06, 0, 0.7), looking straight down, xyaxes="1 0 0  0 1 0".

#### `domino_branching` — Chain reaction
**Physics:** A multi-branch domino chain where one tip can trigger multiple branches simultaneously.
**Setup:** A Y-shaped or fractal layout of dominoes. The first domino is pushed.
**Motion:** Wave propagates from the start, branches at the Y, then both branches cascade simultaneously.
**Template:** `dominoes.xml`. Use a custom programmatic generator.
**Hints:** Spacing and angle at the branch point matters — too far apart and the trigger doesn't reach both. Render 5 s. Camera angled to see both branches.

### Multi-body, exotica (4)

#### `hanging_slinky_drop` — Oscillation / dispersion
**Physics:** A slinky hanging from one end has a tension gradient (tight at top, slack at bottom). When released, the top falls but the bottom STAYS in place for about 0.3 s due to wave propagation along the spring — counter-intuitive.
**Setup:** Long discretized slinky (chain of bodies with stiff springs between them) hanging from one end. Release the support at t=0.
**Motion:** Top of slinky falls immediately; bottom remains stationary for several frames; then everything falls together.
**Template:** `dominoes.xml` + `spring_mass.xml`.
**Hints:** Many small bodies (~20+), spring-joints with high stiffness. Initial qpos = gravity-equilibrium positions (heavy upward bias). Render 1.5 s. Side view, fovy small.

#### `anharmonic_pendulum_large_swing` — Oscillation
**Physics:** A pendulum with very large amplitude (~150°) shows period dependence on amplitude — the small-angle approximation breaks. Period at 90° is ~1.18× longer than at 5°.
**Setup:** Single pendulum, init-qpos = 150° (almost vertical-up).
**Motion:** Pendulum oscillates with very large amplitude; period visibly longer than what small-angle predicts.
**Template:** `pendulum.xml`. Just init-qpos = large angle.
**Hints:** Reference: place a second small-amplitude pendulum (5°) side-by-side for visual contrast — but that may be parameter variation in disguise; alternatively, just render one with a long duration to show the period.

#### `centrifugal_governor` — Rotation / equilibrium
**Physics:** Watt's flyball governor: two heavy balls on arms rotate about a vertical axis; at higher RPM, centrifugal effects lift them outward, which (in a real engine) would close a steam valve. Here we just show the equilibrium angle.
**Setup:** Two heavy balls on arms attached to a central spindle by hinge joints (so they can swing outward). Spindle spins about its vertical axis with initial qvel.
**Motion:** Balls swing outward as the system spins; at steady ω, they reach an equilibrium angle determined by ω.
**Template:** `conical_pendulum.xml` (two of them, mirrored).
**Hints:** Damping on the swing hinges so the balls settle. Camera: 3/4 front. Render 4 s.

#### `n_body_1d_collisions` — Multi-body
**Physics:** A line of N balls with elastic collisions and a small initial perturbation evolves to interesting patterns. Edge cases (light vs heavy ratios) show momentum transfer phenomena.
**Setup:** 6–8 balls on a frictionless track, just barely separated. Strike one end with a fast-moving ball.
**Motion:** Series of elastic collisions propagating; with equal masses, the leftmost ball stops and the rightmost moves off. With varying masses, complex transfer patterns.
**Template:** `elastic_collision.xml` + `newton_cradle.xml`.
**Hints:** Stiff contacts, small timestep. Use freejoints on frictionless track. Camera: side view, wide enough for all N balls.

---

## 🟠 Tier 2 — New patterns (3–5 hr each)

### Free rigid body / inertia tensor (4)

#### `tippe_top` — Free rigid body
**Physics:** An asymmetric "top" (rounded bottom + protruding stem) spun fast inverts itself: the stem (initially at the top) ends up touching the floor while the body spins on it. Driven by the contact friction torque combined with the asymmetric inertia tensor.
**Setup:** Two-part body via a single freejoint:
- Lower hemisphere: capsule from (0,0,0) to (0,0,0.04), radius 0.04 m, M=0.06 kg (heavy half-sphere bottom).
- Upper stem: thin capsule from (0,0,0.04) to (0,0,0.08), radius 0.005 m, M=0.002 kg.
Initial position: center of mass at z = 0.035 (hemisphere bottom near floor). Initial qvel = (0,0,0, 0,0, 80) — 80 rad/s about world +z. Floor contact uses `friction="0.4 0.005 0.01"` (high sliding friction, moderate torsional to drive the flip).
**Motion:** First 1-2 s: top spins upright. Then it gradually tilts; eventually inverts and ends up balancing on the stem. Total time to flip: ~4-5 s.
**Template:** `spinning_top.xml` for the rotation setup + `bowling.xml` for floor friction.
**Hints:** This is HARD to tune. Margins: see gotcha #11 for the floor-friction subtlety. Mass distribution between hemisphere and stem is critical — hemisphere too light → no flip; too heavy → never tilts. Render 6 s, may need 5-8 iterations to dial in. Camera: 3/4 low-angle, pos (0.3, -0.3, 0.1), fovy 36.

#### `dzhanibekov_effect` — Free rigid body / intermediate axis
**Physics:** A free rigid body with three distinct principal moments of inertia, spun about its intermediate axis, periodically flips by 180°. The other two axes are stable; only the intermediate is unstable.
**Setup:** A T-handle or similar asymmetric body in zero gravity, with init-qvel about the intermediate principal axis (with a small perturbation to make the instability manifest).
**Motion:** Body spins about one axis for ~1 s, then suddenly flips by 180°, then spins for another ~1 s, then flips again. Periodic.
**Template:** `spinning_top.xml`. Set `gravity="0 0 0"`.
**Hints:** Use `<option gravity="0 0 0"/>`. Freejoint body. Mass distribution: T-handle (long arm + short cross-piece). Initial qvel slightly off the intermediate axis to seed the instability. Render 4–5 s.

#### `rattleback` — Free rigid body / chirality
**Physics:** A "rattleback" (Celt stone) — boat-shaped, with the long axis of its inertia ellipsoid slightly offset from the long axis of its underside curvature — prefers one spin direction; spun the wrong way it rattles vertically and reverses direction.
**Setup:** Approximate the rattleback with an ellipsoid body. Use a freejoint at world (0, 0, 0.015). Inertia tensor must be asymmetric AND its principal axes must be rotated ~5° relative to the geometric long axis (this is what creates the chirality). Achieve this by setting `<inertial pos="0 0 0" mass="0.05" fullinertia="Ixx Iyy Izz Ixy Ixz Iyz"/>` with non-zero Ixy. Concretely: Ixx=2e-5, Iyy=8e-5, Izz=8.5e-5, Ixy=1.5e-5, Ixz=Iyz=0. Geom: ellipsoid via `<geom type="ellipsoid" size="0.06 0.025 0.015"/>` (long axis x, narrow y, flat z). Floor friction `friction="0.4 0.005 0.001"`. Initial qvel: angular about +z, ω=8 rad/s ("right" direction → just spins) OR ω=-8 ("wrong" direction → rattles + reverses).
**Motion:** Wrong-direction spin: rocks up-and-down (visible bobbing of the long axis), spin slows to a stop, then reverses to the preferred direction.
**Template:** `spinning_top.xml` (rotation handling).
**Hints:** Ellipsoid geom is convex in MuJoCo (works). The skewed-inertia trick (off-diagonal Ixy) is the entire physics. Render 6-8 s for the full reversal. Side view, pos (0, -0.5, 0.08), fovy 38.

#### `tumbling_book` — Free rigid body / intermediate axis
**Physics:** Same physics as Dzhanibekov, demonstrated with a book/rectangular slab. Spinning about the medium-length axis is unstable.
**Setup:** Rectangular slab in zero gravity, init-qvel about its intermediate axis (with small perturbation).
**Motion:** Spins ~1 s about intermediate axis, then suddenly flips, then again.
**Template:** Same as `dzhanibekov_effect` but with a rectangular slab geom.
**Hints:** Different shape but same physics. Render 5 s.

### Chains and ropes (4)

#### `falling_chain_classical` — Chain dynamics
**Physics:** A chain falling off the edge of a table accelerates faster than g once moving — falling links pull the still-on-table links into motion.
**Setup:** A chain (~30 discretized bodies linked by short hinges) initially resting on a table with half hanging off the edge.
**Motion:** Hanging portion descends, pulling the on-table portion off — chain accelerates progressively until fully airborne.
**Template:** `dominoes.xml` (chain layout).
**Hints:** Friction on the table tuned so the resting portion doesn't slide too easily. Render 2–3 s. Side view.

#### `sliding_chain_off_table` — Chain dynamics
**Physics:** A chain half on a frictionless table, half hanging — the hanging weight pulls the table portion off; in the limit of no friction, motion is purely gravity-driven.
**Setup:** Same as `falling_chain_classical` but with zero friction on the table.
**Motion:** Hanging portion descends; table portion slides off rapidly.
**Template:** `dominoes.xml`. Adjust friction.
**Hints:** Same caveats but with friction off. Render 1.5 s.

#### `hanging_chain_catenary` — Statics / chain
**Physics:** A chain hanging from two pinned endpoints at the same height settles into a CATENARY (cosh) curve, not a parabola — though they look similar for shallow sags.
**Setup:** 40 chain links, each a small capsule (length 0.04 m, radius 0.005 m, M=0.01 kg per link). Links connected by hinge joints with axis y (sag in x-z plane), damping=0.05. Endpoints (link 0 and link 39) are attached to fixed posts via weld constraints at world (-0.5, 0, 1.0) and (+0.5, 0, 1.0). Initial qpos: all hinges = 0 (chain starts as a straight horizontal line stretching between the posts; gravity pulls it down to settle).
**Motion:** Chain dynamically settles under gravity into the catenary shape over ~2-3 s, then stays stable.
**Template:** Programmatic gen (`gen_hanging_catenary.py`). Reuse pattern from `gen_dominoes.py` for chain layout.
**Hints:** Endpoint weld constraints can be done by making link 0 and 39 child bodies of the world post (no joint). Friction off. Render 5 s — first 2 s settle, last 3 s show the catenary shape. Side view, pos (0, -1.8, 0.85), fovy 40.

#### `swinging_chain_pendulum` — Chain dynamics
**Physics:** A chain hanging from one fixed end behaves like a continuous pendulum but with internal flexibility — modes are non-trivial; it whips.
**Setup:** Chain fixed at one end, pulled to ~30° tilt, released.
**Motion:** Swings like a pendulum but with the lower end whipping noticeably.
**Template:** `dominoes.xml`. Adjust pivot.
**Hints:** ~25 links, low damping. Render 5 s.

### Bead on wire / constrained particle (4)

#### `bead_on_helix` — Constraint
**Physics:** A bead on a frictionless helical wire descends with combined translation+rotation; ratio of vertical drop to spiral length determines acceleration: a = g·sin(α) where α is the helix pitch angle.
**Setup:** Helix axis vertical (along +z). Generator parameters: radius R=0.06 m, pitch p=0.04 m per turn, 5 turns (total height 0.20 m). Approximate the helix with ~80 short tubular box-segments: at each parameter t ∈ [0, 5·2π], position is `(R·cos(t), R·sin(t), -p·t/(2π))`, segment is a thin box oriented along the local tangent. Bead: sphere R=0.012 m, freejoint, placed just above the top of the helix at world (R, 0, 0.01).
**Motion:** Bead falls onto the helix, slides down spiraling, exits at the bottom after ~3-4 s.
**Template:** Programmatic gen `gen_bead_on_helix.py`. Reuse curve-generation pattern from `gen_brachistochrone.py`.
**Hints:** Make the helix wire from boxes that form a thin "channel" (two parallel walls) so the bead is trapped. Friction off on both bead and helix. Bead radius 0.012 should be much smaller than helix radius 0.06 to fit. Render 4 s. 3/4 view from front-above, pos (0.3, -0.3, 0.15), fovy 38.

#### `bead_on_cycloid_track_isochrony` — Constraint
**Physics:** A bead on a cycloid track has the same period regardless of release point — the cycloid is the tautochrone.
**Setup:** A cycloid-shaped track (programmatic generation from cycloid equation); a bead placed at different starting positions reaches the bottom in the same time.
**Motion:** Three beads released from different positions on the cycloid; they all reach the bottom (or center) simultaneously.
**Template:** `brachistochrone.xml`. Reuse cycloid generator.
**Hints:** Multiple beads released from different heights but on the same track. Render 1.5 s (cycloid is fast). Side view.

#### `bead_on_parabolic_wire` — Constraint
**Physics:** A bead on a parabolic wire (z = x²) has period dependent on amplitude — contrast with cycloid's amplitude-independent period.
**Setup:** A parabolic wire (programmatic), one bead.
**Motion:** Bead oscillates back and forth; period varies with amplitude.
**Template:** `brachistochrone.xml`. Use parabolic curve instead of cycloid.
**Hints:** Render 4 s.

#### `bead_in_rotating_ring` — Constraint
**Physics:** A bead inside a ring that's spinning about its diameter — bead sits at an angle determined by ω, the centrifugal "potential" creating a non-trivial equilibrium.
**Setup:** A ring on a horizontal axis spinning about its diameter; a bead inside it (constrained to the ring's circular path).
**Motion:** Bead settles at an equilibrium angle on the inside of the ring. Higher ω → more horizontal position.
**Template:** `conical_pendulum.xml` + `marble.xml`.
**Hints:** Ring spins via init-qvel on its hinge. Bead's motion is constrained to the ring (geometric setup). Render 4 s. Side view.

### Curves and bowls (3)

#### `ball_in_spherical_bowl` — Oscillation
**Physics:** A ball in a spherical bowl oscillates with period independent of amplitude for small amplitudes (like a pendulum on short string).
**Setup:** A spherical bowl (a hemisphere) with a ball inside, released from one side.
**Motion:** Ball rolls back and forth in the bowl.
**Template:** `loop_the_loop.xml` (closed curved surface).
**Hints:** Build the bowl as a triangle-mesh hemisphere or as many curved segments. Or use a partial spherical capsule. Camera: 3/4 front. Render 4 s.

#### `cycloidal_pendulum_huygens` — Constraint / tautochrone
**Physics:** A pendulum's string wrapping around two cycloid-shaped "cheeks" forces the bob to trace a cycloid path. The resulting motion is exactly isochronous: period is independent of amplitude (unlike a normal pendulum).
**Setup:** Pivot at world (0, 0, 1.0). Two cycloid arcs (the "cheeks") flank the pivot, one on each side. Each cheek is the EVOLUTE of the path-cycloid (per Huygens). Use the parametric form `x = ±R·(θ - sin θ), z = 1.0 - R·(1 - cos θ)` for θ ∈ [0, π/2]; with R=0.20 m. Approximate each cheek with 12 short box-segments. The pendulum: massless string (tendon) of length π·R from the pivot to a bob (sphere R=0.015 m, M=0.05 kg). As the bob swings, the string wraps around the cheeks, effectively shortening — this forces the bob's path to be a cycloid.
**Motion:** Bob swings back and forth tracing a cycloid arc (visibly different from a circular pendulum arc). Period ≈ 4π·sqrt(R/g) ≈ 0.9 s, INDEPENDENT of swing amplitude.
**Template:** `pendulum.xml` (pivot + bob) + `gen_brachistochrone.py` (cycloid generator).
**Hints:** Use a tendon for the string — tendons wrap around obstacles naturally. The cheeks need contact with the tendon. Programmatic generator. Render 4 s (~4 cycles). Side view, pos (0, -1.6, 0.8), fovy 40.

#### `ball_on_saddle` — Constraint / instability
**Physics:** A saddle point (z = x² - y²) is stable in one direction, unstable in the other. A ball placed at the saddle rolls off in the unstable direction.
**Setup:** Saddle-shaped surface (z = a·x² - b·y²) with a ball placed exactly at the center.
**Motion:** Ball is stationary briefly, then with a tiny perturbation rolls off in the unstable y-direction while remaining centered in x.
**Template:** `loop_the_loop.xml` (curved geometry).
**Hints:** Approximate the saddle with many small geoms. Slight initial offset in y to seed the instability. Side view.

### Angular momentum / energy (2)

#### `skater_pulling_arms_in` — Angular momentum
**Physics:** Conservation of angular momentum — a rotating body retracting mass closer to the axis spins faster (I·ω = const).
**Setup:** A central spinning hub (vertical axis) with two arms extending horizontally. Masses are attached to the arms via slide joints; initially extended. At some point the masses are retracted (via init qpos + spring-loaded sliders) — system spins faster.
**Motion:** System spins at ω₁; arms retract; system now spins at ω₂ > ω₁.
**Template:** `conical_pendulum.xml`.
**Hints:** Tricky to model "retracting" without an actuator. Easiest: start with arms in the extended position, use slide joints with stiffness pulling them toward retracted equilibrium; release and watch them retract under their own spring tension. The conservation effect manifests automatically. Render 4 s.

#### `cradle_drop_demo` — Energy / momentum
**Physics:** A small object placed on a pendulum bob is propelled upward when the bob reaches the bottom of its swing — energy transfer demonstration.
**Setup:** A pendulum with a small block balanced on top of its bob. Release the pendulum from height.
**Motion:** Bob swings down; at the bottom of the swing, momentum transfer flicks the small block upward.
**Template:** `pendulum.xml`.
**Hints:** Carefully tuned mass ratio (~10:1 bob:block). Render 3 s.

### Resonance and waves (3)

#### `standing_wave_on_string` — Waves
**Physics:** Wave on a fixed-end string forms standing waves at resonance frequencies. The nodes and antinodes are visible.
**Setup:** Long discretized string with one end fixed. The other end is given a small periodic motion via init-qpos (a sinusoidal initial condition matching the lowest mode).
**Motion:** String oscillates with the visible standing-wave pattern.
**Template:** `dominoes.xml` (chain) + `spring_mass.xml`.
**Hints:** Initial qpos = sin(πx/L) gives the fundamental. Run for several periods. Render 3 s. Without actuator, only the freely-oscillating modes are visible.

#### `wave_on_chain_pulse` — Waves
**Physics:** A pulse propagates along a 1D chain of masses connected by springs. Speed depends on tension and mass density.
**Setup:** Long chain of bodies on a frictionless surface, connected by stiff hinge-springs. Initial pulse at one end (displaced upward).
**Motion:** Pulse propagates along the chain.
**Template:** `dominoes.xml` + `spring_mass.xml`.
**Hints:** Initial qpos has one peak at the start. Render 3 s.

#### `mexican_hat_drum_modes` — Waves / modes
**Physics:** A 2D mass-spring lattice (drum head analog) has discrete vibration modes — the (1,1) "Mexican hat", the (2,1), (1,2), etc. Each mode oscillates at its eigenfrequency. Here we excite the (1,1) fundamental.
**Setup:** 10×10 grid of small bodies on a square 0.20×0.20 m. Each body: sphere R=0.005 m, M=0.005 kg. Body (i,j) at world (-0.10 + i·0.022, -0.10 + j·0.022, 0.20). Each body connected to its 4 nearest neighbors via hinge-joint spring approximation. Use slide joints in z (only out-of-plane vertical motion) with `<equality>` constraints between adjacent bodies acting as springs: `<equality><joint joint1="zij" joint2="z(i+1)j" polycoef="..."/></equality>` — actually for simplicity, just use linked bodies with hinges or tendons. Edges (i=0, i=9, j=0, j=9) are fixed (no slide joint, attached to the world).
**Motion:** Initial qpos sets all bodies to `z_offset = A · sin(π·i/9) · sin(π·j/9)` with A=0.02 — the (1,1) mode shape (one big up-bump in the middle). System oscillates in pure (1,1) mode.
**Template:** Programmatic gen `gen_drum_modes.py`. Reuse from `gen_pendulum_waves.py`.
**Hints:** 10×10 = 100 bodies, manageable. Use slide joints (1 DOF each) with stiffness, not freejoints. Stiffness tuned so visible oscillation period ≈ 1 s. Render 3 s. Top-down 3/4 camera (pos 0.2, -0.2, 0.4) showing the wave shape.

### Structures (4)

#### `cantilever_load_curve` — Structures
**Physics:** A cantilever beam under a tip load deflects in proportion to the load (Hooke's law for the beam): δ = FL³/(3EI). Heavier load = more deflection.
**Setup:** A horizontal beam clamped at one end (like beam_buckling but horizontal). A movable load at the free end progressively gets heavier.
**Motion:** Static or quasi-static: at low load, beam barely deflects; at high load, beam visibly bends.
**Template:** `beam_buckling.xml`. Re-use the discretized beam.
**Hints:** Beam horizontal, one end pinned to a wall. Mass at tip varies (could just render 3 separate scenes or one with progressive mass via tendons). Render 2 s.

#### `truss_collapse` — Structures
**Physics:** A 2D truss is statically determinate; removing one member shifts the load through alternate paths or, if the truss becomes a mechanism, collapses entirely.
**Setup:** Triangulated 2D truss (Pratt or Warren style, ~5-7 members) holding a load. One member is "removed" (or always missing) — truss collapses.
**Motion:** Truss with all members: holds load. Without: collapses.
**Template:** `dominoes.xml` + `block_overhang.xml`.
**Hints:** Members as rigid rods connected by hinges. Programmatic generator. Render 3 s.

#### `inverted_pendulum_tower` — Stability
**Physics:** A tower of inverted pendulums (each hinged on the one below) is unstable — any small perturbation grows.
**Setup:** Stack of N inverted pendulums (link-on-link, each a hinge with stiffness but high amplitude). Small initial tilt.
**Motion:** Tower wobbles initially, then collapses in some direction.
**Template:** `beam_buckling.xml`.
**Hints:** Set hinge stiffness so it's below the buckling-stability threshold. Render 3–4 s.

#### `crane_lifting_simple` — Structures / mechanism
**Physics:** A simple crane (arm + cable + load) demonstrates torque on the base; tipping happens if load·arm-extension > base-weight·base-half-width.
**Setup:** A pivoting vertical pole with a horizontal arm extending out; a cable hanging from the arm tip; a load on the cable.
**Motion:** Without enough base mass, the crane tips forward when the load is hung. With enough, it stays.
**Template:** Custom; use `block_overhang.xml` ideas.
**Hints:** Visualize the load's weight and the crane's stability margin. Render 3 s.

---

## 🟢 Tier 1 — Final additions (10 more, brainstormed in round 2)

### Equilibrium / instability (4)

#### `cone_balanced_on_tip` — Statics / instability
**Physics:** A cone balanced perfectly on its apex is in unstable equilibrium; any infinitesimal perturbation causes it to fall.
**Setup:** Cone shape (build from cylinder + capsule cap or use a cone-shaped geom). Cone height 0.20 m, base radius 0.06 m. M=0.10 kg. Place upside-down with apex on floor at world (0, 0, 0.20). Initial qpos: tiny tilt (~0.5° about y-axis, i.e. quaternion (1, 0, 0.004, 0)). Floor friction `friction="0.8 0.01 0.001"`.
**Motion:** Cone holds steady for ~0.3 s, then starts tilting visibly, falls completely by 1.5-2 s.
**Template:** `spinning_top.xml` (free body + floor) + `dominoes.xml` (tilt seed).
**Hints:** This is just unstable equilibrium — gravity does the rest. Camera: side view, pos (0, -0.6, 0.15), fovy 38. Render 2.5 s.

#### `symmetry_breaking_ball_on_dome` — Statics / instability
**Physics:** A ball at the very top of a smooth dome is in unstable equilibrium; tiny perturbations make it slide off, eventually flying through air.
**Setup:** A semi-spherical dome of radius R=0.20 m, half-sphere shape built from many small triangular boxes or a single half-ellipsoid geom positioned at world (0, 0, 0.20). Ball: sphere R=0.015 m, M=0.05 kg, placed on top at (0, 0, 0.215). Initial qpos: tiny horizontal offset (Δx=0.001). Friction zero.
**Motion:** Ball stays nearly still for ~0.5 s, then slides off the dome accelerating to the side, then flies through the air after losing dome contact.
**Template:** `loop_the_loop.xml` (for curved surface).
**Hints:** Dome can be approximated by half of a high-poly sphere or by stacked rings. Render 2 s. Camera: side view, pos (0.5, -0.5, 0.15), fovy 40.

#### `marble_in_funnel` — Gravity / circular motion
**Physics:** A marble released inside a funnel (cone with vertical axis) spirals down, accelerating as the radius decreases — angular momentum NOT conserved (gravity does work) but visually striking.
**Setup:** Funnel: inverted cone shape, top radius 0.15 m, bottom hole radius 0.01 m, height 0.20 m. Built programmatically from ~24 box segments forming the conical wall. Marble: sphere R=0.008 m, M=0.005 kg, placed at the top edge (R=0.14, z=0.20) with initial tangential velocity vt=0.5 m/s.
**Motion:** Marble spirals down the funnel wall, speeding up as the radius decreases; exits the bottom or oscillates at the throat.
**Template:** Programmatic gen (`gen_funnel.py`). Reuse pattern from `gen_rotating_fluid.py` for ring-of-walls.
**Hints:** Marble friction tuned for low slip on the funnel wall (`friction="0.05 0.005 0.001"`). Camera 3/4 from above, pos (0.25, -0.25, 0.30), fovy 38. Render 4 s.

#### `falling_chimney` — Rotational / rigid body
**Physics:** A tall vertical rod pinned at the base falls over by rotating about the base. The TIP accelerates faster than g during part of the fall — counter-intuitive demonstration of how internal stresses redistribute (real chimneys often break mid-fall because of this).
**Setup:** Single rigid rod: a thin box of length 1.0 m, half-extents (0.025, 0.025, 0.5), M=2 kg. Bottom end pinned at world (0, 0, 0) via a hinge joint with axis y, no stiffness. Initial qpos: 2° tilt about y to seed the fall. No damping.
**Motion:** Rod falls over rotating about its base. Tip's vertical velocity exceeds free-fall during the second half of the trajectory (~30° to 60° from vertical).
**Template:** `pendulum.xml` (single rod on hinge).
**Hints:** Compare the tip's z-velocity to g·t to verify the >g effect. Render 1.5 s. Side view, pos (1.5, -1.0, 0.5), fovy 40.

### Coupling & action-reaction (3)

#### `block_on_accelerating_wedge` — Action-reaction
**Physics:** A block on a frictionless wedge that can itself slide on a frictionless floor — when released, both bodies accelerate. The wedge slides one way as the block slides down it; momentum in x conserved.
**Setup:** Wedge: triangular prism, 30° incline, base 0.40 m × 0.10 m, height 0.20 m at the high end. M_wedge=1.0 kg. Wedge sits on a slide joint along world x. Block: cube 0.05 m, M_block=0.3 kg, sits on the slope of the wedge, constrained to slide on it via slide joint along the slope direction.
**Motion:** Block accelerates down the slope; wedge accelerates in the opposite direction. The combined center of mass stays fixed in x.
**Template:** `incline_friction.xml` (block-on-wedge) + add a slide joint for the wedge.
**Hints:** Set ALL friction to 0 (gotcha #1). Render 1.5 s. Add a vertical marker line at the initial x of the combined COM to make conservation visually obvious. Side view, fovy 38.

#### `two_pendulums_collide` — Collision + oscillation
**Physics:** Two pendulums released from opposite sides meet at the bottom and collide elastically; momentum transfer depends on mass ratio.
**Setup:** Two single pendulums side-by-side (small lateral offset so they meet at the bottom). Left: length 0.40 m, mass 0.10 kg, released from 30° (positive angle). Right: length 0.40 m, mass 0.10 kg, released from -30° (negative angle), with a tiny y-offset (0.001) so geoms don't tangle.
**Motion:** Both pendulums swing toward each other; collide at the bottom with equal-mass elastic collision (essentially swap velocities); each bounces back to near-original height.
**Template:** `pendulum.xml` (duplicate) + `elastic_collision.xml` (stiff contact tuning).
**Hints:** Use stiff contact (`solref="-150000 -15"` `solimp="0.99 0.999 0.001"`) for clean elastic transfer (gotcha #4). Render 3 s (two full swings). Side view.

#### `pulley_with_inertia` — Constraint / rotational
**Physics:** Atwood machine where the pulley has significant moment of inertia — the pulley's I REDUCES the acceleration: a = (m1-m2)·g / (m1 + m2 + I/r²). Pulley I shows up as effective mass.
**Setup:** Same as Atwood but the pulley is a heavy disc (R=0.10 m, thickness 0.02 m, M=0.5 kg) — NOT massless. Pulley rotates via a hinge joint with no damping. The rope is two tendons (one each side) attached to the pulley via sites at radius R; the rope coupling to the pulley rotation enforces no-slip via joint-equality (combination of slide joints + hinge equality).
**Motion:** Heavier mass descends, lighter ascends — but more slowly than ideal Atwood predicts because of the pulley's I.
**Template:** `atwood.xml` (Atwood structure) + `maxwell_wheel.xml` (rolling-without-slip equality).
**Hints:** Connection: two equalities, one per side, each coupling rope-slide to pulley-hinge. Or simpler: ONE equality between (heavy_slide - light_slide) and (pulley_hinge · R). Mass ratio: 0.6 / 0.4 kg gives clean visible acceleration. Render 3 s. Side view.

### Friction & contact (3)

#### `block_on_block_static_friction` — Friction
**Physics:** Two stacked blocks on a frictionless floor; pull the bottom block. If μ_static between blocks is high enough, the top block moves WITH the bottom (no slip). If μ exceeded, top stays while bottom slides out.
**Setup:** Bottom block: 0.20 × 0.10 × 0.05 m, M=1 kg, sitting on a frictionless floor, with slide joint along x. Top block: 0.10 × 0.10 × 0.05 m, M=0.2 kg, placed centered on top, also with a slide joint along x. Inter-block contact has μ_static = 0.4. Apply a horizontal initial velocity to the bottom block (vx=1.0 m/s, large enough to slip).
**Motion:** Bottom block slides; top block stays nearly still for a moment, then accelerates due to friction; eventually they share velocity (or stay apart depending on initial velocity).
**Template:** `incline_friction.xml` (stacked geoms) + `elastic_collision.xml` (sliders).
**Hints:** Set floor friction to 0 (gotcha #1). Top block's slide joint allows it to be left behind. Render 2 s. Side view, pos (0, -1.0, 0.15), fovy 40.

#### `vertical_loop_insufficient_speed` — Energy / centripetal
**Physics:** A ball on a vertical loop track needs minimum speed `v_min = sqrt(g·R)` at the top to maintain contact. With less, it falls off the track partway up.
**Setup:** Closed vertical loop track (radius 0.20 m) — same geometry as `loop_the_loop.xml`. Ball: sphere R=0.025 m, M=0.05 kg. Initial position at the bottom of the loop; initial qvel = small (vx=1.5 m/s — too slow to make it around).
**Motion:** Ball ascends the loop on the inside surface; somewhere past 90° (when gravity component exceeds centripetal requirement), the ball loses contact with the track and falls inward.
**Template:** `loop_the_loop.xml`. Reduce initial speed.
**Hints:** Compare to `loop_the_loop` which uses enough speed. Render 1.5 s. Same camera as loop_the_loop.

#### `spherical_pendulum_2d` — Oscillation
**Physics:** A pendulum with 2D bob motion (instead of constrained to a plane) traces complex Lissajous-like patterns. Period not necessarily commensurate, so trajectory can be quasi-periodic.
**Setup:** Single bob hung from a pivot at world (0, 0, 1.2) via a 2-DOF gimbal: outer hinge axis y (pitch), inner hinge axis x (roll) — see gotcha #8 for why this is better than a ball joint. Bob: sphere R=0.025 m, M=0.10 kg, at the end of a 0.6 m rod from pivot. Initial qpos: pitch=0.5 rad, roll=0; init-qvel: roll_rate=0.8 rad/s.
**Motion:** Bob traces a rosette pattern in the xy plane (as projected) — not a circle, not a flat line.
**Template:** `conical_pendulum.xml` (gimbal pattern).
**Hints:** Use a long render (10 s) so the pattern becomes visible. Top-down camera, pos (0, 0, 0.4), xyaxes="1 0 0  0 1 0", fovy 42.

---

## 🟡 Tier 1/2 — Round 2 additions (F and G packages, 34 more)

### Classic energy / motion demos (5)

#### `galileo_pendulum_peg` — Energy conservation
**Physics:** A pendulum swung from a height rises to the SAME height on the other side, even if a peg in the path shortens the effective length mid-swing.
**Setup:** Pivot at world (0, 0, 1.0); rigid string (length 0.6 m, modelled as a tendon) to a bob (sphere R=0.025 m, M=0.05 kg). Fixed peg at world (0, 0, 0.7). Initial pose: bob pulled back to angle 60° from vertical on the left side.
**Motion:** Bob swings down, string contacts the peg, effective swing length shortens to 0.30 m, bob now swings about the peg, rises to the same height as it started.
**Template:** `pendulum.xml` (basic pendulum) + `cradle_drop_demo.xml`.
**Hints:** Tendon wraps naturally around the peg. Mark the original height with a thin horizontal line for visual proof. Side view, pos (0, -1.5, 0.7), fovy 38. Render 3 s.

#### `horizontal_vs_dropped_balls` — Independence of motion
**Physics:** Horizontal motion is independent of vertical free fall: two balls dropped from the same height — one pushed horizontally, one not — hit the ground simultaneously.
**Setup:** Two balls at world (0, 0, 1.0), each sphere R=0.025 m, M=0.05 kg, with freejoints. Ball A: init-qvel zero. Ball B: init-qvel "1.5 0 0 0 0 0" (horizontal kick).
**Motion:** Ball A falls straight down; Ball B traces a parabola landing 1m+ to the side. Both touch the floor at the same instant (t = √(2·1.0/9.81) ≈ 0.45 s).
**Template:** `galileo_dropballs.xml`.
**Hints:** Side view, pos (0.7, -1.5, 0.5), fovy 38 — frame both initial position AND ball B's landing point. Render 0.6 s.

#### `rolling_disc_inscribes_cycloid` — Trajectory geometry
**Physics:** A point on the rim of a rolling disc traces a cycloid in space — the curve that originally motivated cycloid mathematics.
**Setup:** Disc R=0.10 m, thickness 0.02 m, M=0.5 kg, rolling on the floor (init-qvel: vx=0.6, ω_y=-6 for rolling-without-slip). A small bright marker (sphere R=0.005 m) welded to the disc at one point on the rim.
**Motion:** Disc rolls; marker traces high arches (cycloid), touching the ground at intervals.
**Template:** `rolling_race.xml` + `maxwell_wheel.xml`.
**Hints:** Side view, pos (1.5, -2.0, 0.3), fovy 38. Render 4 s — 2-3 cycloid arches.

#### `bucket_of_water_overhead_swing` — Vertical circular motion
**Physics:** A bucket swung in a vertical circle keeps its contents inside even at the top (upside-down moment) as long as centripetal acceleration > g.
**Setup:** Pivot at world (0, 0, 1.0). Rigid rod (length 0.5 m, NOT a tendon — tendon would go slack at top) ending in a "bucket" (an open-top 5-sided box, 0.10 × 0.10 × 0.10 m). Inside the bucket: a free ball (R=0.025 m, M=0.05 kg). Arm initial qvel: ω=4 rad/s.
**Motion:** Bucket sweeps a full vertical circle (or two). Ball stays inside even when upside-down at the top.
**Template:** `pendulum.xml` + `conical_pendulum.xml`.
**Hints:** Arm must be RIGID (use a rigid hinge-connected body, not tendon). Ball free inside the cup. Render 3 s (1 full circle).

#### `two_marbles_curved_track_collision` — Energy + collision
**Physics:** Two marbles in a frictionless U-shaped track oscillate, meet at the bottom with equal speeds, elastically collide (swap velocities), and oscillate again — perpetual motion (ideally).
**Setup:** U-shaped parabolic track (`z = 0.4·x²` for x ∈ [-0.4, 0.4]), built from ~20 box segments via programmatic gen. Two marbles (R=0.02 m, M=0.04 kg) placed at the rim on opposite sides; both released from rest.
**Motion:** Slide down → meet at bottom → elastic collision → scatter back to original heights → repeat.
**Template:** `brachistochrone.xml` (curved track) + `elastic_collision.xml` (stiff contact).
**Hints:** Marble friction zero. Stiff contact (solref="-200000 -20"). Render 4 s — multiple oscillations. Side view, pos (0, -1.5, 0.4), fovy 40.

### Mechanisms (4)

#### `planetary_gear_train` — Mechanism
**Physics:** Planetary gear system: sun + 3 planets + ring. Driving the sun makes planets rotate AND orbit; ring stays still. Demonstrates how complex gear ratios arise.
**Setup:** Sun gear: cylinder R=0.04 m at world (0, 0, 0.1) on a hinge. 3 planet gears: cylinders R=0.025 m at world (0.065, 0, 0.1) and 120° rotations, each on a hinge attached to a "planet carrier" body. Ring gear: hollow cylinder, inner R=0.115 m, outer R=0.13 m, fixed to world. Joint-equalities couple sun-to-planet and planet-to-ring as `ω_sun · R_sun = -ω_planet · R_planet` (and similar for ring).
**Motion:** Sun spins (init-qvel ω=4 rad/s); planets rotate AND orbit; ring stays still.
**Template:** `maxwell_wheel.xml` (rolling-without-slip equality).
**Hints:** Use joint equalities, not real gear teeth. Top-down view, pos (0, 0, 0.5), xyaxes="1 0 0  0 1 0", fovy 38. Render 3 s.

#### `gear_train_2_gears` — Mechanism
**Physics:** Two meshed gears: angular velocities related by gear ratio (ω_a · R_a = -ω_b · R_b), opposite directions.
**Setup:** Two cylinder gears: A (R=0.06 m) at world (-0.07, 0, 0.1), B (R=0.10 m) at world (0.09, 0, 0.1), each on a hinge about z. Joint equality: `<equality><joint joint1="gear_a" joint2="gear_b" polycoef="0 -0.6 0 0 0"/></equality>` (ratio R_a/R_b=0.6). Gear A initial qvel ω=5 rad/s.
**Motion:** A spins; B counter-rotates at 0.6× A's speed.
**Template:** `maxwell_wheel.xml`.
**Hints:** Top-down, fovy 40. Mark a colored dot on each gear so the speed ratio is visible. Render 3 s.

#### `four_bar_linkage` — Mechanism
**Physics:** Four bars in a closed loop (ground + crank + coupler + rocker) — driving the crank in continuous rotation makes the rocker oscillate. Classic mechanism (e.g., oil pump jacks, windshield wipers).
**Setup:** 4 rigid bar bodies joined by 4 hinge joints in a closed quadrilateral. Lengths: ground 0.20, crank 0.05, coupler 0.20, rocker 0.15 (satisfies Grashof condition for full rotation). Ground bar fixed to world; crank driven by init-qvel ω=4 rad/s.
**Motion:** Crank rotates uniformly; rocker swings back and forth; coupler bar's midpoint traces a "coupler curve" (complex closed shape).
**Template:** `slider_crank_mechanism.xml` (similar mechanism with crank).
**Hints:** Use four hinge joints forming a loop — MuJoCo handles closed loops via constraint. Side view. Render 4 s.

#### `ratchet_pawl` — Mechanism
**Physics:** A toothed wheel + spring-loaded pawl that locks rotation in one direction only. Forward: pawl clicks over teeth. Backward: pawl catches a tooth and locks.
**Setup:** Wheel R=0.10 m with 12 saw-tooth teeth (each tooth: angled box on the rim). Pawl: small lever hinged to a fixed frame, spring-loaded (joint stiffness) so it presses on the rim. Wheel given init-qvel ω in the "allowed" direction (ratchets freely) — for the "blocked" version, give ω in the other direction (immediately locks).
**Motion:** Allowed direction: wheel rotates freely, pawl clicks over teeth. Blocked: wheel rotates ~5° then locks.
**Template:** Programmatic gen `gen_ratchet.py`. Reuse from `gen_dominoes.py` for tooth layout.
**Hints:** Render two variants if desired, or one render that reverses direction at t=1.5 s. Top-down camera. Render 3 s.

### Chain / pile dynamics (3)

#### `chain_jet_classic` — Self-propelled chain
**Physics:** A chain in a container, with one end pulled up, develops a self-propelled "fountain" — the falling chain pulls more chain out, accelerating. The chain arches above the container.
**Setup:** Cylindrical "beaker" (R=0.05 m, H=0.10 m) on a table. ~50 small chain links piled inside. Topmost link given small upward initial velocity (vz=2 m/s).
**Motion:** Chain begins falling out; arch forms above the beaker; chain continuously feeds itself.
**Template:** `dominoes.xml` (chain) + `rotating_fluid.xml` (container).
**Hints:** Hard — pile geometry is finicky. Programmatic gen. Render 3-4 s. Side view, pos (0.5, -1.0, 0.2), fovy 40.

#### `chain_unspooling_from_pile` — Self-feeding chain
**Physics:** A chain piled on the floor, with one end pulled up — the chain accelerates as more length is lifted (less mass remains stationary). Tension at the pile-junction pulls more chain out.
**Setup:** ~40 chain links initially piled at world (0, 0, 0.05). Topmost link given a small lift (initial qpos at z=0.15, with downward velocity zero).
**Motion:** Pile feeds chain upward and out, accelerating over time.
**Template:** `dominoes.xml`.
**Hints:** Programmatic gen for the initial loose stack. Side view. Render 3-4 s.

#### `chain_on_scale_falling` — Impact dynamics
**Physics:** A chain falling onto a scale — the scale reading is HIGHER than the static weight of the deposited chain during the fall, because falling links transfer impact momentum.
**Setup:** Chain (~30 links, each M=0.01 kg) initially suspended just above a fixed plate ("the scale"). Release.
**Motion:** Chain falls onto the scale segment by segment; visible impact dynamics; total deposited weight grows linearly while impact force adds extra peak force.
**Template:** `dominoes.xml` + `bowling.xml`.
**Hints:** Programmatic gen. Render 2 s. Side view.

### Friction / mechanical (3)

#### `triple_block_friction_chain` — Friction
**Physics:** Three stacked blocks on a frictionless floor — push the bottom block. Depending on inter-block μ, all three move together, or top blocks slip behind.
**Setup:** 3 boxes stacked vertically, each on a slide joint along x. Bottom block (M=2 kg) given init-qvel vx=2 m/s. Inter-block friction: μ=0.3 between bottom-middle, μ=0.5 between middle-top.
**Motion:** Bottom accelerates fast; top and middle blocks lag (limited by friction); over a short time they catch up.
**Template:** `incline_friction.xml` + `block_on_block_static_friction.xml`.
**Hints:** Floor friction zero (gotcha #1). Render 2.5 s. Side view, pos (0, -1.0, 0.15), fovy 40.

#### `two_bodies_on_incline_string` — Friction + constraint
**Physics:** Two blocks on an incline connected by a string. If they have different μ, internal string tension develops; they slide as a unit at an intermediate speed.
**Setup:** Inclined ramp at 25°. Two blocks on it (separated 0.15 m along the slope), connected by a tendon. Block A (uphill): μ=0.1 (low). Block B (downhill): μ=0.4 (high).
**Motion:** Both blocks slide down at the same speed (locked by the string); intermediate between their solo speeds.
**Template:** `incline_friction.xml` + `atwood.xml` (tendon).
**Hints:** Tendon visible. Side view, pos (1.0, -1.5, 0.3), fovy 40. Render 3 s.

#### `pulled_block_string_around_peg` — Redirect force
**Physics:** A string going around a fixed peg redirects the pulling direction without changing magnitude (if frictionless). A vertical pull lifts a horizontal block.
**Setup:** Heavy block (M=1 kg) on a frictionless floor with a slide joint along x. Tendon from the block goes UP around a fixed peg at world (0.5, 0, 0.5), then HORIZONTAL to a downward-falling counterweight (M=0.5 kg) on a slide joint along z.
**Motion:** Counterweight falls; string pulls block; block slides horizontally as counterweight descends.
**Template:** `atwood.xml` + `capstan_effect.xml`.
**Hints:** Tendon wraps naturally. Side view. Render 3 s.

### Constraint / coupled motion (4)

#### `double_atwood` — Constraint
**Physics:** Atwood machine where one of the two masses is itself an Atwood machine. Three masses, complex coupled dynamics.
**Setup:** Top pulley at world (0, 0, 1.5). Left side: heavy mass M_h = 0.8 kg on a slide joint. Right side: a second pulley at world (0.3, 0, 0.9) (hanging on the right rope), with two masses m1=0.3 kg, m2=0.2 kg on slide joints below it. Joint equalities couple slides.
**Motion:** All 3 masses move; left mass goes down or up depending on net imbalance; right side masses also move relative to each other.
**Template:** `atwood.xml`.
**Hints:** Two joint equalities chained. Render 3-4 s.

#### `wheel_with_pendulum_inside` — Coupled rotation/pendulum
**Physics:** A wheel rolling on the floor with a pendulum mounted at its center — wheel acceleration drives pendulum swing; coupled dynamics.
**Setup:** Hollow cylinder (wheel) R=0.15 m rolling on the floor. Inside the wheel: a thin rod (pendulum, length 0.10 m, mass 0.05 kg) pivoted at the wheel's axle, free to swing. Wheel given initial rolling velocity.
**Motion:** Wheel rolls; pendulum swings due to wheel's transient acceleration; over time, pendulum's swing decays.
**Template:** `rolling_race.xml` + `conical_pendulum.xml`.
**Hints:** Hollow wheel via thin ring of geoms. Render 3 s. Side view.

#### `catenary_with_central_load` — Statics
**Physics:** A catenary chain with a heavy weight at the midpoint — the chain forms a V-shape (two straight segments) instead of a smooth cosh.
**Setup:** Same as `hanging_chain_catenary` but a heavy mass (M=0.5 kg) attached to the central link.
**Motion:** Chain settles to V-shape; midpoint hangs much lower than usual.
**Template:** `hanging_chain_catenary.xml`.
**Hints:** Render 5 s — last 3 s show the V. Side view.

#### `pulley_chain_loop` — Mechanism
**Physics:** Closed chain loop around two pulleys (like a tank tread laid flat). Drive one pulley → loop circulates continuously.
**Setup:** Two pulleys (R=0.05 m) at fixed positions 0.3 m apart. Closed chain (~30 links) wrapped around both. One pulley has initial qvel ω=3 rad/s.
**Motion:** Loop circulates around the two pulleys continuously.
**Template:** `belt_friction.xml` + `dominoes.xml`.
**Hints:** Programmatic gen for the loop. Render 3 s.

### Mass / drag / various (4)

#### `two_balls_drop_with_different_drag` — Drag
**Physics:** Two balls of the same mass dropped from the same height — one with low air drag, one with high — fall at different rates.
**Setup:** Two balls (each M=0.05 kg) at world (0, 0, 1.0). Ball A: sphere R=0.02 m. Ball B: larger sphere R=0.06 m (more drag). Both freejoints. Use joint damping (linear) as drag proxy. Drop both.
**Motion:** A reaches the floor first; B reaches later (a couple frames behind).
**Template:** `galileo_dropballs.xml`.
**Hints:** MuJoCo has no native air drag — use linear joint damping on each freejoint to mimic. Side view. Render 1.2 s.

#### `block_rolls_off_curved_hill` — Energy → projectile
**Physics:** Block at the top of a smooth curved hill slides down by gravity, then becomes a projectile when the hill ends.
**Setup:** Curved hill: a "ramp-then-cliff" shape (smooth slope going down, then a sharp drop to flat ground). Block placed at the top, friction zero.
**Motion:** Block slides down the slope, reaches the cliff edge, flies off as a projectile, lands somewhere ahead on the ground.
**Template:** `brachistochrone.xml` + `bowling.xml`.
**Hints:** Programmatic gen for the hill shape. Render 1.5 s.

#### `rolling_dumbbell` — Rolling / inertia
**Physics:** A dumbbell (two balls on a rod) on a flat floor doesn't roll uniformly — it tumbles end-over-end, alternating between resting on each ball.
**Setup:** Two spheres (R=0.04 m, M=0.1 kg each) connected by a thin rod (length 0.15 m, M=0.02 kg). Free body on the floor; initial qvel includes both translation (vx=0.3) and rotation.
**Motion:** Dumbbell rolls partially, then tumbles end-over-end, then rolls, then tumbles — characteristic gait.
**Template:** `rolling_race.xml`.
**Hints:** Floor friction tuned for rolling. Side view. Render 4 s.

#### `galileo_inclined_plane_squared` — Distance ~ t²
**Physics:** Ball rolling down a frictionless incline travels distances proportional to t² — passes the d=1,4,9,16 marks at t=1,2,3,4 (in any units).
**Setup:** Long inclined ramp (length 1.0 m, angle 10°). Ball at top. Place 4 visible colored markers at positions corresponding to 1, 4, 9, 16 (scaled) along the ramp.
**Motion:** Ball accelerates down; passes the 4 markers at predicted time intervals (1, 2, 3, 4 in some unit).
**Template:** `marble.xml`.
**Hints:** Friction near zero. Side view. Render 4 s.

### Rotating frame / dynamics (4)

#### `ball_in_rotating_dish_equilibrium` — Rotating frame
**Physics:** A ball in a parabolic dish spinning at constant ω settles at a radius where centrifugal "gravity" balances the dish's slope (a stable orbit).
**Setup:** Parabolic dish (`z = 4·r²` for r ∈ [0, 0.15]) rotating about its vertical axis at ω=6 rad/s. Ball (R=0.012, M=0.01 kg) inside, initial position near the rim with tangential velocity matching the dish.
**Motion:** Ball orbits with the dish at an equilibrium radius.
**Template:** `rotating_fluid.xml` (rotating container).
**Hints:** Dish via programmatic gen. Heavy dish bottom. Render 5 s. 3/4 camera from above.

#### `dropping_ball_on_rotating_disc` — Friction + centrifugal
**Physics:** Ball dropped onto a fast-spinning disc — friction briefly imparts angular velocity, then centrifugal force throws the ball off tangentially.
**Setup:** Spinning disc (R=0.20 m, ω=15 rad/s on a fixed hinge). Ball (R=0.025, M=0.05 kg) dropped from 0.5 m above the disc center.
**Motion:** Ball hits disc, briefly co-rotates, then slides off radially.
**Template:** `rotating_fluid.xml` + `bowling.xml`.
**Hints:** High disc-ball friction. Side view. Render 1.5 s.

#### `bead_on_rotating_horizontal_rod` — Centrifugal
**Physics:** A bead on a horizontal rod that's spinning — without anything to provide centripetal force along the rod, the bead slides outward and flies off the end.
**Setup:** Horizontal rod hinged at its center (axis z), spinning at ω=3 rad/s. Bead on a slide joint along the rod (initial offset 0.02 m from center).
**Motion:** Bead slides outward along the rod, accelerating; eventually flies off the end.
**Template:** `bead_on_helix.xml` + `conical_pendulum.xml`.
**Hints:** Rod must be horizontal (gravity normal to it). Render 2.5 s. Top-down camera.

#### `rotor_wheel_off_axis_wobble` — Imbalance
**Physics:** A wheel with its center of mass offset from its rotation axis wobbles as it spins. Whole system vibrates.
**Setup:** Wheel (R=0.10 m) with its axle going through a point offset 0.025 m from the wheel's true center. Axle on a hinge with init-qvel ω=10 rad/s.
**Motion:** Wheel spins, but visibly wobbles up-and-down (the offset center swings around the axle).
**Template:** `maxwell_wheel.xml` + `spinning_top.xml`.
**Hints:** Use `<inertial>` to position the COM off-center. Side view. Render 3 s.

### Multi-body / structures (4)

#### `three_pendulums_synced_via_support` — Synchronization (Huygens)
**Physics:** Three pendulums on a flexible support (the support itself can move) synchronize in phase over time — Huygens-style coupling through the support's small motion.
**Setup:** Horizontal bar (M=0.5 kg) hanging on two strings (the support, which can swing). Three pendulums (each length 0.30 m, M=0.10 kg) hanging from the bar at evenly spaced points. Initial pendulum angles: 30°, 0°, -30° (out of phase).
**Motion:** Bar's small motion couples the pendulums; over many oscillations, they synchronize to all swing in phase.
**Template:** `pendulum_waves.xml` + `coupled_pendulums.xml`.
**Hints:** Bar needs nonzero mass but small relative to pendulums. Render 20 s (sync takes time). Side view.

#### `chain_swing_collision_target` — Flexibility + collision
**Physics:** A flexible chain pendulum swung into a target hits with the bottom link's whip-effect velocity — higher than a rigid pendulum of the same length.
**Setup:** Chain (~15 links) pivoted at the top, hanging vertically. Bottom link is a heavier "tip". Pulled to 60° and released. A stationary target block at the chain's lowest point.
**Motion:** Chain whips down, bottom link strikes target with whip velocity, target moves off.
**Template:** `dominoes.xml` + `projectile_jenga.xml`.
**Hints:** Render 2.5 s. Side view.

#### `billiard_break_setup` — 2D multi-body collision
**Physics:** A cue ball striking a triangular rack of 10 balls — classic 2D elastic scatter. Energy and momentum redistribute over many bodies.
**Setup:** 10 balls in a triangular pack (4-3-2-1 rows) on a frictionless table. Cue ball positioned 0.3 m away, init-qvel toward the front ball at 2 m/s.
**Motion:** Cue ball strikes; 10-ball rack scatters in a characteristic pattern.
**Template:** `elastic_collision.xml` + `n_body_1d_collisions.xml`.
**Hints:** Top-down camera. Stiff contacts. Render 3 s.

#### `walking_robot_passive_slope` — Passive walking
**Physics:** A 2-legged "biped" with no actuators on a gentle slope — gravity drives walking; swing leg falls forward, plants, switch sides.
**Setup:** Two rigid legs (length 0.4 m, M=0.3 kg each) hinged at a common hip joint. Place on a 5° slope. Initial pose: one leg planted, other leg swung back.
**Motion:** Walker takes 3-5 passive steps down the slope before falling.
**Template:** `triple_pendulum.xml` (link chain).
**Hints:** Slope angle critical (4-7° works); too steep → falls; too shallow → no walk. Render 4 s. Side view.

### Door / dispersion (3)

#### `swinging_door` — Compound pendulum
**Physics:** A door (rectangular plate) hinged on one edge — its swing period depends on moment of inertia, larger than a point-mass pendulum of equivalent length.
**Setup:** Plate dims 0.8 m × 0.6 m × 0.02 m, M=2 kg. Hinged on one vertical edge (axis z). Initial pose: door open 90°. Damping low.
**Motion:** Door swings closed under gravity, oscillates back-and-forth (large period due to extended I).
**Template:** `pendulum.xml` + `compound_pendulum_shapes.xml`.
**Hints:** Top-down camera (door swings in horizontal plane). Render 5 s.

#### `dripping_chain_through_bottleneck` — Chain through hole
**Physics:** A chain piled on a horizontal plate falls through a small hole; the falling portion accelerates as more chain joins it.
**Setup:** Horizontal plate at world (0, 0, 0.3) with a small hole at the center. Chain (~40 links) piled on top of the plate, with the bottom of the chain through the hole.
**Motion:** Chain falls through the hole; accelerating downward as more falls in.
**Template:** `dominoes.xml`.
**Hints:** Programmatic gen for the chain pile + hole geometry. Render 2 s.

#### `chain_around_corner_table_edge` — Static friction
**Physics:** A chain laid over a table edge — part on table, part hanging — stays static if friction is high enough; slides otherwise. Critical fraction is determined by chain-table μ.
**Setup:** Chain (~30 links, each M=0.01 kg) laid flat on a tabletop with the last few links hanging off the edge. Chain-edge friction μ=0.4.
**Motion:** Chain stays static (or, with longer overhang, starts sliding).
**Template:** `falling_chain_classical.xml`.
**Hints:** Tune the overhang fraction to balance friction. Render 3 s.

---

## 🔵 Tier 1/2 — Round 3 additions (H and I packages, 34 more)

### Rotation / gimbal / gyroscope (4)

#### `gimbal_rings_3axes` — Rotational DOF
**Physics:** Three nested gimbals provide three independent rotational DOFs; when two axes align, "gimbal lock" reduces effective DOF to 2.
**Setup:** Outer ring (R=0.20 m) hinged to a fixed stand, axis z. Inner ring (R=0.15 m) hinged to outer, axis y. Innermost ring (R=0.10 m) hinged to inner, axis x. Small rotor inside the innermost ring. Initial qvel: each ring 1-2 rad/s on its own axis.
**Motion:** All three rings rotate independently. If you tune initial conditions, you can show gimbal lock (when two axes coincide).
**Template:** `spinning_top.xml` + `conical_pendulum.xml` (gimbal pattern).
**Hints:** Programmatic gen for the rings. Side view. Render 5 s.

#### `torsion_pendulum` — Rotational oscillation
**Physics:** A disc suspended by a wire that resists twisting oscillates torsionally; period T = 2π·sqrt(I/κ) where κ is the torsion constant.
**Setup:** Disc R=0.08 m, M=0.15 kg, hung from a single hinge axis pointing up. Hinge has stiffness κ=0.02 N·m/rad, damping=0.005. Initial qpos: disc twisted to 60°.
**Motion:** Disc rotates back-and-forth about the vertical axis, period ~2 s, slowly decaying.
**Template:** `pendulum.xml` (oscillation pattern).
**Hints:** Render 8 s — multiple periods. Top-down camera, fovy 40.

#### `l_handle_rotation_inertia` — Inertia tensor
**Physics:** An L-shaped rigid body has different moments of inertia about its three principal axes. Spinning about different axes shows visibly different dynamics.
**Setup:** L-shape made of two perpendicular rods (each 0.20 m × 0.02 m × 0.02 m). Freejoint, gravity off. Apply init-qvel: angular velocity along (a) the long arm axis, (b) the short arm axis, (c) the perpendicular axis. Render 3 versions OR one with the intermediate-axis instability.
**Motion:** Spinning about extreme axes: stable rotation. Spinning about intermediate axis: tumbles (similar to Dzhanibekov).
**Template:** `dzhanibekov_effect.xml`.
**Hints:** Use `<option gravity="0 0 0"/>`. Render 4 s.

#### `gyroscope_pendulum_3d_motion` — Coupled gyro + pendulum
**Physics:** A spinning gyroscope attached to a pendulum-like hanging rod — combined motion has both gyroscopic precession and pendulum swing.
**Setup:** Vertical rod (length 0.4 m) hung from a pivot via a hinge with axis y; at its bottom, a fast-spinning disc (R=0.10 m, ω=30 rad/s about disc's own axis). Pull pendulum to 30° angle and release.
**Motion:** Bob swings as a pendulum AND the gyro precesses — combined 3D motion.
**Template:** `pendulum.xml` + `spinning_top.xml`.
**Hints:** Render 6 s. 3/4 camera, fovy 40.

### Energy / projectile / kinematics (4)

#### `slingshot_elastic_release` — Energy storage/release
**Physics:** A pre-stretched elastic band (spring) releases stored elastic PE into a ball's kinetic energy — slingshot effect.
**Setup:** Two posts with a horizontal "rubber band" (tendon with stiffness, modelled as a spring). Ball placed against the band, band stretched back by initial qpos. At t=0, the ball is unconstrained; band snaps forward, launching the ball.
**Motion:** Ball flies forward at high velocity; arcs through the air.
**Template:** `spring_mass.xml` + `projectile_jenga.xml`.
**Hints:** Tune spring stiffness for visible launch. Side view. Render 1.5 s.

#### `trampoline_bounce_membrane` — Multi-bounce on elastic surface
**Physics:** A ball bouncing on an elastic membrane — surface flexes, ball bounces multiple times with progressive energy loss.
**Setup:** Membrane: 8×8 grid of small masses with springs between (similar to mexican_hat_drum but smaller, with damping). Edges fixed. Ball dropped from above.
**Motion:** Ball strikes membrane, bounces back up, falls again, bounces several times with decaying amplitude.
**Template:** `mexican_hat_drum_modes.xml` (grid + springs) + `bowling.xml` (ball).
**Hints:** Membrane damping for energy loss. Render 4 s. 3/4 camera.

#### `multi_link_chain_vertical_collapse` — Free fall / chain
**Physics:** A vertical chain standing straight up topples over progressively under gravity; the top accelerates while the base remains in place initially.
**Setup:** Chain of 20 links stacked vertically at world (0, 0, z=0.05 to z=1.05), hinged together. Bottom link pinned to the floor. Initial perturbation: top link tilted 2°.
**Motion:** Top tips and falls, pulling lower links along; full collapse to the floor.
**Template:** `dominoes.xml` + `beam_buckling.xml`.
**Hints:** Hinge damping 0.005 per joint. Render 2.5 s. Side view.

#### `galileo_chord_isochrony` — Energy / kinematics
**Physics:** Galileo's chord isochrony: balls released from rest sliding down chords of a vertical circle all reach the bottom (the circle's lowest point) at the same time, regardless of chord angle.
**Setup:** A vertical circle (R=0.5 m) drawn with thin marker geoms; 3-4 frictionless chord-shaped slides starting from different points on the circle, all ending at the bottom. One ball on each slide, released simultaneously.
**Motion:** All balls reach the bottom simultaneously despite different distances and angles.
**Template:** `brachistochrone.xml` (multi-track ball racing).
**Hints:** Programmatic gen for the chord geometry. Render 1 s — close finish. Side view, pos (1.0, -1.5, 0.3), fovy 40.

### Mechanisms (4)

#### `rack_and_pinion` — Mechanism
**Physics:** A gear (pinion) meshed with a flat toothed bar (rack) converts rotation to linear translation.
**Setup:** Pinion: small cylinder R=0.05 m on a hinge. Rack: long box with a slide joint (along x). Joint equality couples pinion rotation to rack translation: rack_x = -R_pinion · pinion_angle.
**Motion:** Pinion driven by init-qvel; rack translates uniformly.
**Template:** `gear_train_2_gears.xml` + `slider_crank_mechanism.xml`.
**Hints:** Top-down camera. Render 3 s.

#### `scotch_yoke` — Mechanism
**Physics:** Converts rotation to sinusoidal (NOT polygonal) linear motion. Different from slider-crank, which gives non-sinusoidal motion.
**Setup:** Rotating crank with a pin (small post offset from center); the pin engages a vertical slot in a "yoke" (a box with a slide joint along x). As the crank rotates, the pin slides along the slot, pushing the yoke horizontally.
**Motion:** Crank rotates uniformly; yoke moves sinusoidally x(t) = R·cos(ωt).
**Template:** `slider_crank_mechanism.xml`.
**Hints:** Slot is a long groove in the yoke; pin slides along it (slide joint between pin and yoke). Render 3 s.

#### `lazy_tongs_extending` — Mechanism
**Physics:** Lazy tongs (accordion / pantograph) — a linkage of crossed rods extends linearly when actuated at one end.
**Setup:** 4-5 X-shaped pairs of rods, each pair pinned at the middle and at the ends to adjacent pairs. One end has a slide joint (push it inward to extend the mechanism).
**Motion:** End pushed → tongs extend; opposite end moves with mechanical advantage.
**Template:** `slider_crank_mechanism.xml` (linkage idea).
**Hints:** Programmatic gen. Initial impulse rather than actuator. Render 2.5 s.

#### `caliper_scissor_mechanism` — Mechanism
**Physics:** Scissor mechanism (two crossed arms pinned at center) — closing one end opens the other proportionally.
**Setup:** Two long bars crossed at their center on a hinge. Pull the bars at one end together; their other ends spread apart.
**Motion:** One end closes → other end opens, by the lever ratio.
**Template:** `four_bar_linkage.xml`.
**Hints:** Side view. Render 3 s.

### Constrained motion / sliding (4)

#### `bead_on_inverted_cycloid` — Tautochrone (upside-down)
**Physics:** A bead released from various heights on an INVERTED cycloid all reach the bottom in the same time — the cycloid's tautochrone property holds for the inverted shape too.
**Setup:** An inverted-cycloid wire (programmatic, opens downward). 3 beads placed at different heights on the wire, all released simultaneously.
**Motion:** All beads reach the bottom of the cycloid at the same time.
**Template:** `bead_on_cycloid_track_isochrony.xml` (cycloid generator) — inverted.
**Hints:** Render 1.5 s.

#### `two_objects_on_conveyor_belt` — Friction / belt
**Physics:** Two objects placed on a moving conveyor belt — friction accelerates them up to belt speed; afterwards they move with the belt.
**Setup:** A horizontal belt (rectangular surface) given a constant velocity vx=0.5 m/s. Two boxes placed on the belt with zero initial velocity.
**Motion:** Boxes accelerate due to friction with the belt; reach belt speed; then move with it.
**Template:** `belt_friction.xml` + `incline_friction.xml`.
**Hints:** Belt as a moving plane — give it `init-qvel` and high mass so it doesn't slow. Render 3 s.

#### `block_slipping_threshold_on_incline` — Friction transition
**Physics:** A block on an incline is static if angle θ < arctan(μ); above that angle, it slides. The transition is abrupt.
**Setup:** Incline angle slowly increases over time (init-qvel slowly tilts the ramp). Block on the incline with μ=0.4 (so critical angle ~22°).
**Motion:** Block stays static while ramp tilts; at critical angle it suddenly starts sliding and accelerates down.
**Template:** `incline_friction.xml` + `tipping_vs_sliding.xml`.
**Hints:** Initial ramp tilt 0°, init-qvel small rotation rate. Render 4 s.

#### `pendulum_string_breaks_at_peak` — Energy + projectile
**Physics:** A pendulum at the peak of its swing has zero KE (all PE). If the string breaks at that instant, the bob falls straight down. Compare with breaking at the bottom (max KE, flies horizontally).
**Setup:** Pendulum pulled to 60° and released. At a specific time (when the bob reaches peak), the string "breaks" — modelled by setting a tendon limit that fails. The bob becomes a free body.
**Motion:** Bob swings up, string breaks at peak, bob falls straight down from peak (vs would fly horizontally if string broke at bottom).
**Template:** `pendulum.xml`. Add a tendon that fails by setting `range` and `solref`.
**Hints:** "Breaking" is implemented by removing the constraint at the right time. Could use two separate scenes: one with string still intact (for comparison) — but render one with the break. Render 2 s.

### Multi-body / collision (5)

#### `two_balls_on_rotating_string` — Rotating frame
**Physics:** Two equal-mass balls connected by a rigid string, rotating about their common COM, demonstrate circular motion (centripetal force = tension).
**Setup:** Two equal balls (M=0.05 kg each) connected by a thin string (length 0.4 m). System at rest with initial angular velocity 4 rad/s about COM. No gravity (or gravity perpendicular to rotation plane).
**Motion:** Balls orbit each other in a circle, string taut, period T = 2π/ω.
**Template:** `binary_pendulum` style or new — like a rotating dumbbell.
**Hints:** Set gravity to 0 or perpendicular plane. Top-down camera. Render 4 s.

#### `pendulum_hits_spring_target` — Energy transfer
**Physics:** A pendulum swung into a spring-loaded target compresses the spring; spring then bounces target away, transferring energy.
**Setup:** Pendulum at 45°. A target block (M=0.1 kg) on a frictionless surface, with a spring attached behind it. Pendulum bob (M=0.2 kg) hits the target.
**Motion:** Bob hits target, compresses spring, spring bounces target away, pendulum recoils.
**Template:** `pendulum.xml` + `spring_mass.xml` + `elastic_collision.xml`.
**Hints:** Render 3 s.

#### `n_marbles_funnel_clog` — Granular jam
**Physics:** Many marbles fed through a narrowing funnel can jam at the throat — granular media jamming, where arches of force-chains support the load.
**Setup:** Funnel (R=0.10 top → R=0.012 throat), ~40 small balls (R=0.005) placed above the throat. Gravity acts.
**Motion:** Balls accumulate above the throat; some flow through; eventually jam forms and flow stops.
**Template:** `rotating_fluid.xml` (granular hack) + `marble_in_funnel.xml`.
**Hints:** Throat just slightly bigger than ball diameter. Render 4 s.

#### `double_chain_fall_compare` — Chain dynamics comparison
**Physics:** Two chains: one with both ends free, one with one end held — both released. The freely-falling one falls at g; the held one has tension dynamics, falls faster than g (like falling_chain_classical).
**Setup:** Two parallel chains. Left chain: free, dropped horizontally. Right chain: half on a table, half hanging.
**Motion:** Right chain accelerates faster than left (after the same time, right reaches the ground first).
**Template:** `falling_chain_classical.xml`.
**Hints:** Render 1.5 s. Side view, wide.

#### `ball_inside_closed_box_bounces` — Multi-bounce containment
**Physics:** A ball inside a closed 5-sided box (open top) bounces off the walls and floor many times; CoR < 1 makes eventually settle.
**Setup:** Cube box (open top), 0.30 m side. Ball (R=0.02, M=0.05 kg) inside, initial qvel (0.5, 0.7, -0.3).
**Motion:** Ball ricochets around the box, eventually losing energy and settling.
**Template:** `bowling.xml` + `elastic_collision.xml`.
**Hints:** Render 4 s. 3/4 camera.

### Structures / statics (4)

#### `leaning_tower_critical_angle` — Equilibrium / tipping
**Physics:** A tower is stable as long as the projection of its COM onto the floor stays inside the base. Tilt it beyond, and it tips.
**Setup:** A tall thin tower (rectangular box, dims 0.10 × 0.10 × 0.6 m) on a slowly-tilting platform. Platform tilts via init-qvel angular rotation.
**Motion:** Tower stays upright while platform tilts; at critical angle (~10° for this geometry), tower tips and falls.
**Template:** `cone_balanced_on_tip.xml` + `tipping_vs_sliding.xml`.
**Hints:** Render 5 s.

#### `arch_stability_increasing_load` — Statics / failure
**Physics:** An arch can hold up to its critical load; beyond that, individual stones slip and the structure fails.
**Setup:** Arch (like `arch_compression.xml`) with a movable load on top that grows over time (or step-increments).
**Motion:** Arch holds small load → grows → eventually buckles when load exceeds critical.
**Template:** `arch_compression.xml`.
**Hints:** Programmatic gen for the arch. Load can be a heavy mass that descends onto the arch. Render 4 s.

#### `granular_arch_self_support` — Granular statics
**Physics:** Granular media (small balls) can form a self-supporting arch over a gap — force chains transfer load to the supports.
**Setup:** Two supports with a gap between them (10 cm). Many small balls (R=0.01) piled on top. After release, some balls fall through; the rest form a self-supporting arch over the gap.
**Motion:** Initial pile collapses; settling state shows a stable arch with balls bridging the gap.
**Template:** `rotating_fluid.xml` (granular).
**Hints:** Render 3 s. Side view.

#### `waterwheel_with_balls` — Granular flow / mechanism
**Physics:** A water wheel driven by cascading "water" (granular balls) — gravity pulls balls into cups on the wheel rim, wheel rotates.
**Setup:** A wheel (R=0.15 m) with 8 small cups on its rim, on a horizontal axle. A stream of small balls falling from above onto one side of the wheel.
**Motion:** Balls land in cups, weight unbalances the wheel, wheel rotates; new cups receive balls; continuous rotation.
**Template:** `rotating_fluid.xml` + `marble.xml`.
**Hints:** Hard — granular cascade. Programmatic. Render 4-5 s.

### Other (5)

#### `inverted_pendulum_on_hinge_falls` — Instability
**Physics:** An inverted rigid rod pinned at the base, with no support, falls due to instability. Different from `falling_chimney` (which has more pinning detail) and `cone_balanced_on_tip` (which is a free body, not pinned).
**Setup:** Rod (length 0.5 m, M=0.5 kg) pinned at base with a hinge (axis y, no stiffness). Initial pose: vertical (no perturbation), with init-qvel tiny angular velocity (0.05 rad/s) to seed the fall.
**Motion:** Rod falls over, pivot at base.
**Template:** `falling_chimney.xml`.
**Hints:** Render 2 s. Side view.

#### `chain_in_freefall_no_tension` — Free fall demonstration
**Physics:** A chain in free-fall has zero internal tension — every link accelerates at g, so they all "float" relative to each other. The chain maintains its initial shape during fall.
**Setup:** Chain shaped in a recognizable curve (e.g., a U or a horizontal line) at world height z=2.0 m. Released from rest.
**Motion:** Entire chain falls together, maintaining its initial shape (no relative motion between links).
**Template:** `dominoes.xml`.
**Hints:** Verify by visual: chain shape doesn't change as it falls. Render 0.6 s (fall time from 2 m ≈ 0.64 s).

#### `chain_pulled_through_pipe` — Constrained chain
**Physics:** A chain pulled through a curved tube — the constraint of the tube redirects the chain's motion; the pulling force changes direction at every bend.
**Setup:** Curved tube (gen): like an S-shape. Chain inside the tube. One end of the chain pulled out at constant force.
**Motion:** Chain slides through the tube; visible direction changes at each bend.
**Template:** `bead_on_helix.xml` + `dominoes.xml`.
**Hints:** Programmatic. Render 4 s.

#### `brake_drum_friction` — Friction / energy dissipation
**Physics:** A spinning drum is slowed by a friction brake pressing on its rim. Kinetic energy dissipated as heat (or in this case, just observed as slowing rotation).
**Setup:** A heavy disc (drum) R=0.15 m, M=1 kg, on a vertical axle, spinning at ω=20 rad/s. A "brake pad" (block on a slide joint) pressed against the rim with some normal force.
**Motion:** Drum spins; friction torque slows it down; eventually stops.
**Template:** `maxwell_wheel.xml` + `incline_friction.xml`.
**Hints:** Brake pad against the rim has friction coefficient. Render 4 s.

#### `two_disks_friction_coupling` — Friction-driven rotation
**Physics:** Two discs in contact at their rims, one spinning — friction between rims drives the other disc to spin (opposite direction). No teeth, just friction.
**Setup:** Disc A (R=0.08 m, M=0.5 kg) on a vertical hinge, spinning at ω=10 rad/s. Disc B (R=0.12 m) on a vertical hinge, initially at rest. The two rims pressed together with some normal force.
**Motion:** A spins; friction transfers torque to B; B starts rotating in opposite direction at scaled speed (R_a/R_b ratio).
**Template:** `gear_train_2_gears.xml` (but without equality — let friction couple them).
**Hints:** Tune normal force and friction to get clean coupling. Render 4 s.

#### `galton_board_classic` — Statistics / multi-body
**Physics:** Many balls dropped through a grid of pegs end up distributed in a binomial (approximate normal) distribution at the bottom.
**Setup:** Grid of small pegs (5-7 rows, triangular layout). Funnel above releases balls one at a time (or many at once). Catchment bins below collect them.
**Motion:** Each ball bounces left/right at each peg level; net path leads to a bell-curve distribution in the bins.
**Template:** `dominoes.xml` (peg layout) + `bowling.xml` (balls).
**Hints:** Pegs as small cylinders. ~20 balls in the funnel. Render 5-6 s.

#### `plate_balancing_on_stick` — Balance + rotation
**Physics:** A plate spinning on a vertical stick — its angular momentum gyroscopically stabilizes the plate against tipping over.
**Setup:** Vertical thin stick on the floor. A horizontal plate (M=0.2 kg, R=0.15 m) balanced on the stick's top, initially spinning at ω=20 rad/s about the stick's axis.
**Motion:** Plate spins; gradually slows due to friction; while spinning fast, stays balanced; eventually wobbles and falls when spin too slow.
**Template:** `spinning_top.xml`.
**Hints:** Stick tip-plate friction needs tuning. Render 5-6 s.

#### `ball_bouncing_corner_2d` — Collision geometry
**Physics:** A ball bouncing into a 90° corner (two perpendicular walls) reflects twice and exits in a direction opposite to incoming (parallel reverse).
**Setup:** Two perpendicular walls forming a corner. A ball with init-qvel into the corner at some angle.
**Motion:** Ball hits one wall, reflects; immediately hits the other wall, reflects again; exits in a direction antiparallel to original.
**Template:** `elastic_collision.xml` + `bowling.xml`.
**Hints:** Stiff contacts. Top-down camera. Render 1 s.

#### `swinging_bell_with_clapper` — Multi-body coupling
**Physics:** A bell swinging on a pivot has a clapper inside (a sub-pendulum hung from the bell's interior); the two pendulums have different effective lengths, so the clapper strikes the bell's walls at characteristic intervals.
**Setup:** Bell: outer hollow cup (4 thin walls + closed top, opening down), M=0.5 kg, pivoted at the top with hinge axis y. Inside the bell: a small clapper (sphere R=0.015, M=0.05 kg) on a short string (length 0.10 m) hung from the bell's interior ceiling. Bell pulled to 60° and released.
**Motion:** Bell swings back and forth as a pendulum; clapper swings inside but with its own (shorter) period; clapper periodically strikes the inner bell wall.
**Template:** `pendulum.xml` (basic pendulum) + `double_pendulum.xml` (nested swings).
**Hints:** Bell wall is a few thin box geoms making the hollow cup. Stiff contact between clapper and walls (gotcha #4). Render 5 s. Side view, pos (0, -1.2, 0.5), fovy 40.

---

## 🔴 Tier 3 — Harder, multi-part scenes (5–10 hr each)

These are bigger projects that warrant their own day each. Don't include in
the 18-scenes-per-day plan; allocate them as one-off projects.

- **trebuchet** — counterweight + arm + sling + projectile; classic mechanical advantage
- **crane_hoist_articulated** — multi-link crane arm + cable + hook + load
- **roller_coaster_simple** — track with loops, hills, and a launch
- **cam_follower_mechanism** — rotating cam drives a reciprocating follower
- **differential_gear_visual** — visual demo of how a car differential splits torque
- **articulated_arm_5dof** — 5-DOF robotic arm reaching for an object
- **domino_fibonacci_spiral** — programmatic Fibonacci or logarithmic spiral of dominoes
- **pendulum_clock_escapement** — escapement wheel + pendulum drives a clock
- **perpetual_motion_demos** — show 3 famous "perpetual motion" designs failing
- **kinetic_sculpture_mobile** — multi-pendulum mobile, balanced and swinging

---

## ❌ Tier 4 — Out of scope (need a different simulator)

These need fluid / EM / optics / thermo and cannot be done with MuJoCo as-is.

- ❌ `hydrostatic_buoyancy` — needs continuous fluid; granular hack is poor
- ❌ `surface_tension`, `capillary_action` — needs SPH/MPM
- ❌ `wave_tank`, `dam_break` — needs SPH
- ❌ `vortex_shedding`, `karman_street` — needs Navier-Stokes
- ❌ `charged_particle_in_field` — needs EM force solver
- ❌ `electromagnetic_induction` — Faraday's law
- ❌ `motor_generator` — coil + magnet rotation, needs EM
- ❌ `light_refraction_lens` — needs ray tracing
- ❌ `double_slit_interference` — needs wave optics
- ❌ `gas_in_piston` — needs thermodynamics

For any of these, suggest a different toolkit (Genesis, Taichi+MPM, Manim,
or pre-animated Blender) — they are deliberately off-roadmap for this repo.

## Unsorted ideas (to triage)

New scene ideas land here. The master keeper triages and slots them into the
right tier when reviewing RETURNS_LOG.md.

- ...

---

## Distribution math

| Tier | Count |
|------|------:|
| ✅ Done | 23 |
| 🔵 Tier 1 (kept) | 28 |
| 🟣 Tier 1 (new) | 23 |
| 🟢 Tier 1 (final additions, round 2) | 10 |
| 🟡 Tier 1/2 (F + G additions, round 2) | 34 |
| 🔵 Tier 1/2 (H + I additions, round 3) | 34 |
| 🟠 Tier 2 | 24 |
| 🔴 Tier 3 (reserved as special projects) | 10 |
| **Total available for assignment** | **129 Tier 1 + 24 Tier 2 = 153** |

Plan: 9 employees × 17 each = 153, exhausting the assignable pool (Tier 3 is
reserved for special projects). Per-person mix: 12 Tier 1 + 5 Tier 2, spread
across topic categories (pendulum / rolling / collision / spring-or-wave /
chain-or-curve / free-body-or-structure / friction-or-mechanism / energy /
mechanism / equilibrium) so nobody gets a one-topic day. Round-1 packages
A–E used the first 85; round-2 packages F and G use the next 34; round-3
packages H and I use the latest 34.
