# Scene Backlog

**Status (2026-05-23):** 23 done, **~90 candidates** queued with full
descriptions, ~10 explicitly out-of-scope. Theoretical ceiling ≈ 88–92
genuinely-distinct mechanics scenes (no parameter sweeps); beyond that, the
next idea is just "the same with different numbers".

## How to use this file

1. **Pick an item** from your `ASSIGNMENT.md` (in handoff packages) or any
   unclaimed item here (master only).
2. **Read its full description** — `Physics`, `Setup`, `Expected motion`,
   `Template`, `Hints`. The Template line tells you which existing scene to
   copy from as a starting point. Don't write from scratch.
3. **Build it** following the 5-step recipe in `CLAUDE.md` / `README.md`.
4. **Mark done** in `DIARY.md` when finished, strike the line here.

## Conventions for each entry

```
### `scene_filename` — Topic tag

**Physics:** One sentence on the concept being demonstrated.
**Setup:** Physical arrangement, initial conditions, what bodies + joints exist.
**Motion:** What the rendered clip should show.
**Template:** Which existing scene to copy from as a starting point.
**Hints:** Key parameter values, common pitfalls, gotchas to watch (cross-ref `docs/gotchas.md` when relevant).
```

---

## ✅ Done (23 scenes)

See `DIARY.md` for the inventory and notes. mp4s in `out/` (original 4) and
`out/new_scenes/` (the rest). Showreel at
`out/new_scenes/all_scenes_grid.mp4`.

| # | scene | topic |
|---|-------|-------|
| 1 | bowling | collision + friction |
| 2 | marble | gravity + rolling |
| 3 | pendulum | simple oscillation |
| 4 | projectile_jenga | projectile + stability |
| 5 | newton_cradle | elastic chain |
| 6 | double_pendulum | chaos |
| 7 | incline_friction | μ comparison |
| 8 | dominoes | chain reaction |
| 9 | spring_mass | SHM |
| 10 | atwood | inextensible string |
| 11 | spinning_top | precession + nutation |
| 12 | conical_pendulum | circular motion |
| 13 | loop_the_loop | centripetal force |
| 14 | rolling_race | I/MR² |
| 15 | pendulum_waves | multi-pendulum sync |
| 16 | coupled_pendulums | normal modes |
| 17 | block_overhang | ∑L/(2k) harmonic series |
| 18 | galileo_dropballs | equivalence of fall time |
| 19 | elastic_collision | momentum transfer |
| 20 | brachistochrone | cycloid vs straight |
| 21 | maxwell_wheel | rotational+translational KE |
| 22 | beam_buckling | Euler instability |
| 23 | rotating_fluid | centrifugal pile-up |

---

## 🔵 Tier 1 — Quick wins (1–2 hr each, copy + tweak)

### Pendulum / oscillation (7)

#### `bifilar_pendulum` — Oscillation
**Physics:** Mass suspended by two parallel strings swings, but rotation about the vertical is geometrically blocked. Period depends on string length and lateral separation.
**Setup:** A horizontal rod (or thin plate) hangs from two vertical strings at its two ends. Push it sideways; it swings without rotating.
**Motion:** Rod translates sideways in pure swing; no twisting about its own axis.
**Template:** `pendulum.xml`. Use two tendons instead of one.
**Hints:** Use spatial tendons (`<tendon><spatial>`) for the two strings — see gotcha #2 for placement. Rod needs a freejoint or a slide+slide joint pair; constraints from the two tendons enforce no rotation. Render ~4 s.

#### `trifilar_pendulum` — Oscillation
**Physics:** Disc suspended by three equally spaced strings; angular oscillation period is sensitive to the disc's moment of inertia (this is how I is measured experimentally).
**Setup:** Horizontal disc hung from a ceiling triangle by three vertical strings (radius r, length L). Twist the disc slightly about the vertical axis; it oscillates torsionally.
**Motion:** Disc rotates back and forth about its vertical axis with period T = 2π·sqrt(I·L/(m·g·r²)).
**Template:** `pendulum.xml` + `atwood.xml` (for the tendon-as-string idea). Three tendons, one disc, init-qpos a small yaw.
**Hints:** Use a single hinge joint about z for the disc, with NO stiffness. The "restoring" comes purely from the three-string geometry — strings tilt as the disc rotates, giving a gravitational restoring torque. Disc body needs a freejoint or constrained body.

#### `compound_pendulum_shapes` — Oscillation
**Physics:** Period of a rigid-body pendulum depends on I_pivot, not just mass — three different shapes pivoted at one end swing at different periods even with the same mass.
**Setup:** Three pendulums side-by-side: a thin rod, a flat plate, and a thin triangular plate, all pivoted at their top with hinge joints. Same mass each.
**Motion:** Released from the same angle, the three swing at visibly different periods.
**Template:** `pendulum.xml`. Replicate 3× with different geom types.
**Hints:** Compute I_pivot for each shape (parallel-axis theorem). Use `<inertial>` to override if needed — gotcha #14. Side-view camera, fovy ~40.

#### `wilberforce_pendulum` — Oscillation / coupling
**Physics:** Mass hangs on a spring with both longitudinal and torsional stiffness. With matched periods, energy slowly trades between bobbing and twisting.
**Setup:** Cylindrical bob hangs from a long thin coiled "spring" (modelled by a tendon for visual + a custom stiff+damped joint pair). Bob has a slide joint (z) and a hinge joint (about z). Both joints have stiffness and similar periods.
**Motion:** Initially the bob bobs up-and-down; over 5–10 oscillations the bobbing dies and the bob is twisting; then it twists back to bobbing. Beats.
**Template:** `spring_mass.xml` + `spinning_top.xml`.
**Hints:** Tune k_slide and k_torsion so periods match within 5%. Add small initial qvel in slide only; the coupling (which we'd add via a constraint or pre-existing geometry) will transfer energy. If pure-MuJoCo coupling is hard, use a small `<equality>` linking the two joints with a tiny polycoef. Render 15+ s.

#### `damped_pendulum_decay` — Oscillation
**Physics:** A pendulum with viscous damping shows exponential decay of amplitude: θ(t) = θ₀·e^(-γt)·cos(ωt). Period is nearly unchanged for light damping.
**Setup:** Single pendulum with a moderate joint damping value.
**Motion:** ~8–10 visible swings, each successively smaller; eventually settles to rest.
**Template:** `pendulum.xml`. Add `damping="0.05"` to the hinge.
**Hints:** Pick damping so the envelope decay is visible within 8 s (try 0.04). Camera: same as `pendulum.xml`. Grid PNG should show monotonically decreasing amplitude.

#### `pendulum_with_air_drag` — Oscillation
**Physics:** Quadratic drag (∝ ω²) decays a pendulum faster at large amplitudes than viscous damping; the envelope curves rather than being a clean exponential.
**Setup:** Same as damped pendulum but with quadratic damping if MuJoCo supports it, otherwise high linear damping that mimics drag.
**Motion:** Initially fast amplitude decay, slowing as amplitude shrinks.
**Template:** `pendulum.xml`.
**Hints:** MuJoCo joint damping is linear in ω. To fake quadratic, use a large linear damping and accept the qualitative behavior. Side-by-side render with `damped_pendulum_decay` would be ideal but each scene is rendered alone.

#### `triple_pendulum` — Chaos
**Physics:** Adding a third link to the double pendulum increases chaotic sensitivity; the trajectory is wildly path-dependent on initial conditions.
**Setup:** Three rigid arms connected by hinges in series, top pivot fixed. Link lengths 0.30 / 0.25 / 0.20 m, masses 0.15 / 0.12 / 0.10 kg (decreasing as you go down — like double_pendulum). Each hinge has axis y, damping=0.005.
**Motion:** From `init-qpos="1.4, 0, 0"` (top link near horizontal, others vertical), the system rapidly transitions to chaotic flailing where all three links swing wildly.
**Template:** `double_pendulum.xml`. Add a third nested body with the same hinge axis.
**Hints:** Render 8 s — chaos takes a few seconds to fully develop. Camera same as double_pendulum (front view, fovy 38). Damping smaller than double_pendulum so motion lasts longer.

### Rolling / rotation (4)

#### `yoyo_with_reversal` — Rotation
**Physics:** Like Maxwell wheel but the wheel hits the lower string limit and re-ascends — the string catches and the rotation direction reverses with respect to descent.
**Setup:** Modified Maxwell wheel where the slider joint hits a "stop" at the bottom, causing the equality constraint to allow re-ascent.
**Motion:** Disc descends, rotates, hits bottom, climbs back up while spinning the same way.
**Template:** `maxwell_wheel.xml`. Add a slider range stop at the bottom.
**Hints:** The polycoef equality may bind oddly at the range limit — use stiff `solref` for the slider's range so the bounce is mostly elastic. Render 6–8 s to see one full cycle.

#### `rolling_cone` — Rotation
**Physics:** A cone rolling on its side traces a circular path centered on its apex (precession of the rolling axis).
**Setup:** A cone (apex on the floor) rolls in a circular path. Use a thin cone geom or build from segments.
**Motion:** Cone rolls around its apex, completing a circle in proportion to its half-angle.
**Template:** `rolling_race.xml`.
**Hints:** Body needs a freejoint + rolling-without-slip via friction. Initial spin matters: give it angular velocity so it starts rolling, not skidding. fovy ~38, top-down 3/4 camera. Render 4–6 s.

#### `spool_with_string` — Rotation / counter-intuitive
**Physics:** A spool with string wrapped underneath — pulling the string horizontally rolls the spool TOWARD you (not away). Surprising visual.
**Setup:** Spool (cylinder with a smaller axle) on the floor. String wraps under the axle and exits horizontally toward +x. Pull the string by ramping a tension.
**Motion:** Spool rolls in +x direction while string unwinds and the spool's axle moves toward you.
**Template:** `marble.xml` + `maxwell_wheel.xml`.
**Hints:** No actuator needed if you set the spool's initial qvel so it's already in motion. Alternatively, attach the string end to a stationary point and give the spool a small push so the tension acts. Camera: side view.

#### `rolling_chain` — Rotation
**Physics:** A flexible chain laid flat on the floor can be pulled like a tank tread — the chain "rolls" by having parts continuously transition between contact and free-fall.
**Setup:** Long chain of small linked bodies on the floor; one end is given a horizontal velocity.
**Motion:** The chain moves like a tractor tread, with the leading end being lifted by tension and falling at the rear.
**Template:** `dominoes.xml` (chain layout) + `atwood.xml` (linked bodies).
**Hints:** Probably needs ~30 small links with friction-enabled contact. Render 4–5 s. May need a programmatic generator (`gen_rolling_chain.py`).

### Collision / momentum (6)

#### `inelastic_collision` — Collision
**Physics:** Two bodies stick together after impact; kinetic energy is lost but momentum is conserved.
**Setup:** Two cubes on a frictionless track; one moving toward the other. On contact, they stick (via high-damping contact or an equality constraint that activates).
**Motion:** Moving block hits stationary block, both move off together at half the original velocity (for equal masses).
**Template:** `elastic_collision.xml`.
**Hints:** Disable elastic contact: set `solref` and `solimp` to soft values so the impact dissipates. Or use a tendon equality that snaps in on contact (advanced). Camera: same as elastic_collision.

#### `coefficient_of_restitution` — Collision
**Physics:** A ball bouncing on a floor loses a fixed fraction of energy per bounce. Successive bounce heights follow h_n = h_0 · e^(2n), giving geometric decay.
**Setup:** Single ball dropped from a height onto a hard floor, with contact `solref/solimp` tuned for partially elastic collision.
**Motion:** Ball bounces with decreasing height; the envelope shows geometric decay over 5–8 bounces.
**Template:** `bowling.xml` (for floor + ball pattern).
**Hints:** Use `solref="-100000 -8" solimp="0.98 0.999 0.001"` for ~85% restitution. Camera: side view, frame from 0 to drop height. Render 4–5 s.

#### `ballistic_pendulum` — Collision + oscillation
**Physics:** A "bullet" embeds in a pendulum bob; momentum conservation gives the bob's swing velocity; energy conservation gives the swing height. The combo lets you measure the bullet's speed.
**Setup:** Small fast cube (the bullet) flies horizontally into a heavier cube hanging on a string (the bob). On contact, the bullet sticks (inelastic).
**Motion:** Bullet → impact → bob+bullet swing as one pendulum to a measurable height.
**Template:** `pendulum.xml` + `projectile_jenga.xml`.
**Hints:** Inelastic contact (soft solref) on the bob-bullet pair. Mass ratio matters: bullet/bob ≈ 0.05 gives a visible but modest swing. Camera: side view.

#### `basketball_tennis_drop` — Collision / energy transfer
**Physics:** Stacked balls dropped together; the bottom one bounces off the floor and immediately collides with the top one, transferring kinetic energy upward. The small top ball can shoot up at ~3× the drop speed.
**Setup:** Two balls stacked vertically (small one on top of big one), released from a height.
**Motion:** Big ball hits floor and rebounds; immediately collides with small ball mid-air; small ball flies up far higher than its drop height.
**Template:** `bowling.xml` + `elastic_collision.xml`.
**Hints:** Use very high contact stiffness (`solref="-200000 -20"`) for both bottom-ball-to-floor AND ball-to-ball contacts. Initial separation between balls: 0.01 m (almost touching). Mass ratio ~10:1 (heavy:light) gives the cleanest effect.

#### `glancing_2d_collision` — Collision
**Physics:** Equal-mass elastic collision at an angle: the two balls fly off at 90° to each other. Their final velocity vectors form a right angle.
**Setup:** Two pucks on a frictionless table; one moving, the other stationary, with a small lateral offset so the impact is glancing (not head-on).
**Motion:** Moving puck strikes glancingly; both pucks scatter at angles that sum to 90°.
**Template:** `elastic_collision.xml`. Switch to 2D (top-down camera).
**Hints:** Pucks on a slide-x and slide-y joint pair (no rotation). High contact stiffness, zero friction between pucks and floor. Top-down camera. Render 2 s.

#### `line_collision_chain` — Collision
**Physics:** Newton's cradle without the strings — a row of touching balls. Striking the leftmost transmits momentum along the line; only the rightmost moves off.
**Setup:** 5 balls in a horizontal row on a frictionless track, just barely touching. Add 1 more ball arriving from the left with some velocity.
**Motion:** Incoming ball strikes, momentum "walks" down the line in an instant, the rightmost ball leaves at the incoming velocity.
**Template:** `newton_cradle.xml` (for contact tuning) + `elastic_collision.xml` (for track).
**Hints:** Use the same stiff contact + small timestep recipe as Newton's cradle (gotcha #4). Balls on freejoints, frictionless track. Energy still leaks (not perfectly elastic) but the qualitative effect is striking.

### Spring / oscillator (4)

#### `beats` — Oscillation
**Physics:** Two mass-spring oscillators with slightly different frequencies appear to slowly modulate each other's amplitude when started in phase. The envelope frequency is the difference frequency.
**Setup:** Two separate mass-spring systems side-by-side, with k values differing by ~5%. Both released with the same initial displacement.
**Motion:** Both bodies oscillate; their RELATIVE phase drifts. Watched together, the visual "beats" pattern is the slow envelope.
**Template:** `spring_mass.xml`. Replicate 2× with slightly different k.
**Hints:** Need to render long enough for the difference frequency to manifest — beat period = 2π/(ω₁-ω₂). If ω₁=2π, ω₂=2π·0.95, beat period = 2π/0.314 ≈ 20 s. Render 25 s or use larger Δk. Camera: front view showing both side by side.

#### `normal_modes_2mass` — Oscillation
**Physics:** Two masses with three springs (wall–m–m–wall) have two normal modes: symmetric (both move together) at lower frequency, antisymmetric (move oppositely) at higher frequency.
**Setup:** Two masses on a horizontal frictionless track, three springs in series. Initial conditions chosen to excite ONE mode only (e.g., symmetric: both same displacement; antisymmetric: equal but opposite).
**Motion:** Demonstrates pure mode: in symmetric mode the gap between masses stays constant; in antisymmetric mode the gap oscillates twice per cycle.
**Template:** `spring_mass.xml`.
**Hints:** Use tendons as visual springs + slide joints with stiffness for the dynamics. Render two versions (one for each mode) if desired, or just pick antisymmetric (more visually striking). Camera: side view.

#### `vertical_spring_mass` — Oscillation
**Physics:** Mass on a vertical spring oscillates about its STRETCHED equilibrium (where spring force = mg), not the unstretched length. Period is unchanged: T = 2π·sqrt(m/k).
**Setup:** Spring (tendon + stiffness) hanging from a ceiling point; mass attached at the bottom. Release from above the equilibrium (or below).
**Motion:** Mass oscillates vertically about the equilibrium height; equilibrium is BELOW the unstretched-spring height.
**Template:** `spring_mass.xml`.
**Hints:** k tuned so equilibrium stretch is visible (e.g., 5–10 cm). Mark the equilibrium with a thin horizontal line for clarity. Camera: side view.

#### `pendulum_with_lateral_spring` — Oscillation / coupling
**Physics:** A pendulum attached to a horizontal wall-spring shows mode coupling: pure swing and pure spring oscillation are eigenstates only when carefully tuned; otherwise energy sloshes between them.
**Setup:** Hinge-pivoted pendulum with a spring connecting its mass to a horizontal wall.
**Motion:** Initially energy goes into the pendulum swing; over time it transfers to the spring's vibration, then back.
**Template:** `pendulum.xml` + `spring_mass.xml`.
**Hints:** Tune string length and spring k so the periods are close — that gives the strongest beats-like transfer. Render 15 s.

### Constraint / mechanical advantage (3)

#### `block_and_tackle` — Mechanical advantage
**Physics:** A 2:1 pulley system halves the force needed to lift a mass (and doubles the distance). This is Atwood with an extra pulley.
**Setup:** Heavy mass on one end of a rope; rope goes over a fixed pulley, around a movable pulley attached to a lighter mass, and ends fixed to the ceiling.
**Motion:** Heavy mass descends slowly; the light load lifts up (also slowly) because the rope on the movable pulley side bears HALF the tension.
**Template:** `atwood.xml`. Add a second pulley + joint-equality coupling: q_heavy + 2·q_light = 0.
**Hints:** Polycoef "0 -0.5 0 0 0" enforces q_heavy = -0.5·q_light (i.e., 2:1 ratio). Mass ratio matters: heavy ≈ 1.0, light ≈ 0.45 to see clean lifting at moderate damping.

#### `mass_on_frictionless_incline` — Constraint
**Physics:** Block on a frictionless inclined plane has acceleration a = g·sin(θ) regardless of mass.
**Setup:** Inclined ramp + a block constrained to slide along its surface (slide joint along the ramp's surface direction).
**Motion:** Block accelerates down the ramp; with no friction, motion is pure linear acceleration along the slope.
**Template:** `incline_friction.xml`. Drop friction to 0.
**Hints:** Set ALL friction values to 0 (block AND ramp — gotcha #1!). Slide joint along the ramp surface gives clean physics without contact instability. Camera: side view. Render 2 s.

#### `incline_with_pulley` — Constraint / Atwood variant
**Physics:** Mass on an incline connected over a pulley to a hanging mass — system accelerates if hanging weight > sin(θ)·incline weight. Classic IPhO-style problem.
**Setup:** Inclined ramp + a block on it + a pulley at the top of the ramp + a string over the pulley + a hanging mass on the other side.
**Motion:** If hanging mass is heavy enough, it descends and pulls the incline block up the ramp; otherwise the reverse.
**Template:** `atwood.xml` + `incline_friction.xml`.
**Hints:** Use joint equality (Atwood-style) between the slide joint on incline and the slide joint of the hanging mass. Adjust masses so the dynamics are visible over 3–4 s. Damping in both joints.

### Friction (4)

#### `capstan_effect` — Friction / wrap
**Physics:** A rope wrapped around a fixed cylinder needs only a small holding force to resist a large pulling force; the ratio scales exponentially with wrap angle: F_pull/F_hold = e^(μθ).
**Setup:** Vertical post on the floor; rope wrapped 1.5 turns around it; one end has a heavy weight (10 kg); the other end has a light weight (0.5 kg, hanging just over the edge).
**Motion:** Despite the huge mass ratio, the rope holds — light weight doesn't get lifted because friction along the wrap absorbs the tension.
**Template:** `atwood.xml` (for tendons + hanging weights) + `dominoes.xml` (post setup).
**Hints:** Use a thin spatial tendon for the rope; friction interaction may be approximate. Could fake the effect with a 2:1 joint equality if direct wrap-friction is too hard. Render 5 s.

#### `stick_slip` — Friction
**Physics:** Block dragged by a spring shows alternating stick-and-slip: builds tension until static friction breaks, then slips forward, then sticks again. Generates characteristic sawtooth motion.
**Setup:** Block on floor with high static friction; attached by a spring to a slowly-moving driver. (Driver moves via init-qvel.)
**Motion:** Block sits still while spring stretches, then suddenly jumps forward; then sits still while spring stretches again; repeats.
**Template:** `incline_friction.xml` + `spring_mass.xml`.
**Hints:** μ_static must be > μ_kinetic — MuJoCo distinguishes these via `friction` and `solimp` settings. Driver needs a sustained low velocity, so give it big mass and high init-qvel so it barely slows over the render. Render 6 s.

#### `tipping_vs_sliding` — Friction / statics
**Physics:** A tall block on an inclined plane either tips over or slides, depending on the ratio of its height/width vs μ — the tipping angle is arctan(w/h), the sliding angle is arctan(μ).
**Setup:** Two side-by-side blocks on the same incline: one tall (high h/w), one short (low h/w). Same μ for both. Increase incline gradually.
**Motion:** As the incline tilts, the tall block tips first while the short one is still static; then the short block slides.
**Template:** `incline_friction.xml`. Two blocks with different aspect ratios.
**Hints:** Use a hinged or sliding incline (joint with init velocity to gradually tilt) or just set the incline at a critical angle showing both behaviors at once. Side view camera. Render 4 s.

#### `belt_friction` — Friction / coupled rotation
**Physics:** A belt connecting two pulleys couples their rotation — if pulley radii differ, the angular velocities differ inversely. With sufficient slip, the belt slides instead of driving.
**Setup:** Two pulleys (different radii) connected by a closed loop tendon "belt". One pulley is driven (initial spin); the other should follow.
**Motion:** Driven pulley spins; belt transfers motion; driven pulley spins at scaled velocity.
**Template:** `maxwell_wheel.xml` + `atwood.xml` (for tendon as belt).
**Hints:** Belt as a tendon-loop is approximate — true belt-pulley coupling needs friction simulation along the tendon, which MuJoCo doesn't do well. Workaround: use a joint equality coupling the two hinges directly (polycoef = -r₁/r₂). The tendon is purely visual. Render 4 s.

---

## 🟣 Tier 1 — Quick wins, brand new (~20 more)

### Kinematics / projectile (4)

#### `monkey_and_hunter` — Kinematics
**Physics:** Both projectiles fall the same Δh in the same time. A dart aimed at the monkey's initial position will hit it regardless of dart speed (within ballistic range), provided both are released at the same instant.
**Setup:** A "cannon" (small box) on the floor angled at ~30° toward a "monkey" ball suspended at height 0.8 m, 1 m away. The monkey is held by a "release point" that activates at t=0.
**Motion:** Cannon fires a small ball at angle; monkey simultaneously begins free-fall. They collide in mid-air regardless of initial dart velocity.
**Template:** `projectile_jenga.xml` (strip the tower).
**Hints:** Both are freejoint balls. The "monkey" has zero initial qvel; the dart has angled init-qvel pointing at monkey. Make 2-3 scenes' worth: vary dart speed, all still collide. Camera: x-z side view, fovy 38.

#### `projectile_max_range_45` — Kinematics
**Physics:** For projectiles launched at the same speed from ground level, the 45° angle maximizes range; angles equidistant from 45° (e.g. 30° and 60°) give equal but shorter ranges.
**Setup:** Three projectiles launched simultaneously at 30°, 45°, 60° from the same point, same initial speed.
**Motion:** All three follow parabolic arcs; the 45° lands furthest; the 30° and 60° land the same distance away but at different times.
**Template:** `projectile_jenga.xml`.
**Hints:** Three freejoint balls with carefully tuned init-qvel (each (v·cos θ, 0, v·sin θ)). Side view camera with wide fovy. Render 1.5 s.

#### `com_pair_track` — Momentum
**Physics:** Two masses on a frictionless track connected by a compressed spring — when released, they fly apart, but the center of mass stays still (momentum conservation).
**Setup:** Two cubes on a horizontal frictionless slider track, with a compressed (or stretched) spring between them. Spring releases at t=0.
**Motion:** The two masses fly apart in opposite directions; visibly, their midpoint never moves.
**Template:** `spring_mass.xml` + `elastic_collision.xml`.
**Hints:** Initialize the spring with stored energy (tendons may need init-qvel that gives them stored PE, or use a stiff hinge with init torsion). A pre-marked "COM" indicator (a thin vertical line at the midpoint) makes the demo visually obvious. Mass ratio 2:1 gives unequal velocities but same COM. Camera: side view.

#### `cannon_recoil` — Momentum
**Physics:** Cannon on wheels firing a projectile experiences recoil; final momenta sum to zero (cannon backward, ball forward).
**Setup:** Heavy cannon (box on wheels — slide joint horizontal) holding a smaller projectile. At t=0, the projectile is given a strong forward velocity; the cannon must accordingly receive backward momentum.
**Motion:** Projectile shoots forward; cannon visibly rolls backward.
**Template:** `marble.xml` (for cart on wheels) + `projectile_jenga.xml`.
**Hints:** Use a freejoint for both bodies but connect them with a "spring" or "rod" until t=0 (then somehow release). Simpler: just give both bodies opposite initial qvel, scaled by inverse mass. Render 2.5 s.

### Rotational / gyroscopic (5)

#### `bicycle_wheel_gyroscope` — Rotation / precession
**Physics:** A spinning wheel suspended by a string at one end of its axle precesses horizontally rather than falling — gyroscopic stabilization. Precession rate Ω = M·g·L / (I·ω) where L is distance from string to wheel center.
**Setup:** A heavy wheel: cylinder, R=0.10 m, thickness 0.015 m, M=0.5 kg. Mounted on a thin axle (length 0.18 m) sticking through its center. One axle end is connected by a 0.4 m vertical string (tendon) to the ceiling. Initial state: axle horizontal, wheel at world position (0.09, 0, 0.6), and `init-qvel` gives the wheel a spin of ω=60 rad/s about its axle axis.
**Motion:** Wheel doesn't fall; instead, its axle slowly rotates horizontally about the suspension point with Ω ≈ 2-3 rad/s. Render at least one half-revolution.
**Template:** `spinning_top.xml` (for spin physics) + `maxwell_wheel.xml` (for tendon as string).
**Hints:** Use a freejoint on the wheel body. Initial qvel: linear=(0,0,0), angular=(0,ω,0) — see gotcha #10 for world-frame angular qvel. Wheel inertia I_axle = ½MR² = 0.0025. Render 5 s. Camera: side view at the suspension point, pos (1.2, -0.5, 0.7), fovy 38.

#### `gyroscope_on_string` — Rotation
**Physics:** Same gyroscopic precession as the bicycle wheel demo, but with a thin disc (rather than wheel) emphasizing the rotor character. Different aspect ratio yields different I/I_perpendicular ratio.
**Setup:** Thin heavy disc: cylinder R=0.08 m, thickness 0.005 m, M=0.4 kg, on an axle (length 0.15 m). One axle end connected by a 0.4 m tendon to the ceiling. Disc starts at world (0.075, 0, 0.65), axle horizontal, spinning at ω=80 rad/s.
**Motion:** Disc precesses about the vertical through the suspension point.
**Template:** `bicycle_wheel_gyroscope` (copy after building that one first; this is its sibling).
**Hints:** Thinner disc + higher ω compared to bicycle_wheel scene. Precession rate Ω = Mg·L/(½MR²·ω). Render 5 s. Side view, pos (1.0, -0.4, 0.75), fovy 38.

#### `mass_through_hole` — Angular momentum
**Physics:** A mass on a string passing through a hole in a frictionless table is pulled inward; as the radius shrinks, the angular velocity grows (L = mvr conserved).
**Setup:** A puck on a frictionless table, attached to a string that passes through a central hole. Below the table, the string's lower end is given a downward velocity (or a hanging mass below pulling it).
**Motion:** Puck spirals inward while spinning faster and faster.
**Template:** `conical_pendulum.xml` + `atwood.xml`.
**Hints:** Tricky to set up — the string going through a hole needs to be modelled as a tendon with a fixed point in space (the hole). Alternative: use a slide joint to model the radius and a hinge joint for the angle. Camera: top-down or 3/4.

#### `reuleaux_triangle_rolling` — Rotation / geometry
**Physics:** A Reuleaux triangle (constant-width non-circular shape) rolls along a flat surface keeping the TOP face at a constant height — but the centroid of the shape bobs up and down by ~6.7% of the width as it rolls.
**Setup:** Reuleaux triangle of side L=0.10 m, thickness (z-extent) 0.05 m. Construct programmatically: for each of 3 vertices (at angles 0°, 120°, 240° on a circle of radius L/sqrt(3)), generate an arc of radius L centered on the OPPOSITE vertex. Approximate each arc with 8 small `<geom type="box">` segments. The triangle is given an initial linear velocity (vx=0.3 m/s) and matching rolling angular velocity (ω_y = vx / (centroid_height)).
**Motion:** Triangle rolls; the upper face holds a near-constant height (so a board on top wouldn't tilt). The centroid (and thus a marker glued to the centroid) bobs visibly up and down with 3× the rolling angular period.
**Template:** Programmatic gen (`gen_reuleaux.py`). Reuse rolling pattern from `marble.xml`.
**Hints:** ~24 box geoms total (3 arcs × 8). Friction tuned for rolling without slip: `friction="0.6 0.005 0.0001"`. Side view, camera pos (0, -1.5, 0.15), fovy 40. Render 4 s.

#### `coin_spiral` — Rotation / friction
**Physics:** A coin set on its edge and given a small wobble spins down in a spiral, transitioning from tall precession to flat rotation with characteristic increasing pitch. Energy lost to floor friction.
**Setup:** A thin cylinder ("coin") on the floor, given an initial vertical orientation with a small tilt and large initial spin about its vertical axis.
**Motion:** Coin spins on edge, gradually tilts more, and finally settles flat after a few seconds of accelerating-pitch oscillation.
**Template:** `spinning_top.xml`.
**Hints:** Use a freejoint with a carefully tuned initial state including a small tilt and large ω. Camera at 3/4 to capture the spiral motion. Render 6–8 s.

### Waves on strings (3)

#### `wave_reflection_fixed` — Waves
**Physics:** A pulse traveling along a string reflects off a fixed (clamped) end with an inverted polarity.
**Setup:** Long discretized horizontal string (chain of small bodies linked by spring-like hinges), one end pinned to a wall, other end free. Initial pulse generated by displacing the free end then releasing.
**Motion:** Pulse travels along the string toward the wall; upon hitting the wall, returns as an inverted pulse traveling back.
**Template:** `dominoes.xml` (chain) + `spring_mass.xml`.
**Hints:** Use ~40 nodes, hinge joints with stiffness, low damping. Initial qpos gives the pulse shape (e.g., one peak at the middle). Render 4 s. Side view.

#### `wave_reflection_free` — Waves
**Physics:** A pulse traveling along a string reflects off a free end with the same polarity (no inversion).
**Setup:** Same as above but with the second end completely free (no wall).
**Motion:** Pulse propagates → reflects from free end → returns SAME-SIDE.
**Template:** Same as `wave_reflection_fixed` but free-end boundary.
**Hints:** Discrete chain endpoint has a freejoint (no constraint). Render side-by-side with the fixed case for the educational contrast — but each is its own scene.

#### `wave_on_heavy_rope` — Waves
**Physics:** Wave speed in a vertical hanging rope varies with height: v(h) = sqrt(g·h). A pulse at the top moves faster than at the bottom (heavy lower portion has lower tension).
**Setup:** Vertical chain of small bodies hanging by gravity, top fixed, bottom free.
**Motion:** A pulse displaced at one end propagates downward and speeds up (or vice versa).
**Template:** `dominoes.xml` (chain) + `spring_mass.xml`.
**Hints:** Use ~30 nodes; gravity creates the tension gradient automatically. Initial qpos for the pulse. Render 3 s.

### Statics / structures (4)

#### `arch_compression` — Statics
**Physics:** A Roman arch supports a heavy load above by transferring the weight through compressive force along its curved spine. Remove the keystone and the arch collapses.
**Setup:** Roman semi-circular arch made of N wedge-shaped blocks; a heavy load on top. Compare with-keystone vs without-keystone.
**Motion:** With keystone in place, the arch holds the load indefinitely. Without (drop the keystone), the arch buckles inward.
**Template:** `block_overhang.xml`. Programmatic generator likely needed.
**Hints:** Use ~10-12 wedge-shaped blocks per arch. Block-block friction tuned moderately. Initial qpos placing each block precisely. Render 4 s. Side view.

#### `balance_beam_lever` — Statics / equilibrium
**Physics:** A lever in static equilibrium: F1·d1 = F2·d2 (torque balance about the fulcrum).
**Setup:** Horizontal rod pinned at center on a fulcrum. Two different weights hanging at different distances from the fulcrum, balanced.
**Motion:** Static initially. Add a small perturbation (a third mass briefly applied), then released — beam returns to equilibrium.
**Template:** `pendulum.xml`. The rod is essentially a pendulum but pinned at center.
**Hints:** The fulcrum is a hinge joint with no stiffness. Two weights attached as nested bodies at different x offsets. Render 3 s.

#### `pyramid_keystone_removal` — Statics
**Physics:** A pyramid of blocks held together by gravity and friction; remove a load-bearing block and the structure collapses.
**Setup:** ~10 blocks stacked in a pyramidal arrangement (4 on bottom, 3 on next, etc.). At some moment, one block is removed (via temporary support that disappears).
**Motion:** Pyramid initially static; after key block removal, it collapses progressively.
**Template:** `block_overhang.xml`.
**Hints:** Initially over-constrain so the stack is stable (high friction, soft contacts). To "remove" a block, just don't render it or use a slide joint with init-qvel to slide it out. Render 3 s.

#### `ladder_slipping_off_wall` — Friction / statics
**Physics:** A ladder leans against a wall, supported by friction at the floor and the wall. If μ is too low, the ladder slips outward (foot slides, top slides down).
**Setup:** A long thin rod leaning at ~60° against a vertical wall. Friction values at the floor and wall contact tuned.
**Motion:** With high μ: static. With low μ: ladder slips outward.
**Template:** `incline_friction.xml`.
**Hints:** Use a freejoint for the ladder body. Floor and wall geoms. Tune friction so the demo is at the edge of stability. Render 3–4 s.

### Mechanisms (3)

#### `slider_crank_mechanism` — Mechanism
**Physics:** Converts rotational motion to linear (reciprocating) motion via a crank arm and connecting rod. Used in every IC engine.
**Setup:** A spinning crank (hinge joint with init-qvel); connecting rod attached at one end of the crank; piston (slide joint) attached at the other end of the rod.
**Motion:** Crank spins continuously → piston reciprocates back and forth.
**Template:** `maxwell_wheel.xml`. Custom rod via hinge joints.
**Hints:** Initial qvel on the crank hinge to make it spin; geometric constraints (the rod's length) drive the piston. Render 3 s, several cycles. Side view.

#### `geneva_drive` — Mechanism
**Physics:** Converts continuous rotation into intermittent indexed rotation — a driver wheel with a single pin engages a slotted driven wheel, causing the driven wheel to step by 360°/N per pin engagement.
**Setup:** Driving wheel: cylinder R=0.08 m, thickness 0.02 m, with a small box pin of half-extent (0.005, 0.005, 0.015) at offset 0.04 m from center. Driven wheel: cylinder R=0.10 m, thickness 0.02 m, with 4 radial slots cut at 90° spacing. Each slot is a 0.012 m wide × 0.04 m deep rectangular channel approximated by box geoms forming the slot walls. The two wheel centers are 0.13 m apart on the same y-line so the pin clears the driven wheel's body but enters the slots. Driver gets init-qvel ω=2 rad/s on its hinge.
**Motion:** Driver rotates continuously; driven wheel sits still for ~270° of driver rotation, then jumps forward by 90° in ~90° of driver rotation, then sits still again. Render shows 2-3 indexing steps.
**Template:** Programmatic gen `gen_geneva_drive.py`. Closest existing: `dominoes.xml` (for chain reaction style).
**Hints:** Slot width must be slightly larger than pin width (1.5x for clean engagement). Damping on driven wheel hinge (0.05) to prevent oscillation. Friction off between pin and slot walls. Render 5 s. Top-down camera, pos (0.06, 0, 0.7), looking straight down, xyaxes="1 0 0  0 1 0".

#### `domino_branching` — Chain reaction
**Physics:** A multi-branch domino chain where one tip can trigger multiple branches simultaneously.
**Setup:** A Y-shaped or fractal layout of dominoes. The first domino is pushed.
**Motion:** Wave propagates from the start, branches at the Y, then both branches cascade simultaneously.
**Template:** `dominoes.xml`. Use a custom programmatic generator.
**Hints:** Spacing and angle at the branch point matters — too far apart and the trigger doesn't reach both. Render 5 s. Camera angled to see both branches.

### Multi-body, exotica (4)

#### `hanging_slinky_drop` — Oscillation / dispersion
**Physics:** A slinky hanging from one end has a tension gradient (tight at top, slack at bottom). When released, the top falls but the bottom STAYS in place for about 0.3 s due to wave propagation along the spring — counter-intuitive.
**Setup:** Long discretized slinky (chain of bodies with stiff springs between them) hanging from one end. Release the support at t=0.
**Motion:** Top of slinky falls immediately; bottom remains stationary for several frames; then everything falls together.
**Template:** `dominoes.xml` + `spring_mass.xml`.
**Hints:** Many small bodies (~20+), spring-joints with high stiffness. Initial qpos = gravity-equilibrium positions (heavy upward bias). Render 1.5 s. Side view, fovy small.

#### `anharmonic_pendulum_large_swing` — Oscillation
**Physics:** A pendulum with very large amplitude (~150°) shows period dependence on amplitude — the small-angle approximation breaks. Period at 90° is ~1.18× longer than at 5°.
**Setup:** Single pendulum, init-qpos = 150° (almost vertical-up).
**Motion:** Pendulum oscillates with very large amplitude; period visibly longer than what small-angle predicts.
**Template:** `pendulum.xml`. Just init-qpos = large angle.
**Hints:** Reference: place a second small-amplitude pendulum (5°) side-by-side for visual contrast — but that may be parameter variation in disguise; alternatively, just render one with a long duration to show the period.

#### `centrifugal_governor` — Rotation / equilibrium
**Physics:** Watt's flyball governor: two heavy balls on arms rotate about a vertical axis; at higher RPM, centrifugal effects lift them outward, which (in a real engine) would close a steam valve. Here we just show the equilibrium angle.
**Setup:** Two heavy balls on arms attached to a central spindle by hinge joints (so they can swing outward). Spindle spins about its vertical axis with initial qvel.
**Motion:** Balls swing outward as the system spins; at steady ω, they reach an equilibrium angle determined by ω.
**Template:** `conical_pendulum.xml` (two of them, mirrored).
**Hints:** Damping on the swing hinges so the balls settle. Camera: 3/4 front. Render 4 s.

#### `n_body_1d_collisions` — Multi-body
**Physics:** A line of N balls with elastic collisions and a small initial perturbation evolves to interesting patterns. Edge cases (light vs heavy ratios) show momentum transfer phenomena.
**Setup:** 6–8 balls on a frictionless track, just barely separated. Strike one end with a fast-moving ball.
**Motion:** Series of elastic collisions propagating; with equal masses, the leftmost ball stops and the rightmost moves off. With varying masses, complex transfer patterns.
**Template:** `elastic_collision.xml` + `newton_cradle.xml`.
**Hints:** Stiff contacts, small timestep. Use freejoints on frictionless track. Camera: side view, wide enough for all N balls.

---

## 🟠 Tier 2 — New patterns (3–5 hr each)

### Free rigid body / inertia tensor (4)

#### `tippe_top` — Free rigid body
**Physics:** An asymmetric "top" (rounded bottom + protruding stem) spun fast inverts itself: the stem (initially at the top) ends up touching the floor while the body spins on it. Driven by the contact friction torque combined with the asymmetric inertia tensor.
**Setup:** Two-part body via a single freejoint:
- Lower hemisphere: capsule from (0,0,0) to (0,0,0.04), radius 0.04 m, M=0.06 kg (heavy half-sphere bottom).
- Upper stem: thin capsule from (0,0,0.04) to (0,0,0.08), radius 0.005 m, M=0.002 kg.
Initial position: center of mass at z = 0.035 (hemisphere bottom near floor). Initial qvel = (0,0,0, 0,0, 80) — 80 rad/s about world +z. Floor contact uses `friction="0.4 0.005 0.01"` (high sliding friction, moderate torsional to drive the flip).
**Motion:** First 1-2 s: top spins upright. Then it gradually tilts; eventually inverts and ends up balancing on the stem. Total time to flip: ~4-5 s.
**Template:** `spinning_top.xml` for the rotation setup + `bowling.xml` for floor friction.
**Hints:** This is HARD to tune. Margins: see gotcha #11 for the floor-friction subtlety. Mass distribution between hemisphere and stem is critical — hemisphere too light → no flip; too heavy → never tilts. Render 6 s, may need 5-8 iterations to dial in. Camera: 3/4 low-angle, pos (0.3, -0.3, 0.1), fovy 36.

#### `dzhanibekov_effect` — Free rigid body / intermediate axis
**Physics:** A free rigid body with three distinct principal moments of inertia, spun about its intermediate axis, periodically flips by 180°. The other two axes are stable; only the intermediate is unstable.
**Setup:** A T-handle or similar asymmetric body in zero gravity, with init-qvel about the intermediate principal axis (with a small perturbation to make the instability manifest).
**Motion:** Body spins about one axis for ~1 s, then suddenly flips by 180°, then spins for another ~1 s, then flips again. Periodic.
**Template:** `spinning_top.xml`. Set `gravity="0 0 0"`.
**Hints:** Use `<option gravity="0 0 0"/>`. Freejoint body. Mass distribution: T-handle (long arm + short cross-piece). Initial qvel slightly off the intermediate axis to seed the instability. Render 4–5 s.

#### `rattleback` — Free rigid body / chirality
**Physics:** A "rattleback" (Celt stone) — boat-shaped, with the long axis of its inertia ellipsoid slightly offset from the long axis of its underside curvature — prefers one spin direction; spun the wrong way it rattles vertically and reverses direction.
**Setup:** Approximate the rattleback with an ellipsoid body. Use a freejoint at world (0, 0, 0.015). Inertia tensor must be asymmetric AND its principal axes must be rotated ~5° relative to the geometric long axis (this is what creates the chirality). Achieve this by setting `<inertial pos="0 0 0" mass="0.05" fullinertia="Ixx Iyy Izz Ixy Ixz Iyz"/>` with non-zero Ixy. Concretely: Ixx=2e-5, Iyy=8e-5, Izz=8.5e-5, Ixy=1.5e-5, Ixz=Iyz=0. Geom: ellipsoid via `<geom type="ellipsoid" size="0.06 0.025 0.015"/>` (long axis x, narrow y, flat z). Floor friction `friction="0.4 0.005 0.001"`. Initial qvel: angular about +z, ω=8 rad/s ("right" direction → just spins) OR ω=-8 ("wrong" direction → rattles + reverses).
**Motion:** Wrong-direction spin: rocks up-and-down (visible bobbing of the long axis), spin slows to a stop, then reverses to the preferred direction.
**Template:** `spinning_top.xml` (rotation handling).
**Hints:** Ellipsoid geom is convex in MuJoCo (works). The skewed-inertia trick (off-diagonal Ixy) is the entire physics. Render 6-8 s for the full reversal. Side view, pos (0, -0.5, 0.08), fovy 38.

#### `tumbling_book` — Free rigid body / intermediate axis
**Physics:** Same physics as Dzhanibekov, demonstrated with a book/rectangular slab. Spinning about the medium-length axis is unstable.
**Setup:** Rectangular slab in zero gravity, init-qvel about its intermediate axis (with small perturbation).
**Motion:** Spins ~1 s about intermediate axis, then suddenly flips, then again.
**Template:** Same as `dzhanibekov_effect` but with a rectangular slab geom.
**Hints:** Different shape but same physics. Render 5 s.

### Chains and ropes (4)

#### `falling_chain_classical` — Chain dynamics
**Physics:** A chain falling off the edge of a table accelerates faster than g once moving — falling links pull the still-on-table links into motion.
**Setup:** A chain (~30 discretized bodies linked by short hinges) initially resting on a table with half hanging off the edge.
**Motion:** Hanging portion descends, pulling the on-table portion off — chain accelerates progressively until fully airborne.
**Template:** `dominoes.xml` (chain layout).
**Hints:** Friction on the table tuned so the resting portion doesn't slide too easily. Render 2–3 s. Side view.

#### `sliding_chain_off_table` — Chain dynamics
**Physics:** A chain half on a frictionless table, half hanging — the hanging weight pulls the table portion off; in the limit of no friction, motion is purely gravity-driven.
**Setup:** Same as `falling_chain_classical` but with zero friction on the table.
**Motion:** Hanging portion descends; table portion slides off rapidly.
**Template:** `dominoes.xml`. Adjust friction.
**Hints:** Same caveats but with friction off. Render 1.5 s.

#### `hanging_chain_catenary` — Statics / chain
**Physics:** A chain hanging from two pinned endpoints at the same height settles into a CATENARY (cosh) curve, not a parabola — though they look similar for shallow sags.
**Setup:** 40 chain links, each a small capsule (length 0.04 m, radius 0.005 m, M=0.01 kg per link). Links connected by hinge joints with axis y (sag in x-z plane), damping=0.05. Endpoints (link 0 and link 39) are attached to fixed posts via weld constraints at world (-0.5, 0, 1.0) and (+0.5, 0, 1.0). Initial qpos: all hinges = 0 (chain starts as a straight horizontal line stretching between the posts; gravity pulls it down to settle).
**Motion:** Chain dynamically settles under gravity into the catenary shape over ~2-3 s, then stays stable.
**Template:** Programmatic gen (`gen_hanging_catenary.py`). Reuse pattern from `gen_dominoes.py` for chain layout.
**Hints:** Endpoint weld constraints can be done by making link 0 and 39 child bodies of the world post (no joint). Friction off. Render 5 s — first 2 s settle, last 3 s show the catenary shape. Side view, pos (0, -1.8, 0.85), fovy 40.

#### `swinging_chain_pendulum` — Chain dynamics
**Physics:** A chain hanging from one fixed end behaves like a continuous pendulum but with internal flexibility — modes are non-trivial; it whips.
**Setup:** Chain fixed at one end, pulled to ~30° tilt, released.
**Motion:** Swings like a pendulum but with the lower end whipping noticeably.
**Template:** `dominoes.xml`. Adjust pivot.
**Hints:** ~25 links, low damping. Render 5 s.

### Bead on wire / constrained particle (4)

#### `bead_on_helix` — Constraint
**Physics:** A bead on a frictionless helical wire descends with combined translation+rotation; ratio of vertical drop to spiral length determines acceleration: a = g·sin(α) where α is the helix pitch angle.
**Setup:** Helix axis vertical (along +z). Generator parameters: radius R=0.06 m, pitch p=0.04 m per turn, 5 turns (total height 0.20 m). Approximate the helix with ~80 short tubular box-segments: at each parameter t ∈ [0, 5·2π], position is `(R·cos(t), R·sin(t), -p·t/(2π))`, segment is a thin box oriented along the local tangent. Bead: sphere R=0.012 m, freejoint, placed just above the top of the helix at world (R, 0, 0.01).
**Motion:** Bead falls onto the helix, slides down spiraling, exits at the bottom after ~3-4 s.
**Template:** Programmatic gen `gen_bead_on_helix.py`. Reuse curve-generation pattern from `gen_brachistochrone.py`.
**Hints:** Make the helix wire from boxes that form a thin "channel" (two parallel walls) so the bead is trapped. Friction off on both bead and helix. Bead radius 0.012 should be much smaller than helix radius 0.06 to fit. Render 4 s. 3/4 view from front-above, pos (0.3, -0.3, 0.15), fovy 38.

#### `bead_on_cycloid_track_isochrony` — Constraint
**Physics:** A bead on a cycloid track has the same period regardless of release point — the cycloid is the tautochrone.
**Setup:** A cycloid-shaped track (programmatic generation from cycloid equation); a bead placed at different starting positions reaches the bottom in the same time.
**Motion:** Three beads released from different positions on the cycloid; they all reach the bottom (or center) simultaneously.
**Template:** `brachistochrone.xml`. Reuse cycloid generator.
**Hints:** Multiple beads released from different heights but on the same track. Render 1.5 s (cycloid is fast). Side view.

#### `bead_on_parabolic_wire` — Constraint
**Physics:** A bead on a parabolic wire (z = x²) has period dependent on amplitude — contrast with cycloid's amplitude-independent period.
**Setup:** A parabolic wire (programmatic), one bead.
**Motion:** Bead oscillates back and forth; period varies with amplitude.
**Template:** `brachistochrone.xml`. Use parabolic curve instead of cycloid.
**Hints:** Render 4 s.

#### `bead_in_rotating_ring` — Constraint
**Physics:** A bead inside a ring that's spinning about its diameter — bead sits at an angle determined by ω, the centrifugal "potential" creating a non-trivial equilibrium.
**Setup:** A ring on a horizontal axis spinning about its diameter; a bead inside it (constrained to the ring's circular path).
**Motion:** Bead settles at an equilibrium angle on the inside of the ring. Higher ω → more horizontal position.
**Template:** `conical_pendulum.xml` + `marble.xml`.
**Hints:** Ring spins via init-qvel on its hinge. Bead's motion is constrained to the ring (geometric setup). Render 4 s. Side view.

### Curves and bowls (3)

#### `ball_in_spherical_bowl` — Oscillation
**Physics:** A ball in a spherical bowl oscillates with period independent of amplitude for small amplitudes (like a pendulum on short string).
**Setup:** A spherical bowl (a hemisphere) with a ball inside, released from one side.
**Motion:** Ball rolls back and forth in the bowl.
**Template:** `loop_the_loop.xml` (closed curved surface).
**Hints:** Build the bowl as a triangle-mesh hemisphere or as many curved segments. Or use a partial spherical capsule. Camera: 3/4 front. Render 4 s.

#### `cycloidal_pendulum_huygens` — Constraint / tautochrone
**Physics:** A pendulum's string wrapping around two cycloid-shaped "cheeks" forces the bob to trace a cycloid path. The resulting motion is exactly isochronous: period is independent of amplitude (unlike a normal pendulum).
**Setup:** Pivot at world (0, 0, 1.0). Two cycloid arcs (the "cheeks") flank the pivot, one on each side. Each cheek is the EVOLUTE of the path-cycloid (per Huygens). Use the parametric form `x = ±R·(θ - sin θ), z = 1.0 - R·(1 - cos θ)` for θ ∈ [0, π/2]; with R=0.20 m. Approximate each cheek with 12 short box-segments. The pendulum: massless string (tendon) of length π·R from the pivot to a bob (sphere R=0.015 m, M=0.05 kg). As the bob swings, the string wraps around the cheeks, effectively shortening — this forces the bob's path to be a cycloid.
**Motion:** Bob swings back and forth tracing a cycloid arc (visibly different from a circular pendulum arc). Period ≈ 4π·sqrt(R/g) ≈ 0.9 s, INDEPENDENT of swing amplitude.
**Template:** `pendulum.xml` (pivot + bob) + `gen_brachistochrone.py` (cycloid generator).
**Hints:** Use a tendon for the string — tendons wrap around obstacles naturally. The cheeks need contact with the tendon. Programmatic generator. Render 4 s (~4 cycles). Side view, pos (0, -1.6, 0.8), fovy 40.

#### `ball_on_saddle` — Constraint / instability
**Physics:** A saddle point (z = x² - y²) is stable in one direction, unstable in the other. A ball placed at the saddle rolls off in the unstable direction.
**Setup:** Saddle-shaped surface (z = a·x² - b·y²) with a ball placed exactly at the center.
**Motion:** Ball is stationary briefly, then with a tiny perturbation rolls off in the unstable y-direction while remaining centered in x.
**Template:** `loop_the_loop.xml` (curved geometry).
**Hints:** Approximate the saddle with many small geoms. Slight initial offset in y to seed the instability. Side view.

### Angular momentum / energy (2)

#### `skater_pulling_arms_in` — Angular momentum
**Physics:** Conservation of angular momentum — a rotating body retracting mass closer to the axis spins faster (I·ω = const).
**Setup:** A central spinning hub (vertical axis) with two arms extending horizontally. Masses are attached to the arms via slide joints; initially extended. At some point the masses are retracted (via init qpos + spring-loaded sliders) — system spins faster.
**Motion:** System spins at ω₁; arms retract; system now spins at ω₂ > ω₁.
**Template:** `conical_pendulum.xml`.
**Hints:** Tricky to model "retracting" without an actuator. Easiest: start with arms in the extended position, use slide joints with stiffness pulling them toward retracted equilibrium; release and watch them retract under their own spring tension. The conservation effect manifests automatically. Render 4 s.

#### `cradle_drop_demo` — Energy / momentum
**Physics:** A small object placed on a pendulum bob is propelled upward when the bob reaches the bottom of its swing — energy transfer demonstration.
**Setup:** A pendulum with a small block balanced on top of its bob. Release the pendulum from height.
**Motion:** Bob swings down; at the bottom of the swing, momentum transfer flicks the small block upward.
**Template:** `pendulum.xml`.
**Hints:** Carefully tuned mass ratio (~10:1 bob:block). Render 3 s.

### Resonance and waves (3)

#### `standing_wave_on_string` — Waves
**Physics:** Wave on a fixed-end string forms standing waves at resonance frequencies. The nodes and antinodes are visible.
**Setup:** Long discretized string with one end fixed. The other end is given a small periodic motion via init-qpos (a sinusoidal initial condition matching the lowest mode).
**Motion:** String oscillates with the visible standing-wave pattern.
**Template:** `dominoes.xml` (chain) + `spring_mass.xml`.
**Hints:** Initial qpos = sin(πx/L) gives the fundamental. Run for several periods. Render 3 s. Without actuator, only the freely-oscillating modes are visible.

#### `wave_on_chain_pulse` — Waves
**Physics:** A pulse propagates along a 1D chain of masses connected by springs. Speed depends on tension and mass density.
**Setup:** Long chain of bodies on a frictionless surface, connected by stiff hinge-springs. Initial pulse at one end (displaced upward).
**Motion:** Pulse propagates along the chain.
**Template:** `dominoes.xml` + `spring_mass.xml`.
**Hints:** Initial qpos has one peak at the start. Render 3 s.

#### `mexican_hat_drum_modes` — Waves / modes
**Physics:** A 2D mass-spring lattice (drum head analog) has discrete vibration modes — the (1,1) "Mexican hat", the (2,1), (1,2), etc. Each mode oscillates at its eigenfrequency. Here we excite the (1,1) fundamental.
**Setup:** 10×10 grid of small bodies on a square 0.20×0.20 m. Each body: sphere R=0.005 m, M=0.005 kg. Body (i,j) at world (-0.10 + i·0.022, -0.10 + j·0.022, 0.20). Each body connected to its 4 nearest neighbors via hinge-joint spring approximation. Use slide joints in z (only out-of-plane vertical motion) with `<equality>` constraints between adjacent bodies acting as springs: `<equality><joint joint1="zij" joint2="z(i+1)j" polycoef="..."/></equality>` — actually for simplicity, just use linked bodies with hinges or tendons. Edges (i=0, i=9, j=0, j=9) are fixed (no slide joint, attached to the world).
**Motion:** Initial qpos sets all bodies to `z_offset = A · sin(π·i/9) · sin(π·j/9)` with A=0.02 — the (1,1) mode shape (one big up-bump in the middle). System oscillates in pure (1,1) mode.
**Template:** Programmatic gen `gen_drum_modes.py`. Reuse from `gen_pendulum_waves.py`.
**Hints:** 10×10 = 100 bodies, manageable. Use slide joints (1 DOF each) with stiffness, not freejoints. Stiffness tuned so visible oscillation period ≈ 1 s. Render 3 s. Top-down 3/4 camera (pos 0.2, -0.2, 0.4) showing the wave shape.

### Structures (4)

#### `cantilever_load_curve` — Structures
**Physics:** A cantilever beam under a tip load deflects in proportion to the load (Hooke's law for the beam): δ = FL³/(3EI). Heavier load = more deflection.
**Setup:** A horizontal beam clamped at one end (like beam_buckling but horizontal). A movable load at the free end progressively gets heavier.
**Motion:** Static or quasi-static: at low load, beam barely deflects; at high load, beam visibly bends.
**Template:** `beam_buckling.xml`. Re-use the discretized beam.
**Hints:** Beam horizontal, one end pinned to a wall. Mass at tip varies (could just render 3 separate scenes or one with progressive mass via tendons). Render 2 s.

#### `truss_collapse` — Structures
**Physics:** A 2D truss is statically determinate; removing one member shifts the load through alternate paths or, if the truss becomes a mechanism, collapses entirely.
**Setup:** Triangulated 2D truss (Pratt or Warren style, ~5-7 members) holding a load. One member is "removed" (or always missing) — truss collapses.
**Motion:** Truss with all members: holds load. Without: collapses.
**Template:** `dominoes.xml` + `block_overhang.xml`.
**Hints:** Members as rigid rods connected by hinges. Programmatic generator. Render 3 s.

#### `inverted_pendulum_tower` — Stability
**Physics:** A tower of inverted pendulums (each hinged on the one below) is unstable — any small perturbation grows.
**Setup:** Stack of N inverted pendulums (link-on-link, each a hinge with stiffness but high amplitude). Small initial tilt.
**Motion:** Tower wobbles initially, then collapses in some direction.
**Template:** `beam_buckling.xml`.
**Hints:** Set hinge stiffness so it's below the buckling-stability threshold. Render 3–4 s.

#### `crane_lifting_simple` — Structures / mechanism
**Physics:** A simple crane (arm + cable + load) demonstrates torque on the base; tipping happens if load·arm-extension > base-weight·base-half-width.
**Setup:** A pivoting vertical pole with a horizontal arm extending out; a cable hanging from the arm tip; a load on the cable.
**Motion:** Without enough base mass, the crane tips forward when the load is hung. With enough, it stays.
**Template:** Custom; use `block_overhang.xml` ideas.
**Hints:** Visualize the load's weight and the crane's stability margin. Render 3 s.

---

## 🟢 Tier 1 — Final additions (10 more, brainstormed in round 2)

### Equilibrium / instability (4)

#### `cone_balanced_on_tip` — Statics / instability
**Physics:** A cone balanced perfectly on its apex is in unstable equilibrium; any infinitesimal perturbation causes it to fall.
**Setup:** Cone shape (build from cylinder + capsule cap or use a cone-shaped geom). Cone height 0.20 m, base radius 0.06 m. M=0.10 kg. Place upside-down with apex on floor at world (0, 0, 0.20). Initial qpos: tiny tilt (~0.5° about y-axis, i.e. quaternion (1, 0, 0.004, 0)). Floor friction `friction="0.8 0.01 0.001"`.
**Motion:** Cone holds steady for ~0.3 s, then starts tilting visibly, falls completely by 1.5-2 s.
**Template:** `spinning_top.xml` (free body + floor) + `dominoes.xml` (tilt seed).
**Hints:** This is just unstable equilibrium — gravity does the rest. Camera: side view, pos (0, -0.6, 0.15), fovy 38. Render 2.5 s.

#### `symmetry_breaking_ball_on_dome` — Statics / instability
**Physics:** A ball at the very top of a smooth dome is in unstable equilibrium; tiny perturbations make it slide off, eventually flying through air.
**Setup:** A semi-spherical dome of radius R=0.20 m, half-sphere shape built from many small triangular boxes or a single half-ellipsoid geom positioned at world (0, 0, 0.20). Ball: sphere R=0.015 m, M=0.05 kg, placed on top at (0, 0, 0.215). Initial qpos: tiny horizontal offset (Δx=0.001). Friction zero.
**Motion:** Ball stays nearly still for ~0.5 s, then slides off the dome accelerating to the side, then flies through the air after losing dome contact.
**Template:** `loop_the_loop.xml` (for curved surface).
**Hints:** Dome can be approximated by half of a high-poly sphere or by stacked rings. Render 2 s. Camera: side view, pos (0.5, -0.5, 0.15), fovy 40.

#### `marble_in_funnel` — Gravity / circular motion
**Physics:** A marble released inside a funnel (cone with vertical axis) spirals down, accelerating as the radius decreases — angular momentum NOT conserved (gravity does work) but visually striking.
**Setup:** Funnel: inverted cone shape, top radius 0.15 m, bottom hole radius 0.01 m, height 0.20 m. Built programmatically from ~24 box segments forming the conical wall. Marble: sphere R=0.008 m, M=0.005 kg, placed at the top edge (R=0.14, z=0.20) with initial tangential velocity vt=0.5 m/s.
**Motion:** Marble spirals down the funnel wall, speeding up as the radius decreases; exits the bottom or oscillates at the throat.
**Template:** Programmatic gen (`gen_funnel.py`). Reuse pattern from `gen_rotating_fluid.py` for ring-of-walls.
**Hints:** Marble friction tuned for low slip on the funnel wall (`friction="0.05 0.005 0.001"`). Camera 3/4 from above, pos (0.25, -0.25, 0.30), fovy 38. Render 4 s.

#### `falling_chimney` — Rotational / rigid body
**Physics:** A tall vertical rod pinned at the base falls over by rotating about the base. The TIP accelerates faster than g during part of the fall — counter-intuitive demonstration of how internal stresses redistribute (real chimneys often break mid-fall because of this).
**Setup:** Single rigid rod: a thin box of length 1.0 m, half-extents (0.025, 0.025, 0.5), M=2 kg. Bottom end pinned at world (0, 0, 0) via a hinge joint with axis y, no stiffness. Initial qpos: 2° tilt about y to seed the fall. No damping.
**Motion:** Rod falls over rotating about its base. Tip's vertical velocity exceeds free-fall during the second half of the trajectory (~30° to 60° from vertical).
**Template:** `pendulum.xml` (single rod on hinge).
**Hints:** Compare the tip's z-velocity to g·t to verify the >g effect. Render 1.5 s. Side view, pos (1.5, -1.0, 0.5), fovy 40.

### Coupling & action-reaction (3)

#### `block_on_accelerating_wedge` — Action-reaction
**Physics:** A block on a frictionless wedge that can itself slide on a frictionless floor — when released, both bodies accelerate. The wedge slides one way as the block slides down it; momentum in x conserved.
**Setup:** Wedge: triangular prism, 30° incline, base 0.40 m × 0.10 m, height 0.20 m at the high end. M_wedge=1.0 kg. Wedge sits on a slide joint along world x. Block: cube 0.05 m, M_block=0.3 kg, sits on the slope of the wedge, constrained to slide on it via slide joint along the slope direction.
**Motion:** Block accelerates down the slope; wedge accelerates in the opposite direction. The combined center of mass stays fixed in x.
**Template:** `incline_friction.xml` (block-on-wedge) + add a slide joint for the wedge.
**Hints:** Set ALL friction to 0 (gotcha #1). Render 1.5 s. Add a vertical marker line at the initial x of the combined COM to make conservation visually obvious. Side view, fovy 38.

#### `two_pendulums_collide` — Collision + oscillation
**Physics:** Two pendulums released from opposite sides meet at the bottom and collide elastically; momentum transfer depends on mass ratio.
**Setup:** Two single pendulums side-by-side (small lateral offset so they meet at the bottom). Left: length 0.40 m, mass 0.10 kg, released from 30° (positive angle). Right: length 0.40 m, mass 0.10 kg, released from -30° (negative angle), with a tiny y-offset (0.001) so geoms don't tangle.
**Motion:** Both pendulums swing toward each other; collide at the bottom with equal-mass elastic collision (essentially swap velocities); each bounces back to near-original height.
**Template:** `pendulum.xml` (duplicate) + `elastic_collision.xml` (stiff contact tuning).
**Hints:** Use stiff contact (`solref="-150000 -15"` `solimp="0.99 0.999 0.001"`) for clean elastic transfer (gotcha #4). Render 3 s (two full swings). Side view.

#### `pulley_with_inertia` — Constraint / rotational
**Physics:** Atwood machine where the pulley has significant moment of inertia — the pulley's I REDUCES the acceleration: a = (m1-m2)·g / (m1 + m2 + I/r²). Pulley I shows up as effective mass.
**Setup:** Same as Atwood but the pulley is a heavy disc (R=0.10 m, thickness 0.02 m, M=0.5 kg) — NOT massless. Pulley rotates via a hinge joint with no damping. The rope is two tendons (one each side) attached to the pulley via sites at radius R; the rope coupling to the pulley rotation enforces no-slip via joint-equality (combination of slide joints + hinge equality).
**Motion:** Heavier mass descends, lighter ascends — but more slowly than ideal Atwood predicts because of the pulley's I.
**Template:** `atwood.xml` (Atwood structure) + `maxwell_wheel.xml` (rolling-without-slip equality).
**Hints:** Connection: two equalities, one per side, each coupling rope-slide to pulley-hinge. Or simpler: ONE equality between (heavy_slide - light_slide) and (pulley_hinge · R). Mass ratio: 0.6 / 0.4 kg gives clean visible acceleration. Render 3 s. Side view.

### Friction & contact (3)

#### `block_on_block_static_friction` — Friction
**Physics:** Two stacked blocks on a frictionless floor; pull the bottom block. If μ_static between blocks is high enough, the top block moves WITH the bottom (no slip). If μ exceeded, top stays while bottom slides out.
**Setup:** Bottom block: 0.20 × 0.10 × 0.05 m, M=1 kg, sitting on a frictionless floor, with slide joint along x. Top block: 0.10 × 0.10 × 0.05 m, M=0.2 kg, placed centered on top, also with a slide joint along x. Inter-block contact has μ_static = 0.4. Apply a horizontal initial velocity to the bottom block (vx=1.0 m/s, large enough to slip).
**Motion:** Bottom block slides; top block stays nearly still for a moment, then accelerates due to friction; eventually they share velocity (or stay apart depending on initial velocity).
**Template:** `incline_friction.xml` (stacked geoms) + `elastic_collision.xml` (sliders).
**Hints:** Set floor friction to 0 (gotcha #1). Top block's slide joint allows it to be left behind. Render 2 s. Side view, pos (0, -1.0, 0.15), fovy 40.

#### `vertical_loop_insufficient_speed` — Energy / centripetal
**Physics:** A ball on a vertical loop track needs minimum speed `v_min = sqrt(g·R)` at the top to maintain contact. With less, it falls off the track partway up.
**Setup:** Closed vertical loop track (radius 0.20 m) — same geometry as `loop_the_loop.xml`. Ball: sphere R=0.025 m, M=0.05 kg. Initial position at the bottom of the loop; initial qvel = small (vx=1.5 m/s — too slow to make it around).
**Motion:** Ball ascends the loop on the inside surface; somewhere past 90° (when gravity component exceeds centripetal requirement), the ball loses contact with the track and falls inward.
**Template:** `loop_the_loop.xml`. Reduce initial speed.
**Hints:** Compare to `loop_the_loop` which uses enough speed. Render 1.5 s. Same camera as loop_the_loop.

#### `spherical_pendulum_2d` — Oscillation
**Physics:** A pendulum with 2D bob motion (instead of constrained to a plane) traces complex Lissajous-like patterns. Period not necessarily commensurate, so trajectory can be quasi-periodic.
**Setup:** Single bob hung from a pivot at world (0, 0, 1.2) via a 2-DOF gimbal: outer hinge axis y (pitch), inner hinge axis x (roll) — see gotcha #8 for why this is better than a ball joint. Bob: sphere R=0.025 m, M=0.10 kg, at the end of a 0.6 m rod from pivot. Initial qpos: pitch=0.5 rad, roll=0; init-qvel: roll_rate=0.8 rad/s.
**Motion:** Bob traces a rosette pattern in the xy plane (as projected) — not a circle, not a flat line.
**Template:** `conical_pendulum.xml` (gimbal pattern).
**Hints:** Use a long render (10 s) so the pattern becomes visible. Top-down camera, pos (0, 0, 0.4), xyaxes="1 0 0  0 1 0", fovy 42.

---

## 🔴 Tier 3 — Harder, multi-part scenes (5–10 hr each)

These are bigger projects that warrant their own day each. Don't include in
the 18-scenes-per-day plan; allocate them as one-off projects.

- **trebuchet** — counterweight + arm + sling + projectile; classic mechanical advantage
- **crane_hoist_articulated** — multi-link crane arm + cable + hook + load
- **roller_coaster_simple** — track with loops, hills, and a launch
- **cam_follower_mechanism** — rotating cam drives a reciprocating follower
- **differential_gear_visual** — visual demo of how a car differential splits torque
- **articulated_arm_5dof** — 5-DOF robotic arm reaching for an object
- **domino_fibonacci_spiral** — programmatic Fibonacci or logarithmic spiral of dominoes
- **pendulum_clock_escapement** — escapement wheel + pendulum drives a clock
- **perpetual_motion_demos** — show 3 famous "perpetual motion" designs failing
- **kinetic_sculpture_mobile** — multi-pendulum mobile, balanced and swinging

---

## ❌ Tier 4 — Out of scope (need a different simulator)

These need fluid / EM / optics / thermo and cannot be done with MuJoCo as-is.

- ❌ `hydrostatic_buoyancy` — needs continuous fluid; granular hack is poor
- ❌ `surface_tension`, `capillary_action` — needs SPH/MPM
- ❌ `wave_tank`, `dam_break` — needs SPH
- ❌ `vortex_shedding`, `karman_street` — needs Navier-Stokes
- ❌ `charged_particle_in_field` — needs EM force solver
- ❌ `electromagnetic_induction` — Faraday's law
- ❌ `motor_generator` — coil + magnet rotation, needs EM
- ❌ `light_refraction_lens` — needs ray tracing
- ❌ `double_slit_interference` — needs wave optics
- ❌ `gas_in_piston` — needs thermodynamics

For any of these, suggest a different toolkit (Genesis, Taichi+MPM, Manim,
or pre-animated Blender) — they are deliberately off-roadmap for this repo.

## Unsorted ideas (to triage)

New scene ideas land here. The master keeper triages and slots them into the
right tier when reviewing RETURNS_LOG.md.

- ...

---

## Distribution math

| Tier | Count |
|------|------:|
| ✅ Done | 23 |
| 🔵 Tier 1 (kept) | 28 |
| 🟣 Tier 1 (new) | 23 |
| 🟢 Tier 1 (final additions, round 2) | 10 |
| 🟠 Tier 2 | 24 |
| 🔴 Tier 3 (reserved as special projects) | 10 |
| **Total available for assignment** | **61 Tier 1 + 24 Tier 2 = 85** |

Plan: 5 employees × 17 each = 85, exhausting the assignable pool (Tier 3 is
reserved for special projects, not the first round). Per-person mix: 12 Tier 1
+ 5 Tier 2, spread across topic categories (pendulum / rolling / collision /
spring-or-wave / chain-or-curve / free-body-or-structure / friction-or-
mechanism) so nobody gets a one-topic day.
