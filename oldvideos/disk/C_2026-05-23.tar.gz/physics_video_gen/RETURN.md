# Return from C

(Fill this in before sending the package back. Keep the headings — the master
keeper greps for them.)

**Your name:** C
**Round date (received):** 2026-05-23
**Return date:**

---

## Tasks completed

List each scene you finished. For each, give a 1-line description and the
duration you rendered.

- [x] example_scene_name — brief description, 4s
- [ ] some_blocked_scene — see "incomplete" below

## Tasks incomplete or blocked

If you couldn't finish a task, say which one and why. If the physics was
harder than expected, what blocked you?

- ...

## New gotchas hit (worth adding to docs/gotchas.md)

If you (or your AI) hit a non-obvious MuJoCo behavior that cost more than
30 min to debug, describe it here. Use this format so the master keeper can
move it into `docs/gotchas.md` cleanly:

### Title of the gotcha

**What happened:** ...

**Why:** ...

**Fix / how to apply:** ...

(Repeat the above block for each gotcha. Delete the section entirely if you
hit none.)

## New scene ideas worth adding to BACKLOG

Found a physics topic that would make a good scene but isn't in `BACKLOG.md`
yet? Suggest it here. Just a 1-line description per idea is fine.

- ...

## Anything else (questions, comments, blockers)

Free-form. Anything you want the master keeper to know.

...
